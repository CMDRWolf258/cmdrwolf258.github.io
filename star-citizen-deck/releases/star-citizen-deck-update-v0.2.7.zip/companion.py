#!/usr/bin/env python3
"""Star Citizen Deck: LAN touchscreen interface + Windows single-key input companion.

Only user-initiated, single mapped key/button actions are sent. Does not touch game files.
No external Python modules are required.
"""
from __future__ import annotations

import argparse
import io
import hashlib
import zipfile
import subprocess
import ctypes
import hmac
import json
import os
import platform
import secrets
import socket
import sys
import threading
import time
import xml.etree.ElementTree as ET
import urllib.request
import urllib.error
from copy import deepcopy
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from deck_defaults import CONTROLS, PROFILES
from update_helper import verify_package, STAGE_FILE, VERSION, version_tuple

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"
MAX_XML = 6_000_000
MAX_UPDATE = 4_000_000
# The public Pages folder contains only release artifacts, not the private repo.
# Every download path is derived from the validated version, never from user input.
RELEASE_MANIFEST_URL = "https://cmdrwolf258.github.io/star-citizen-deck/latest.json"
RELEASE_ASSET_BASE = "https://cmdrwolf258.github.io/star-citizen-deck/releases/"

def release_info():
    """Check the fixed HTTPS release manifest published to our GitHub Pages site.

    A SHA-256 digest catches corruption but does not replace publisher signatures.
    Never accept arbitrary URLs, redirects, filenames, or oversized packages.
    """
    request=urllib.request.Request(RELEASE_MANIFEST_URL, headers={
        "User-Agent":"StarCitizenDeck/" + VERSION,
        "Accept":"application/json", "Cache-Control":"no-cache"})
    try:
        with urllib.request.urlopen(request, timeout=6) as resp:
            if resp.geturl() != RELEASE_MANIFEST_URL:
                raise ValueError('Unexpected release manifest redirect')
            raw=resp.read(16_385)
        if len(raw)>16_384:
            raise ValueError('Release manifest exceeds size limit')
        info=json.loads(raw)
        if not isinstance(info,dict) or info.get('schema')!=1 or info.get('channel')!='stable':
            raise ValueError('Unrecognized release manifest')
        release_version=info['version']
        if not isinstance(release_version,str) or len(release_version)>20:
            raise ValueError('Invalid release version')
        version_tuple(release_version)
        filename=f'star-citizen-deck-update-v{release_version}.zip'
        expected_url=RELEASE_ASSET_BASE+filename
        size=info.get('size')
        digest=info.get('sha256','')
        if (info.get('filename')!=filename or info.get('url')!=expected_url or
                not isinstance(size,int) or isinstance(size,bool) or not 0<size<=MAX_UPDATE or
                not isinstance(digest,str) or len(digest)!=64 or
                any(c not in '0123456789abcdef' for c in digest)):
            raise ValueError('Invalid release asset metadata')
        newer=version_tuple(release_version)>version_tuple(VERSION)
        return {'configured':True,'available':newer,'latest':release_version,
                'note':('Verified update v'+release_version+' is available.' if newer
                        else 'Companion is up to date.'),
                'url':expected_url if newer else '',
                'sha256':digest if newer else '', 'size':size if newer else 0}
    except urllib.error.HTTPError as e:
        if e.code==404:
            return {'configured':False,'available':False,'latest':'',
                    'note':'Public update channel is not published yet.','url':''}
        return {'configured':False,'available':False,'latest':'',
                'note':'Release check failed (HTTP %s).'%e.code,'url':''}
    except (OSError,ValueError,KeyError,TypeError,UnicodeError) as e:
        return {'configured':False,'available':False,'latest':'',
                'note':'Release check unavailable: '+str(e)[:150],'url':''}


class DeckError(Exception):
    pass

def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def standard_path():
    if platform.system() == "Windows":
        return Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / "StarCitizenDeck" / "state.json"
    return Path.home() / ".config" / "StarCitizenDeck" / "state.json"

def default_config():
    return {"controls": deepcopy(CONTROLS), "source_path":"", "auto_sync":True,
            "last_import":"", "last_file":"", "profile_label":"DEFAULT DECK","prefer_live":True,
            "auth_token":secrets.token_urlsafe(32), "armed":False, "input_mode":"scan","input_migrated_024":False}

def parse_xml(path:Path):
    """Read Star Citizen's exported or active custom overrides (not the base defaults)."""
    if not path.is_file() or path.stat().st_size > MAX_XML:
        raise DeckError("XML profile missing or too large")
    doc = ET.parse(path)
    if doc.getroot().tag != "ActionMaps":
        raise DeckError("Not a Star Citizen ActionMaps file")
    catalog=[]
    # Real active actionmaps.xml may nest actionmaps in ActionProfiles.
    for group in doc.getroot().iter("actionmap"):
        group_name=group.get("name", "")
        for action in group.findall("action"):
            name=action.get("name", "")
            if not group_name or not name: continue
            raw=[(e.get("input") or "").strip() for e in action.findall("rebind")]
            if not raw:continue
            k_overrides=[x for x in raw if x.lower().startswith("kb1_")]
            kb=k_overrides[-1] if k_overrides else None
            catalog.append({"ref":f"{group_name}/{name}","map":group_name,"name":name,
                            "keyboard":kb or "", "keyboard_override":kb, "raw":raw})
    return {"profile":doc.getroot().get("profileName") or path.stem,
            "catalog":catalog,"count":len(catalog)}

def parse_defaults(path:Path):
    """Read genuine extracted defaultProfile.xml (not a community shortcut table)."""
    if not path.is_file() or path.stat().st_size > MAX_XML:
        raise DeckError("Default profile XML missing or too large")
    root=ET.parse(path).getroot()
    if root.tag not in ("profile","ActionMaps"):
        raise DeckError("Not a Star Citizen defaultProfile.xml")
    out={}
    for group in root.iter("actionmap"):
        gn=group.get("name", "")
        for act in group.findall("action"):
            an=act.get("name", "")
            if not gn or not an:continue
            raw=(act.get("keyboard") or "").strip()
            if not raw:
                k=act.find("keyboard")
                if k is not None:raw=(k.get("input") or "").strip()
            kb=""
            if raw:
                try:
                    candidate=raw if raw.lower().startswith('kb1_') else 'kb1_'+raw
                    parse_key(candidate)
                    kb=candidate
                except DeckError:pass  # never turn mouse/axis input into an invalid key
            out[f"{gn}/{an}"]={"ref":f"{gn}/{an}","map":gn,"name":an,
                                 "keyboard":kb,"raw":([raw] if raw else []),"origin":"game-default"}
    if not out:raise DeckError("No Star Citizen actions found in default profile")
    return out

def locate_game_files(export_path:Path):
    """Find current live overrides and an *extracted* game default, read-only."""
    branch=None
    for parent in [export_path.parent,*export_path.parents]:
        if parent.name.upper() in ("LIVE","PTU","EPTU","TECH-PREVIEW"):
            branch=parent;break
    active=[];defaults=[]
    if branch:
        for controls_dir in (branch/'USER'/'Client'/'0'/'Profiles'/'default',
                             branch/'USER'/'Profiles'/'default'):
            active.append(controls_dir/'actionmaps.xml')
        defaults.extend([branch/'Data'/'Libs'/'Config'/'defaultProfile.xml',
                         branch/'Data'/'Localization'/'english'/'defaultProfile.xml'])
    # Explicit user-provided extracted defaults stored outside Star Citizen.
    defaults.extend([standard_path().parent/'defaultProfile.xml',ROOT/'defaults'/'defaultProfile.xml'])
    return next((x for x in active if x.is_file()),None),next((x for x in defaults if x.is_file()),None)

def compose_catalog(custom, base=None):
    """Default keyboard first; override only keyboard entries, never joystick-only entries."""
    catalog={k:dict(v) for k,v in (base or {}).items()}
    # The user's in-game UI confirmed this mapping. Only a fallback if game defaults absent.
    if 'lights/controller/v_lights' not in catalog:
        catalog['lights/controller/v_lights']={"ref":"lights/controller/v_lights",
          "map":"lights/controller","name":"v_lights","keyboard":"kb1_l",
          "raw":[],"origin":"user-confirmed-reference"}
    for item in custom:
        ref=item['ref']; existed=catalog.get(ref,{})
        saved=existed.get('keyboard','')
        override=item['keyboard_override']
        if override is not None:
            # A bare kb1_ represents an explicitly unbound keyboard action.
            if override.lower()=='kb1_':saved=''
            else:
                try:parse_key(override);saved=override
                except DeckError:saved=''
            origin='custom-keyboard' if saved else 'custom-unbound'
        else:origin=existed.get('origin','joystick-only')
        catalog[ref]={**existed,**item,"keyboard":saved,"origin":origin,
                      "raw":item['raw']}
    return sorted(catalog.values(),key=lambda a:(a['map'],a['name']))

def find_profile_candidates():
    """Find recent exported layouts in typical SC install directories, without writing there."""
    choices=[]
    for drive in "CDEFGH":
        for prefix in (Path(f"{drive}:/Program Files/Roberts Space Industries/StarCitizen"),
                       Path(f"{drive}:/Roberts Space Industries/StarCitizen"),
                       Path(f"{drive}:/StarCitizen")):
            for branch in ("LIVE", "PTU", "EPTU", "TECH-PREVIEW"):
                directory=prefix/branch/"USER"/"Client"/"0"/"Controls"/"Mappings"
                if directory.exists():
                    choices.extend(directory.glob("layout_*_exported.xml"))
    return sorted(set(choices),key=lambda p:p.stat().st_mtime,reverse=True)[:25]

class DeckState:
    def __init__(self, state_file=None):
        self.path=Path(state_file) if state_file else standard_path()
        self.lock=threading.RLock()
        self.data=default_config()
        self.catalog=[]
        self.import_error=""
        self.last_signature=None
        self.active_file=""
        self.defaults_file=""
        self.defaults_count=0
        self.sync_source=""
        self._load()
        self._start_watch()

    def _load(self):
        try:
            if self.path.is_file():
                loaded=json.loads(self.path.read_text(encoding="utf-8"))
                for key in ("source_path","auto_sync","last_import","last_file","profile_label","auth_token","prefer_live","input_mode","input_migrated_024"):
                    if key in loaded: self.data[key]=loaded[key]
                saved={c["id"]:c for c in loaded.get("controls",[]) if isinstance(c,dict) and "id" in c}
                for item in self.data["controls"]:
                    if item["id"] in saved:
                        for key in ("label","kind","profile","section","binding","action_ref","hold_ms","manual","binding_up","binding_down"):
                            if key in saved[item["id"]]: item[key]=saved[item["id"]][key]
                for custom in loaded.get("controls",[]):
                    if isinstance(custom,dict) and str(custom.get("id","")).startswith("custom_") and not any(x["id"]==custom["id"] for x in self.data["controls"]):
                        self.data["controls"].append(custom)
                # Migrate known, user-confirmed lights mapping without replacing custom choices.
                for ctl in self.data["controls"]:
                    if ctl["id"] in ("sys_lights","home_lights") and not ctl.get("action_ref") and not ctl.get("manual"):
                        ctl["action_ref"]="lights/controller/v_lights"
                # Always disarmed when starting/restarting companion.
                self.data["armed"]=False
        except (OSError, ValueError, TypeError) as e:
            print("Warning: could not load saved settings:", e)
        if self.data.get("input_mode") not in ("virtual","scan"):
            self.data["input_mode"]="scan"
        # One-time compatibility trial: prior releases always defaulted to virtual keys.
        # Automatically select scan codes, requiring no iPad menu change. A later user
        # selection of virtual mode persists and is not overridden on next launch.
        if not self.data.get("input_migrated_024"):
            self.data["input_mode"]="scan"
            self.data["input_migrated_024"]=True
        for ctl in self.data["controls"]:
            if ctl["id"] in ("sys_lights","home_lights") and not ctl.get("action_ref") and not ctl.get("manual"):
                ctl["action_ref"]="lights/controller/v_lights"
        self._save()
        if self.data["source_path"]:
            try:self._sync(self.data["source_path"], save=True)
            except Exception as e:self.import_error=str(e)

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp=self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.data,indent=2),encoding="utf-8")
        temp.replace(self.path)

    def _files_for(self,target):
        path=Path(target).expanduser()
        if path.is_dir():
            files=sorted(path.glob("layout_*_exported.xml"),key=lambda p:p.stat().st_mtime_ns,reverse=True)
            if not files:raise DeckError("No exported layout_..._exported.xml files in that folder")
            path=files[0]
        active,base=locate_game_files(path)
        if not self.data['prefer_live']:active=None
        sources=[path]
        if active:sources.append(active)
        if base:sources.append(base)
        signature=tuple((str(p),p.stat().st_mtime_ns,p.stat().st_size) for p in sources)
        return path, active, base, signature

    def _sync(self, target, save=True):
        path,live,default_file,sig=self._files_for(target)
        override_file=live or path
        custom=parse_xml(override_file)
        base=parse_defaults(default_file) if default_file else {}
        catalog=compose_catalog(custom['catalog'],base)
        lookup={x["ref"]:x for x in catalog}
        for ctl in self.data["controls"]:
            if ctl.get("manual"):continue
            bind=lookup.get(ctl.get("action_ref"))
            ctl["binding"]=bind["keyboard"] if bind else ""
            ctl["binding_source"]=(bind['origin'] if bind else 'not-found')
        self.catalog=catalog
        self.data["last_import"]=now()
        self.data["last_file"]=str(path)
        self.defaults_file=str(default_file or '')
        self.defaults_count=len(base)
        self.active_file=str(live or '')
        self.sync_source='Live game mappings' if live else 'Exported profile'
        self.import_error=""
        self.last_signature=sig
        if save:self._save()
        return {"profile":custom['profile'],"count":custom['count'],
                "total":len(catalog),"defaults":len(base),"source":self.sync_source}

    def sync(self, target=None):
        with self.lock:
            if target is not None:
                path=Path(target).expanduser()
                if not path.exists(): raise DeckError("That XML file or directory does not exist on Serenity")
                self.data["source_path"]=str(path)
            if not self.data["source_path"]:
                candidates=find_profile_candidates()
                if not candidates:raise DeckError("No exported profile found automatically. Enter its path in Settings.")
                self.data["source_path"]=str(candidates[0])
            return self._sync(self.data["source_path"])

    def _start_watch(self):
        def loop():
            while True:
                time.sleep(3)
                with self.lock:
                    if not self.data["auto_sync"] or not self.data["source_path"]:continue
                    try:
                        *_,sig=self._files_for(self.data["source_path"])
                        if sig!=self.last_signature:self._sync(self.data["source_path"])
                    except Exception as e:self.import_error=str(e)
        threading.Thread(target=loop,daemon=True,name="xml-profile-watch").start()

    def view(self):
        with self.lock:
            return {"profiles":PROFILES, "controls":deepcopy(self.data["controls"]),
                    "armed":self.data["armed"],"input_mode":self.data["input_mode"],"auto_sync":self.data["auto_sync"],
                    "source_path":self.data["source_path"],"last_file":self.data["last_file"],
                    "last_import":self.data["last_import"],"profile_label":self.data["profile_label"],
                    "catalog":deepcopy(self.catalog),"import_error":self.import_error,
                    "defaults_file":self.defaults_file,"defaults_count":self.defaults_count,
                    "active_file":self.active_file,"sync_source":self.sync_source,
                    "prefer_live":self.data["prefer_live"],"version":VERSION,
                    "system":platform.system(), "can_send":platform.system()=="Windows"}

    def update_control(self, payload):
        with self.lock:
            ctl=next((c for c in self.data["controls"] if c["id"]==payload.get("id")),None)
            if not ctl:raise DeckError("Unknown control")
            if "label" in payload:
                label=str(payload["label"]).strip()[:55]
                if not label:raise DeckError("Label required")
                ctl["label"]=label
            if "profile" in payload:
                if payload["profile"] not in [p["id"] for p in PROFILES]:raise DeckError("Unknown profile")
                ctl["profile"]=payload["profile"]
            if "section" in payload:
                section=str(payload["section"]).strip()[:52]
                if not section:raise DeckError("Section name required")
                ctl["section"]=section
            if "kind" in payload:
                if payload["kind"] not in ("button","toggle","hold","slider"):raise DeckError("Invalid control type")
                ctl["kind"]=payload["kind"]
            if "hold_ms" in payload:
                ms=int(payload["hold_ms"])
                if not 40<=ms<=3000:raise DeckError("Hold duration must be 40–3000 ms")
                ctl["hold_ms"]=ms
            if "manual_binding" in payload:
                key=str(payload["manual_binding"]).strip()[:90]
                if key:parse_key(key)  # validate before accepting
                ctl["binding"]=key
                ctl["manual"]=True
                ctl["binding_source"]="manual"
            if "action_ref" in payload:
                ref=str(payload["action_ref"])
                ctl["action_ref"]=ref or None
                ctl["manual"]=False
                match=next((a for a in self.catalog if a["ref"]==ref),None)
                ctl["binding"]=match["keyboard"] if match else ""
                ctl["binding_source"]=match.get("origin","xml") if match else "not-found"
            if "binding_up" in payload:
                value=str(payload["binding_up"]).strip()[:90]
                if value:parse_key(value)
                ctl["binding_up"]=value
            if "binding_down" in payload:
                value=str(payload["binding_down"]).strip()[:90]
                if value:parse_key(value)
                ctl["binding_down"]=value
            self._save()
            return deepcopy(ctl)

    def create_control(self, payload):
        with self.lock:
            profile=str(payload.get("profile","home"))
            if profile not in [p["id"] for p in PROFILES]:raise DeckError("Unknown profile")
            label=str(payload.get("label","")).strip()[:55]
            if not label:raise DeckError("A name is required")
            group=str(payload.get("section","Custom controls")).strip()[:52] or "Custom controls"
            new={"id":"custom_"+secrets.token_hex(6),"profile":profile,"section":group,"label":label,
                 "kind":"button","binding":"","action_ref":None,"hold_ms":100,"description":"Custom control",
                 "manual":False,"confirm":False}
            self.data["controls"].append(new)
            self._save()
            return new

    def delete_control(self, control_id):
        with self.lock:
            if not str(control_id).startswith("custom_"):raise DeckError("Built-in controls cannot be deleted; move or rename them")
            self.data["controls"]=[c for c in self.data["controls"] if c["id"]!=control_id]
            self._save()
            return {"ok":True}

    def settings(self, payload):
        with self.lock:
            if "armed" in payload:self.data["armed"]=bool(payload["armed"])
            if "input_mode" in payload:
                if payload["input_mode"] not in ("virtual","scan"):
                    raise DeckError("Input mode must be virtual or scan")
                self.data["input_mode"]=payload["input_mode"]
            if "auto_sync" in payload:self.data["auto_sync"]=bool(payload["auto_sync"])
            if "prefer_live" in payload:
                self.data["prefer_live"]=bool(payload["prefer_live"])
                if self.data["source_path"]:self._sync(self.data["source_path"],save=False)
            if "profile_label" in payload:self.data["profile_label"]=str(payload["profile_label"])[:50]
            self._save()
            return self.view()

    def action(self, ctl_id, direction=None):
        with self.lock:
            ctl=next((c for c in self.data["controls"] if c["id"]==ctl_id),None)
            if not ctl:raise DeckError("Unknown control")
            if not self.data["armed"]:raise DeckError("Output is DISARMED. Enable it in Settings before sending commands.")
            key=ctl.get("binding")
            if ctl.get("kind")=="slider":
                if direction not in ("up","down"):
                    raise DeckError("Slider sends no analog axis. Use + / − step buttons.")
                key=ctl.get("binding_"+direction)
            if not key:raise DeckError("No compatible keyboard binding. Link an imported action or enter a keyboard shortcut.")
            hold=int(ctl.get("hold_ms",100))
            mode=self.data["input_mode"]
        send_key(str(key),hold,input_mode=mode)
        return {"ok":True,"label":ctl["label"],"command":str(key)}

# Key syntax accepts imported 'kb1_lalt+r' or manually entered 'ALT+R'.
KEYS={"SPACE":0x20,"ENTER":0x0D,"RETURN":0x0D,"TAB":0x09,"ESC":0x1B,"ESCAPE":0x1B,
      "BACKSPACE":0x08,"DELETE":0x2E,"DEL":0x2E,"INSERT":0x2D,"HOME":0x24,"END":0x23,
      "PAGEUP":0x21,"PAGEDOWN":0x22,"UP":0x26,"DOWN":0x28,"LEFT":0x25,"RIGHT":0x27,
      "CAPSLOCK":0x14,"PAUSE":0x13,"PRINTSCREEN":0x2C,"PLUS":0xBB,"MINUS":0xBD,
      "EQUALS":0xBB,"COMMA":0xBC,"PERIOD":0xBE,"SLASH":0xBF,"BACKSLASH":0xDC,
      "SEMICOLON":0xBA,"APOSTROPHE":0xDE,"LBRACKET":0xDB,"RBRACKET":0xDD,
      "TILDE":0xC0,"BACKTICK":0xC0,"LALT":0xA4,"RALT":0xA5,"ALT":0x12,
      "LCTRL":0xA2,"RCTRL":0xA3,"CTRL":0x11,"LSHIFT":0xA0,"RSHIFT":0xA1,"SHIFT":0x10,
      "LWIN":0x5B,"RWIN":0x5C}
KEYS.update({f"F{i}":0x6F+i for i in range(1,25)})
KEYS.update({f"NUMPAD{i}":0x60+i for i in range(10)})
ALIAS={"LCONTROL":"LCTRL","RCONTROL":"RCTRL","CONTROL":"CTRL","LALT":"LALT",
       "RALT":"RALT","LCTRL":"LCTRL","RCTRL":"RCTRL","LSHIFT":"LSHIFT","RSHIFT":"RSHIFT",
       "SPACEBAR":"SPACE","PGUP":"PAGEUP","PGDN":"PAGEDOWN","KP_ENTER":"ENTER",
       "MOUSE1":"INVALID","MWHEELUP":"INVALID","MWHEELDOWN":"INVALID"}

def parse_key(value):
    value=value.strip().upper()
    if value.startswith("KB1_"):value=value[4:]
    tokens=[ALIAS.get(part.strip(),part.strip()) for part in value.split("+")]
    if not tokens or len(tokens)>5 or any(not t for t in tokens):raise DeckError("Invalid key combination")
    result=[]
    for token in tokens:
        if len(token)==1 and ("A"<=token<="Z" or "0"<=token<="9"):
            result.append(ord(token))
        elif token in KEYS:
            result.append(KEYS[token])
        else:raise DeckError(f"Unsupported key: {token}. Use keyboard keys only; joystick/mouse axes aren't supported in v0.2.")
    if len(set(result))!=len(result):raise DeckError("Duplicate key in combination")
    return result

# Win32 INPUT must contain the largest of MOUSEINPUT, KEYBDINPUT and HARDWAREINPUT.
# A union containing only KEYBDINPUT is too small on 64-bit Windows (32 vs 40 bytes),
# causing SendInput to fail with ERROR_INVALID_PARAMETER before the game sees a key.
DWORD=ctypes.c_uint32
WORD=ctypes.c_uint16
LONG=ctypes.c_int32
ULONG_PTR=ctypes.c_size_t

class MOUSEINPUT(ctypes.Structure):
    _fields_=[("dx",LONG),("dy",LONG),("mouseData",DWORD),("dwFlags",DWORD),
              ("time",DWORD),("dwExtraInfo",ULONG_PTR)]

class KEYBDINPUT(ctypes.Structure):
    _fields_=[("wVk",WORD),("wScan",WORD),("dwFlags",DWORD),
              ("time",DWORD),("dwExtraInfo",ULONG_PTR)]

class HARDWAREINPUT(ctypes.Structure):
    _fields_=[("uMsg",DWORD),("wParamL",WORD),("wParamH",WORD)]

class INPUT_UNION(ctypes.Union):
    _fields_=[("mi",MOUSEINPUT),("ki",KEYBDINPUT),("hi",HARDWAREINPUT)]

class INPUT(ctypes.Structure):
    _fields_=[("type",DWORD),("data",INPUT_UNION)]

def foreground_is_notepad(user32, hwnd):
    """Only allow the explicit diagnostics endpoint to target genuine notepad.exe.

    Validate the foreground window's owning process, not just its title.
    This leaves the normal Star Citizen-only path entirely unchanged.
    """
    if not hwnd:
        return False
    pid=ctypes.c_uint32(0)
    user32.GetWindowThreadProcessId.argtypes=(ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint32))
    user32.GetWindowThreadProcessId.restype=ctypes.c_uint32
    if not user32.GetWindowThreadProcessId(ctypes.c_void_p(hwnd),ctypes.byref(pid)) or not pid.value:
        return False
    kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel32.OpenProcess.argtypes=(ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32)
    kernel32.OpenProcess.restype=ctypes.c_void_p
    kernel32.CloseHandle.argtypes=(ctypes.c_void_p,)
    kernel32.CloseHandle.restype=ctypes.c_int
    kernel32.QueryFullProcessImageNameW.argtypes=(ctypes.c_void_p,ctypes.c_uint32,
                                                   ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32))
    kernel32.QueryFullProcessImageNameW.restype=ctypes.c_int
    handle=kernel32.OpenProcess(0x1000,False,pid.value)
    if not handle:
        return False
    try:
        name=ctypes.create_unicode_buffer(32768)
        size=ctypes.c_uint32(len(name))
        if not kernel32.QueryFullProcessImageNameW(handle,0,name,ctypes.byref(size)):
            return False
        return os.path.basename(name.value).casefold()=='notepad.exe'
    finally:
        kernel32.CloseHandle(handle)


def keyboard_event(vk, release=False, input_mode='virtual', mapped_scan=0):
    """Build one standard Windows keyboard INPUT event, without game hooks.

    Virtual-key is legacy v0.2.2 behavior. Scan-code mode uses Microsoft's
    documented KEYEVENTF_SCANCODE, with the E0 extended-key bit when needed.
    """
    if input_mode=='virtual':
        return INPUT(type=1,data=INPUT_UNION(ki=KEYBDINPUT(vk,0,0x0002 if release else 0,0,0)))
    if input_mode!='scan':
        raise DeckError('Invalid input mode')
    if not mapped_scan:
        raise DeckError('Windows did not map the keyboard key to a scan code')
    prefix=mapped_scan & 0xFF00
    if prefix not in (0,0xE000):
        raise DeckError('Unsupported extended scan-code prefix')
    flags=0x0008 | (0x0002 if release else 0) | (0x0001 if prefix else 0)
    return INPUT(type=1,data=INPUT_UNION(ki=KEYBDINPUT(0,mapped_scan & 0xFF,flags,0,0)))


def send_key(binding,hold_ms,target='starcitizen',input_mode='virtual'):
    keycodes=parse_key(binding)
    if platform.system()!="Windows":raise DeckError("Live input is available only with the Windows companion on Serenity.")
    user32=ctypes.WinDLL("user32",use_last_error=True)
    user32.GetForegroundWindow.restype=ctypes.c_void_p
    hwnd=user32.GetForegroundWindow()
    buf=ctypes.create_unicode_buffer(256)
    user32.GetWindowTextW(ctypes.c_void_p(hwnd),buf,256)
    if target=='notepad':
        if not foreground_is_notepad(user32,hwnd):
            raise DeckError('Notepad is not the foreground app. Open Notepad on Serenity and click inside a blank document first.')
    elif target=='starcitizen':
        if "star citizen" not in buf.value.lower() and "starcitizen" not in buf.value.lower():
            raise DeckError("Star Citizen is not the foreground window. Focus the game on Serenity first. (Title: "+(buf.value or "none")+")")
    else:
        raise DeckError('Unknown input target')
    # Single user-initiated press/release, without hooks or modification of game files.
    user32.SendInput.argtypes=(ctypes.c_uint,ctypes.POINTER(INPUT),ctypes.c_int)
    user32.SendInput.restype=ctypes.c_uint
    if input_mode=='scan':
        user32.MapVirtualKeyW.argtypes=(ctypes.c_uint,ctypes.c_uint)
        user32.MapVirtualKeyW.restype=ctypes.c_uint
    def event(vk, release=False):
        mapped=user32.MapVirtualKeyW(vk,4) if input_mode=='scan' else 0
        item=keyboard_event(vk,release,input_mode,mapped)
        ctypes.set_last_error(0)
        if user32.SendInput(1,ctypes.byref(item),ctypes.sizeof(INPUT))!=1:
            code=ctypes.get_last_error()
            detail=(f" (Win32 error {code}: {ctypes.FormatError(code).strip()})" if code else " (no Windows error code provided)")
            raise DeckError("Windows SendInput failed"+detail+". This does not establish anti-cheat interference.")
    pressed=[]
    try:
        for code in keycodes:
            event(code)
            pressed.append(code)
        time.sleep(min(3,max(0.04,hold_ms/1000)))
    finally:
        for code in reversed(pressed):
            try:event(code,True)
            except DeckError:pass

class Handler(BaseHTTPRequestHandler):
    server_version="StarCitizenDeck/" + VERSION
    def _send(self,obj,status=200):
        raw=json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store")
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Content-Length",str(len(raw)))
        self.end_headers();self.wfile.write(raw)
    def _body(self):
        n=int(self.headers.get("Content-Length","0"))
        if not 0<n<20_000:raise DeckError("Invalid request size")
        value=json.loads(self.rfile.read(n))
        if not isinstance(value,dict):raise DeckError("Expected JSON object")
        return value
    def _auth(self):
        token=self.headers.get("X-Deck-Token","")
        return hmac.compare_digest(token,self.server.state.data["auth_token"])
    def _handle(self):
        parsed=urlparse(self.path).path
        if parsed.startswith("/api/"):
            # LAN clients must use the app's own origin. Never accept cross-site POSTs.
            origin=self.headers.get("Origin","")
            if origin and origin not in (f"http://{self.headers.get('Host','')}",):
                return self._send({"error":"Cross-origin request refused"},403)
            if parsed=="/api/hello" and self.command=="GET":
                return self._send({"app":"Star Citizen Deck","version":VERSION,"pairing":True})
            if parsed=="/api/pair" and self.command=="POST":
                ip=self.client_address[0]
                with self.server.pair_lock:
                    attempts=self.server.attempts.get(ip,[])
                    attempts=[t for t in attempts if time.monotonic()-t<120]
                    if len(attempts)>=8:return self._send({"error":"Too many attempts. Try again in two minutes."},429)
                    body=self._body()
                    if not hmac.compare_digest(str(body.get("pin","")),self.server.pin):
                        attempts.append(time.monotonic());self.server.attempts[ip]=attempts
                        return self._send({"error":"Incorrect pairing code"},401)
                    self.server.attempts[ip]=[]
                return self._send({"token":self.server.state.data["auth_token"]})
            if not self._auth():return self._send({"error":"Pair the iPad with the companion first."},401)
            state=self.server.state
            if parsed=="/api/state" and self.command=="GET":return self._send(state.view())
            if parsed=="/api/update/check" and self.command=="GET":
                report=release_info()
                report.pop('url',None) # do not grant arbitrary URL selection to clients
                return self._send(report)
            if parsed=="/api/update/status" and self.command=="GET":
                pending=STAGE_FILE(state.path).is_file()
                return self._send({"version":VERSION,"pending":pending,
                                   "method":"verified update ZIP","remote_feed":True})
            if self.command!="POST":return self._send({"error":"Unsupported method"},405)
            if parsed=="/api/update/fetch":
                info=release_info()
                if not info['available'] or not info['url']:
                    raise DeckError('No published update available')
                req=urllib.request.Request(info['url'],headers={'User-Agent':'StarCitizenDeck/0.2'})
                with urllib.request.urlopen(req,timeout=15) as resp:
                    if resp.geturl()!=info['url']:
                        raise DeckError('Release download redirected to an unexpected location')
                    content=resp.read(MAX_UPDATE+1)
                if len(content)!=info['size']:
                    raise DeckError('Downloaded release size does not match public manifest')
                if hashlib.sha256(content).hexdigest()!=info['sha256']:
                    raise DeckError('Downloaded release checksum differs from public manifest')
                if len(content)>MAX_UPDATE:raise DeckError('Remote update is too large')
                checked=verify_package(content,minimum=VERSION)
                if checked['version']!=info['latest']:raise DeckError('Release version does not match package')
                stage=STAGE_FILE(state.path);stage.parent.mkdir(parents=True,exist_ok=True)
                temporary=stage.with_suffix('.part')
                temporary.write_bytes(content);temporary.replace(stage)
                return self._send({'ok':True,'version':info['latest']})
            if parsed=="/api/update/upload":
                if self.headers.get("Content-Type","").split(';')[0]!="application/zip":
                    raise DeckError("Please select a .zip update package")
                size=int(self.headers.get("Content-Length","0"))
                if not 0<size<=MAX_UPDATE:raise DeckError("Update package exceeds 4 MB limit")
                raw=self.rfile.read(size)
                info=verify_package(raw,minimum=VERSION)
                path=STAGE_FILE(state.path);path.parent.mkdir(parents=True,exist_ok=True)
                part=path.with_suffix('.part');part.write_bytes(raw);part.replace(path)
                return self._send({"ok":True,"version":info['version']})
            data=self._body()
            if parsed=="/api/update/apply":
                if data.get('confirm')!='INSTALL':raise DeckError('Installation not confirmed')
                path=STAGE_FILE(state.path)
                if not path.is_file():raise DeckError('No update package staged')
                info=verify_package(path.read_bytes(),minimum=VERSION)
                state.data['armed']=False
                state._save()
                threading.Timer(.8,lambda:os._exit(75)).start()
                return self._send({"ok":True,"version":info['version'],"restart":True})
            if parsed=="/api/settings":return self._send(state.settings(data))
            if parsed=="/api/control":return self._send(state.update_control(data))
            if parsed=="/api/control/create":return self._send(state.create_control(data))
            if parsed=="/api/control/delete":return self._send(state.delete_control(data.get("id")))
            if parsed=="/api/import":return self._send(state.sync(data.get("path")))
            if parsed=="/api/diagnostic/notepad":
                # A deliberately fixed, single-key test. Normal controls still require the game.
                if not state.data['armed']:
                    raise DeckError('Arm keyboard controls in Settings → Connection before testing Notepad.')
                send_key('L',100,target='notepad')
                return self._send({'ok':True,'sent':'L','target':'Notepad',
                                   'note':'Input reported sent; confirm whether a letter l appeared.'})
            if parsed=="/api/action":return self._send(state.action(data.get("id"),data.get("direction")))
            return self._send({"error":"Unknown endpoint"},404)
        if self.command!="GET":return self._send({"error":"Unsupported method"},405)
        path="index.html" if parsed=="/" else parsed.lstrip("/")
        asset=(WEB/path).resolve()
        if WEB.resolve() not in asset.parents or not asset.is_file():
            return self.send_error(404,"Not found")
        mime="text/html" if asset.suffix==".html" else "text/css" if asset.suffix==".css" else "text/javascript"
        raw=asset.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type",mime+"; charset=utf-8")
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Cache-Control","no-store")
        self.send_header("Content-Length",str(len(raw)))
        self.end_headers();self.wfile.write(raw)
    def do_GET(self):
        try:self._handle()
        except (DeckError,ValueError,KeyError,OSError,zipfile.BadZipFile,ET.ParseError) as e:self._send({"error":str(e)},400)
    def do_POST(self):
        try:self._handle()
        except (DeckError,ValueError,KeyError,OSError,zipfile.BadZipFile,ET.ParseError) as e:self._send({"error":str(e)},400)
    def log_message(self,fmt,*args):
        if not self.path.startswith("/api/state"):
            super().log_message(fmt,*args)

class Server(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    def __init__(self,address,state):
        super().__init__(address,Handler)
        self.state=state
        self.pin=f"{secrets.randbelow(1_000_000):06d}"
        self.attempts={};self.pair_lock=threading.Lock()

def lan_ip():
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:
        sock.connect(("192.0.2.1",80));return sock.getsockname()[0]
    except OSError:return "YOUR-PC-IP"
    finally:sock.close()

def main():
    ap=argparse.ArgumentParser(description="Star Citizen iPad Control Deck companion")
    ap.add_argument("--port",type=int,default=8765)
    ap.add_argument("--host",default="0.0.0.0",help="Listen interface (default LAN)")
    ap.add_argument("--state",default="",help="Override state path for testing")
    args=ap.parse_args()
    state=DeckState(args.state or None)
    server=Server((args.host,args.port),state)
    print("\n"+"="*56)
    print(" STAR CITIZEN DECK  |  COMPANION v"+VERSION)
    print("="*56)
    print(" iPad URL: http://%s:%s"%(lan_ip(),args.port))
    print(" This PC : http://127.0.0.1:%s"%args.port)
    print(" Pair PIN: %s"%server.pin)
    print(" Commands: DISARMED on every startup")
    print(" Settings: %s"%state.path)
    print(" Keep this window open. Ctrl+C to exit.")
    print(" SECURITY: Local, trusted Wi-Fi only. HTTP is not encrypted.")
    print("="*56+"\n")
    try:server.serve_forever(poll_interval=.5)
    except KeyboardInterrupt:print("\nDeck companion stopped.")
    finally:server.server_close()

if __name__=="__main__":main()
