# Star Citizen Control Deck v0.2.6 — Public Update Channel

## Windows companion upgrade

- v0.2.6 changes the release checker to the dedicated public GitHub Pages channel at `https://cmdrwolf258.github.io/star-citizen-deck/latest.json`. The private development repository stays private.
- The installed v0.2.5 still points at the previous inactive feed. To activate future one-button remote updates, install **star-citizen-deck-update-v0.2.6.zip once** using Settings → Updates → Advanced: install a trusted ZIP manually. **Do not unzip.**
- After restarting into v0.2.6, future newer versions appear under Settings → Updates → Install. The file size, HTTPS-origin, SHA-256 digest, allowed internal paths and per-file hashes are verified before an update is installed.
- Your current user settings, pairing and keyboard controls remain outside the app folder; the installer creates persistent backups and runs an import smoke test.
- SHA-256 is an integrity check, not a developer signature. The public Pages repository is the trusted delivery location.
- The Win32 scan-code injection functions have not been changed, and in-game verification still covers **only Ship Lights**.

## Developer release

Run `python -m unittest discover -s windows/tests -v` and `python scripts/build_update.py` from the private repo. Publish the versioned ZIP to the public Pages repository at `star-citizen-deck/releases/` and publish `star-citizen-deck/latest.json` **after** verifying the ZIP is publicly accessible. See root README.

## Input behavior and limits

- Only Ship Lights has been validated in-game. Other controls, modifiers, axes and held inputs remain unverified.
- The browser panel shows sent commands, **not** confirmed game state.
- No ship telemetry, true analog axis controls, or GameGlass dependencies.
- Port 8765 is HTTP on trusted Wi-Fi, not an internet-facing service. Do not port-forward it.
- This update does not change HOTAS mappings or Star Citizen files.


### v0.2.7 Cockpit Concept 02
The existing browser iPad interface now uses the approved cockpit instrument layout on the seven profile pages. `Settings`, local pairing, XML imports, the updater, and scan-code command delivery remain unchanged. Each control reads the current server action and mapping by its stable ID; any control reassigned to a new profile appears in Additional Controls. Reordering within a bank saves only in that iPad browser's local storage and does not affect bindings or other devices. The mining range slider is visual-only; ± keys use their existing single-step mapped action. No ship telemetry is inferred from command delivery.
