@echo off
cd /d "%~dp0"
title Star Citizen Control Deck - Companion
where py >nul 2>nul
if %ERRORLEVEL%==0 (set "PY=py -3") else (set "PY=python")
:run
%PY% companion.py
if %ERRORLEVEL% EQU 75 (
  %PY% update_helper.py --apply --staged "%LOCALAPPDATA%\StarCitizenDeck\updates\pending.zip"
  if errorlevel 1 (
    echo Automatic install failed. The prior version is still available.
    pause
    goto :end
  )
  goto :run
)
pause
:end
