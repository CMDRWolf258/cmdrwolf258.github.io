"""Verified, reversible updates for the Star Citizen Deck Windows companion.

A SHA-256 manifest detects corruption but is not a publisher signature. Automated
updates are restricted to the project's fixed GitHub release feed and also check
GitHub's published release-asset SHA-256 digest when available.
"""
from __future__ import annotations
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERSION = '0.2.10'  # The companion, API, updater, and browser display all use this value.
MANIFEST = 'deck-package.json'
UPDATABLE = {'companion.py','deck_defaults.py','update_helper.py',
             'web/app.js','web/index.html','web/style.css',
             'START_DECK.bat','README.md'}
MAX_PACKAGE = 4_000_000
MAX_FILE = 1_000_000

def version_tuple(value):
    parts = str(value).split('.')
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        raise ValueError('Invalid version')
    return tuple(int(p) for p in parts)

def STAGE_FILE(state_path):
    return Path(state_path).parent / 'updates' / 'pending.zip'

def default_state_path():
    if sys.platform == 'win32':
        return Path(os.getenv('LOCALAPPDATA', str(Path.home()))) / 'StarCitizenDeck' / 'state.json'
    return Path.home() / '.config' / 'StarCitizenDeck' / 'state.json'

def verify_package(content, minimum=VERSION):
    if len(content) > MAX_PACKAGE:
        raise ValueError('Update package too large')
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError('Duplicate paths in update ZIP')
        if MANIFEST not in names:
            raise ValueError('Missing deck-package.json manifest')
        manifest = json.loads(z.read(MANIFEST))
        version = manifest['version']
        if version_tuple(version) <= version_tuple(minimum):
            raise ValueError('Update must be newer than ' + minimum)
        files = manifest['files']
        if not isinstance(files,dict) or not files or not set(files).issubset(UPDATABLE):
            raise ValueError('Update includes unexpected application files')
        if set(names) != set(files) | {MANIFEST}:
            raise ValueError('Update ZIP contains unexpected paths or files')
        if sum(z.getinfo(p).file_size for p in files) > MAX_PACKAGE * 2:
            raise ValueError('Unpacked update size exceeds limit')
        for rel, digest in files.items():
            info = z.getinfo(rel)
            if info.is_dir() or info.file_size > MAX_FILE or info.compress_size > MAX_PACKAGE:
                raise ValueError('Unexpected update file size')
            if ((info.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError('Symlinks are not permitted')
            if not isinstance(digest,str) or len(digest) != 64:
                raise ValueError('Invalid file digest for ' + rel)
            data = z.read(rel)
            if hashlib.sha256(data).hexdigest() != digest:
                raise ValueError('File checksum mismatch: ' + rel)
            if rel.endswith('.py'):
                compile(data, rel, 'exec')  # Detect syntax errors before touching live files.
    return manifest

def install_package(path, root=ROOT, old_version=VERSION, state_path=None):
    """Stage, back up, replace, and preflight. Restore files if any phase fails.

    Backups persist in the per-user app data directory; saved settings live outside
    the install folder and are not overwritten by the package.
    """
    root = Path(root)
    path = Path(path)
    raw = path.read_bytes()
    manifest = verify_package(raw, minimum=old_version)
    data_dir = Path(state_path).parent if state_path else default_state_path().parent
    data_dir.mkdir(parents=True,exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup = data_dir / 'backups' / (stamp + '-' + manifest['version'].replace('.','-'))
    backup.mkdir(parents=True, exist_ok=False)
    (backup/'files').mkdir()
    (backup/'metadata.json').write_text(json.dumps({
        'from':old_version,'to':manifest['version'],'paths':list(manifest['files'])},indent=2))
    state = Path(state_path) if state_path else default_state_path()
    if state.exists():
        shutil.copy2(state,backup/'state.json')
    replaced=[]
    with tempfile.TemporaryDirectory(prefix='scdeck-update-') as workspace:
        staged=Path(workspace)
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for rel in manifest['files']:
                p=staged/rel;p.parent.mkdir(parents=True,exist_ok=True)
                p.write_bytes(z.read(rel))
        try:
            for rel in manifest['files']:
                original=root/rel
                if original.is_file():
                    old=backup/'files'/rel;old.parent.mkdir(parents=True,exist_ok=True)
                    shutil.copy2(original,old)
                replaced.append(rel)
                original.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(staged/rel,original)
            # Import smoke test uses the actual installed source; no game input, no server.
            check=subprocess.run([sys.executable,'-c',
                'import companion,update_helper; assert companion.VERSION == update_helper.VERSION'],
                cwd=root,capture_output=True,text=True,timeout=12)
            if check.returncode:
                raise RuntimeError('Post-install import failed: '+check.stderr[-500:])
        except Exception:
            for rel in reversed(replaced):
                original=root/rel;old=backup/'files'/rel
                if old.is_file():shutil.copy2(old,original)
                else:original.unlink(missing_ok=True)
            raise
    path.unlink(missing_ok=True)
    return manifest['version']

if __name__=='__main__':
    if sys.argv[1:3] != ['--apply','--staged'] or len(sys.argv)!=4:
        print('Usage: update_helper.py --apply --staged <path>')
        sys.exit(2)
    try:
        print('Verifying and installing Star Citizen Deck update...')
        version=install_package(Path(sys.argv[3]))
        print('Installed version '+version+'; previous files backed up')
    except Exception as exc:
        print('Update FAILED; application files restored where possible:',exc)
        sys.exit(1)
