# Star Citizen Control Deck v0.2.6 — Public Update Channel

## Windows companion upgrade

- v0.2.6 changes the release checker to the dedicated public GitHub Pages channel at `https://cmdrwolf258.github.io/star-citizen-deck/latest.json`. The private development repository stays private.
- The installed v0.2.5 still points at the previous inactive feed. To activate future one-button remote updates, install **star-citizen-deck-update-v0.2.6.zip once** using Settings → Updates → Advanced: install a trusted ZIP manually. **Do not unzip.**
- After restarting into v0.2.6, future newer versions appear under Settings → Updates → Install. The file size, HTTPS-origin, SHA-256 digest, allowed internal paths and per-file hashes are verified before an update is installed.
- Your current user settings, pairing and keyboard controls remain outside the app folder; the installer creates persistent backups and runs an import smoke test.
- SHA-256 is an integrity check, not a developer signature. The public Pages repository is the trusted delivery location.
- The Win32 scan-code injection functions have not been changed, and in-game verification still covers **only Ship Lights**.

## Developer release

Run `python -m unittest discover -s windows/tests -v` and `python scripts/build_update.py` from the private repo. Publish the versioned ZIP to the public Pages repository at `star-citizen-deck/releases/` and publish `star-citizen-deck/latest.json` **after** verifying the ZIP is publicly accessible. See root README.

## Input behavior and limits

- Only Ship Lights has been validated in-game. Other controls, modifiers, axes and held inputs remain unverified.
- The browser panel shows sent commands, **not** confirmed game state.
- No ship telemetry, true analog axis controls, or GameGlass dependencies.
- Port 8765 is HTTP on trusted Wi-Fi, not an internet-facing service. Do not port-forward it.
- This update does not change HOTAS mappings or Star Citizen files.


### v0.2.7 Cockpit Concept 02
The existing browser iPad interface now uses the approved cockpit instrument layout on the seven profile pages. `Settings`, local pairing, XML imports, the updater, and scan-code command delivery remain unchanged. Each control reads the current server action and mapping by its stable ID; any control reassigned to a new profile appears in Additional Controls. Reordering within a bank saves only in that iPad browser's local storage and does not affect bindings or other devices. The mining range slider is visual-only; ± keys use their existing single-step mapped action. No ship telemetry is inferred from command delivery.

### v0.2.8: cockpit fit and action-linked binding visibility

- Narrow iPad panels now give single/odd-last buttons the full row and allow control banks to become single-column when space is tight. Hardware lever mechanisms remain inside their frames with wrapping labels.
- A read-only binding report shows which controls intentionally share a Star Citizen action reference and which different actions may overlap on the same keyboard shortcut. Overlap warnings are **advisory**, since ship and on-foot contexts may share keys. No mappings are changed automatically.
- The control editor now lets you copy an existing action reference from another button. Manual overrides remain per-control and survive restarts.
- Hold-type buttons show configured timed-keypress durations; this is **not** a press-and-hold-until-release input. No live ship-state telemetry or true axes have been added.
- Windows scan-code delivery, settings, pairing, updater, and saved control IDs are preserved.


### v0.2.9: Import game defaults with one explicit action

Users whose controller shows `0 game defaults` can choose **Settings → Keybindings → IMPORT GAME DEFAULTS**. The companion downloads an independently maintained, pinned SHA-256-verified SSCM v1.4.0 Windows full release, and only if the user confirms it runs the extractor against Serenity's installed Star Citizen data in read-only print mode. The resulting XML is validated and saved outside Star Citizen at `%LOCALAPPDATA%\StarCitizenDeck\defaultProfile.xml`. The existing override synchronization then runs again, preserving manual controls and joystick bindings.

SSCM is a separate upstream program; internet and a local LIVE game install are required. This operation's Windows/Data.p4k path is not tested on the user's PC yet. The action catalog will improve substantially if extraction succeeds, but unmapped cockpit controls with no valid Star Citizen action reference remain unmapped until their action is identified.

### v0.2.10: Game defaults import location fix
The verified SSCM extractor now uses the same Star Citizen environment as the synced XML profile, not SSCM's Program Files fallback. The temporary SSCM working directory receives a temporary appsettings.local.json with GameRoot and environment. No game files or mappings are modified. Report the first meaningful extractor error if the tool still fails; the last stack-trace line is not useful.

### v0.2.11: Current LIVE effective keybindings
User-initiated IMPORT CURRENT BINDINGS downloads an exact pinned 4.10.2 LIVE defaultProfile.xml (data only, no downloaded executables), verifies its Git blob checksum and checks the catalog, then overlays the current game's active actionmaps.xml overrides. A curated exact action mapping links known cockpit buttons but never overwrites manual shortcuts or previously working lights. Controls without supported keyboard inputs remain unassigned; the 4.10.2 reference version is displayed and must not be confused with a live archive extraction.
