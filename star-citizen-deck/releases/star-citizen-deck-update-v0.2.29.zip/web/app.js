/* Star Citizen Control Deck — version from Windows companion API. */
'use strict';
/* Integrated Layout Lab visuals and personal hangar; live game inputs remain in companion.py. */
const icons = {
 grid:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
 compass:'<circle cx="12" cy="12" r="9"/><path d="m15.9 8.1-3 6-4.8 2.1 2-5.4z"/>',
 target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 1v5m0 12v5M1 12h5m12 0h5"/>',
 cpu:'<rect x="5" y="5" width="14" height="14" rx="2"/><path d="M9 9h6v6H9zM9 1v4m6-4v4M9 19v4m6-4v4M1 9h4M1 15h4m14-6h4m-4 6h4"/>',
 pickaxe:'<path d="m14 8-7 13M2 5c7-4 14-3 19 3-8-1-13 1-16 8"/>',
 person:'<circle cx="12" cy="6" r="3.2"/><path d="M5 21v-3c0-7 14-7 14 0v3M9 12v7m6-7v7"/>',
 sliders:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="8" cy="6" r="2" fill="#07111d"/><circle cx="15" cy="12" r="2" fill="#07111d"/><circle cx="10" cy="18" r="2" fill="#07111d"/>',
 radar:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="1.5"/><path d="M12 12l5-5M12 7a5 5 0 0 1 5 5M12 3a9 9 0 0 1 9 9"/>',
 ship:'<path d="M12 2 18 9v8l-6 5-6-5V9zM8 10h8M9 14h6M12 2v12"/>',
 settings:'<circle cx="12" cy="12" r="3.5"/><path d="M9 2h6l.5 2.5 2 1 2.2-1.2 3 5-2 1.7v2.2l2 1.7-3 5-2.2-1.2-2 1L15 22H9l-.5-2.3-2-1-2.2 1.2-3-5 2-1.7v-2.2l-2-1.7 3-5 2.2 1.2 2-1z"/>',
 bolt:'<path d="m13 2-9 12h7l-1 8 10-13h-7z"/>',
 toggle:'<path d="M12 2v10M6.4 6.5a9 9 0 1 0 11.2 0"/>',
 circle:'<circle cx="12" cy="12" r="8"/><path d="m9 12 2 2 4-4"/>',
 arrow:'<path d="M4 12h16M14 6l6 6-6 6"/>',
 lock:'<rect x="5" y="10" width="14" height="12" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
 sync:'<path d="M21 11A9 9 0 0 0 5 5L3 7m0-5v5h5M3 13a9 9 0 0 0 16 6l2-2m0 5v-5h-5"/>',
 shield:'<path d="m12 2 9 4v6c0 5-3.3 8.3-9 10-5.7-1.7-9-5-9-10V6z"/>',
 chevron:'<path d="m5 9 7 7 7-7"/>',
 edit:'<path d="M3 21l5-1 13-13-4-4L4 16zM14 6l4 4"/>',
 alert:'<path d="m12 2 10 19H2zM12 8v6m0 3v1"/>',
};
const svg=(name,css='')=>`<svg class="${css}" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" fill="none" aria-hidden="true">${icons[name]||icons.circle}</svg>`;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let token=localStorage.getItem('scdeck-token')||'';
let app=null,active='home',settingsTab='bindings',profileFilter='all',search='',localStates={},localSliders={};
let sessionData=null;
let shipReference=null,shipReferenceKey='',shipReferenceChecked=0,sessionHistoryExpanded=false,shipDetailsExpanded=false;
let toastTimer=null;
const activeHoldTouches=new Map();
const el=id=>document.getElementById(id);
async function request(path,data){
  let resp=await fetch(path,{method:data===undefined?'GET':'POST',headers:{...(token?{'X-Deck-Token':token}:{}),...(data===undefined?{}:{'Content-Type':'application/json'})},body:data===undefined?undefined:JSON.stringify(data),cache:'no-store'});
  const j=await resp.json();
  if(!resp.ok)throw Object.assign(new Error(j.error||`HTTP ${resp.status}`),{status:resp.status});
  return j;
}
function notify(message,isError=false){
  const root=el('toast-root');
  root.innerHTML=`<div class="toast ${isError?'error':''}"><strong>${isError?'COMMAND NOT SENT':'CONTROL DECK'}</strong>${esc(message)}</div>`;
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>root.innerHTML='',3700);
}
function clock(){const d=new Date();el('top-time').textContent=d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',hour12:false});}
function linkStatus(ok){const node=el('top-link');node.className='connection-chip'+(ok?'':' offline');node.innerHTML=`<span class="dot"></span>${ok?'LINK ESTABLISHED':'OFFLINE'}`;}
async function startup(){
  el('settings-icon').innerHTML=svg('settings'); clock();setInterval(clock,15000);
  setInterval(refreshSession,4000);
  if(!token){showPairing();return;}
  await loadState();
  setInterval(async()=>{
    if(!token||!app)return;
    try{
      const fresh=await request('/api/state');
      const changed=fresh.last_import!==app.last_import||fresh.armed!==app.armed||fresh.version!==app.version||JSON.stringify(fresh.controls)!==JSON.stringify(deckServerApp?.controls||app.controls);
      app=deckApplyUi(fresh);linkStatus(true);updateRail();
      if(changed && !el('modal-root').innerHTML){render();}
    }catch(err){linkStatus(false);if(err.status===401){token='';localStorage.removeItem('scdeck-token');showPairing();}}
  },9000);
}
async function loadState(){
  try{app=deckApplyUi(await request('/api/state'));linkStatus(true);render();refreshSession();}
  catch(err){linkStatus(false);if(err.status===401){token='';localStorage.removeItem('scdeck-token');showPairing();}else notify(err.message,true);}
}
async function refreshSession(){
 if(!token||!app)return;
 try{
  sessionData=await request('/api/session');
  const shipKey=(sessionData.status!=='missing' && sessionData.vehicle_status!=='Released')?(sessionData.vehicle_class||''):'';
  if(shipKey!==shipReferenceKey){
    shipReferenceKey=shipKey;shipReference=null;shipReferenceChecked=0;
  }
  paintSessionPanels();
  if(shipKey && Date.now()-shipReferenceChecked>10*60*1000){
    shipReferenceChecked=Date.now();
    refreshShipReference(shipKey);
  }
 }catch(_){sessionData=null;paintSessionPanels();}
}
async function refreshShipReference(requestedClass){
 try{
  const data=await request('/api/ship-reference');
  if(requestedClass!==shipReferenceKey)return;
  shipReference=data;
 }catch(_){
  if(requestedClass!==shipReferenceKey)return;
  shipReference={status:'unavailable',reason:'Community ship database unavailable'};
 }
 paintSessionPanels();
}
function paintSessionPanels(){
 const history=el('session-history');
 if(history)sessionHistoryExpanded=history.open;
 const session=el('session-intelligence');
 if(session)session.innerHTML=sessionIntelligenceHTML();
 const previousDetails=el('ship-details');
 if(previousDetails)shipDetailsExpanded=previousDetails.open;
 const banner=el('ship-intelligence');
 if(banner)banner.innerHTML=shipIntelligenceHTML();
 const nav=el('quantum-intelligence');
 if(nav)nav.innerHTML=quantumIntelligenceHTML();
}
function shipIntelligenceHTML(){
 const s=sessionData;
 if(!s)return '<div class="ship-status">Connecting to local ship intelligence…</div>';
 const name=s.vehicle_name||s.ship_channel||'No ship detected';
 const reference=shipReference?.ship;
 const confirmed=s.vehicle_status==='Pilot control';
 const inferred=s.vehicle_status==='Inferred';
 const condition=s.status==='stale'?'LAST OBSERVED / STALE LOG':s.status==='missing'?'GAME.LOG NOT FOUND':confirmed?'LOCAL PILOT CONTROL OBSERVED':inferred?'SHIP IDENTIFIED · NAVIGATION EVENT':'UNCONFIRMED SHIP CHANNEL';
 const referenceStatus=reference ? (shipReference.status==='snapshot'?'CACHED REFERENCE · '+(reference.version||''):'WIKI DATABASE · '+(reference.version||'CURRENT')) : shipReferenceKey?(shipReference?.reason||'Looking up ship specifications…'):'No ship specification record selected';
 const displayName=reference?.name||name;
 const number=(value,suffix='')=>value===null||value===undefined||value===''?'—':Number(value).toLocaleString()+suffix;
 const specs=[
  ['CREW',reference?number(reference.crew):'—'],
  ['CARGO',reference?number(reference.cargo_capacity,' SCU'):'—'],
  ['SCM',reference?number(reference.scm_speed,' m/s'):'—'],
  ['MAX SPEED',reference?number(reference.max_speed,' m/s'):'—'],
  ['SHIELDS',reference?number(reference.shield_hp,' HP'):'—'],
  ['HULL',reference?number(reference.hull_hp,' HP'):'—']
 ];
 const stats=reference?'<div class="ship-stat-grid">'+specs.map(([label,value])=>'<div class="ship-stat"><small>'+esc(label)+'</small><b>'+esc(value)+'</b></div>').join('')+'</div>':'';
 const equipment=Array.isArray(reference?.equipment)?reference.equipment:[];
 const components=equipment.length?'<div class="ship-equipment">'+equipment.map(x=>'<div><b>'+esc(x.name)+'</b><small>'+esc(x.type||'Factory reference component')+'</small></div>').join('')+'</div>':'<p class="subtle-note">Factory component list is not available from this record. Custom-fitted parts cannot be detected from Game.log.</p>';
 const sourceUrl=reference?.source_url;
 const srcLink=sourceUrl?'<a href="'+esc(sourceUrl)+'" target="_blank" rel="noopener noreferrer">OPEN SHIP DATABASE</a>':'';
 const full=reference?'<div class="ship-detail-facts"><span>'+esc(reference.manufacturer||'')+'</span><span>'+esc(reference.role||'')+'</span>'
  +(reference.length!=null?'<span>'+esc(number(reference.length))+' × '+esc(number(reference.beam))+' × '+esc(number(reference.height))+' m</span>':'')
  +(reference.mass!=null?'<span>'+esc(number(reference.mass,' kg'))+'</span>':'')+'</div>':'';
 return '<div class="ship-banner-top"><div><div class="ship-kicker">DETECTED VESSEL / SHIP INTELLIGENCE</div>'
  +'<div class="ship-name">'+esc(displayName)+'</div><div class="ship-evidence">'+esc(condition)+'</div></div>'
  +'<div class="ship-reference-tag">REFERENCE · NOT LIVE TELEMETRY</div></div>'
  +stats+'<div class="ship-banner-bottom"><span>'+esc(referenceStatus)+'</span>'
  +(reference?'<details id="ship-details" class="ship-details" '+(shipDetailsExpanded?'open':'')+'><summary>FACTORY REFERENCE &amp; SYSTEMS</summary>'+full+components+'</details>':'')
  +srcLink+'</div>';
}
function sessionIntelligenceHTML(){
 const s=sessionData;
 if(!s)return '<p class="subtle-note">Connecting to the read-only Game.log monitor…</p>';
 const state=s.status==='monitoring'?'LOG MONITORED':s.status==='stale'?'LOG NOT RECENT':'LOG NOT FOUND';
 const note=s.status==='missing'?(s.error||'Game.log not located. Set its path in Settings → Connection.'):(s.status==='stale'?'This game log has not changed in over 15 minutes. Information below is last observed, not live.':'Game.log is being monitored; events update when the game writes them.');
 const detectedVehicle=s.vehicle_name||(s.vehicle_status==='Released'?'Not currently identified':s.ship_channel||'Unknown');
 const vehicleEvidence=s.vehicle_name?(s.vehicle_source||'Event observed')
    :(s.vehicle_status==='Released'?'Pilot control released':s.ship_channel?'Comms channel only (unverified)':'No local vehicle event found');
 const rows=[
  ['DETECTED VEHICLE',detectedVehicle],
  ['SHIP EVIDENCE',vehicleEvidence],
  ['LOCATION-RELATED EVENT',s.location_activity||'Unknown'],
  ['LAST JURISDICTION',s.jurisdiction||'Unknown'],
  ['QUANTUM TARGET CODE',s.quantum_target||'Not observed']
 ];
 const detail=rows.map(([name,value])=>'<div class="session-data-row"><span>'+esc(name)+'</span><b>'+esc(value)+'</b></div>').join('');
 const events=(s.events||[]);
 const eventHTML=e=>'<div class="session-event"><span class="session-event-mark">'+(e.historical?'HISTORY':'LOG')+'</span><span>'+esc(e.detail)+'</span></div>';
 const feed=events.slice(0,3).map(eventHTML).join('');
 const older=events.slice(3).map(eventHTML).join('');
 const history=older?'<details id="session-history" '+(sessionHistoryExpanded?'open':'')+'><summary class="session-history-title">SHOW '+(events.length-3)+' OLDER EVENTS</summary>'+older+'</details>':'';
 const contracts=(s.contracts||[]).slice(-3).map(e=>'<div class="session-event"><span class="session-event-mark">'+esc(e.status)+'</span><span>'+esc(e.name)+'</span></div>').join('');
 return '<div class="session-heading"><b>'+esc(state)+'</b><span>READ-ONLY / GAME.LOG</span></div>'
  +'<p class="session-explainer">'+esc(note)+'</p><div class="session-data">'+detail+'</div>'
  +(contracts?'<div class="microhead"><span>RECENT CONTRACT EVENTS</span><span>LOG-DERIVED</span></div>'+contracts:'')
  +'<div class="microhead"><span>RECENT GAME EVENTS</span><span>LAST 7</span></div>'
  +(feed||'<p class="subtle-note">No supported events detected in the current log yet.</p>')+history
  +'<p class="subtle-note">Pilot-control events identify a controlled vehicle when logged. Navigation-derived ship IDs are inferred; neither provides continuous live ship telemetry.</p>';
}
function quantumIntelligenceHTML(){
 const s=sessionData;
 if(!s)return '<p class="subtle-note">Connecting to Game.log…</p>';
 const label=s.quantum_target||'Not observed';
 const status=s.quantum_target?(s.quantum_status||'Unknown'):'No quantum destination event detected';
 return '<div class="session-heading"><b>LOG-OBSERVED QUANTUM TARGET</b><span>'+esc(s.status==='stale'?'STALE':s.status==='missing'?'NO LOG':'READ-ONLY')+'</span></div>'
  +'<div class="quantum-target">'+esc(label)+'</div><div class="quantum-state">'+esc(status)+'</div>'
  +'<p class="subtle-note">This is the last target code recorded by Game.log, not a synced Starmap route, distance, or ETA.</p>';
}
function showPairing(){
  const template=`<div class="modal-wrap pair-wrap"><div class="modal" role="dialog" aria-modal="true" aria-label="Pair companion"><div class="pair-logo">${svg('compass')}</div><div class="eyebrow" style="justify-content:center">INITIAL CONNECTION</div><h2>Pair with Serenity</h2><p>Start <b>START_DECK.bat</b> on your PC, then enter the six-digit PIN displayed in the companion window.</p><form id="pair-form"><div class="field"><label for="pair-pin">PAIRING CODE</label><input id="pair-pin" class="input" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]{6}" placeholder="••••••" required></div><button class="primary-btn" type="submit">CONNECT CONTROL DECK</button></form><p class="hint">Both devices must be on the same trusted local network.</p></div></div>`;
  el('modal-root').innerHTML=template;
  el('pair-form').onsubmit=async ev=>{ev.preventDefault();try{
    const result=await request('/api/pair',{pin:el('pair-pin').value});token=result.token;
    localStorage.setItem('scdeck-token',token);el('modal-root').innerHTML='';await loadState();
  }catch(e){notify(e.message,true);}};
}
function render(){
 if(!app)return;
 document.body.classList.toggle('cockpit-page', active!=='settings');
 const version=app.version||'unknown';
 if(el('deck-footer-version'))el('deck-footer-version').innerHTML='<b>STAR CITIZEN DECK</b> / V'+esc(version);
 if(el('top-version'))el('top-version').textContent='v'+version;
 renderNav();renderContent();updateRail();
}
function renderNav(){
  el('profile-nav').innerHTML=deckOrderedProfiles().map(p=>`<button data-profile="${esc(p.id)}" class="sidebar-button ${active===p.id?'active':''}" aria-label="${esc(p.name)}"><span>${svg(p.icon)}</span><small>${esc(p.short)}</small></button>`).join('');
  el('profile-nav').querySelectorAll('[data-profile]').forEach(node=>node.onclick=()=>{active=node.dataset.profile;render();el('main-area').scrollTop=0;});
  const btn=el('settings-nav');btn.classList.toggle('active',active==='settings');btn.onclick=()=>{active='settings';render();el('main-area').scrollTop=0;};
}
const heroTexts={
  home:['SYSTEM OVERVIEW','Your ship. One command center.','Favorite controls and quick access. Labels and bindings are editable in Settings.'],
  nav:['NAVIGATION SUITE','Travel without reaching for the keyboard.','Quantum travel, flight modes and energy distribution.'],
  scm:['COMBAT SUITE','Stay focused on the fight.','Targeting, weapons and defensive systems within easy reach.'],
  systems:['SHIP SYSTEMS','Every switch has a purpose.','Electrical systems, flight readiness, access and landing configuration.'],
  mining:['INDUSTRIAL SUITE','Precision at your fingertips.','Mining operator controls and an experimental local-value power slider.'],
  foot:['PERSONNEL SUITE','Equipment ready.','Useful on-foot controls for FPS activities and ground operations.'],
  utility:['AUXILIARY SUITE','Everything else, organized.','Cargo, salvage, EVA, camera and communication controls.'],
};
function renderContent(){
  if(active==='settings')return renderSettings();
  if(active==='ships')return renderShipInfo();
  renderCockpitContent();
}

function bindingLabel(control){return control.kind==='slider'?'STEP KEYS': control.binding?control.binding.replace(/^(kb1_|mo1_)/i,'').replace(/mwheel_up/ig,'WHEEL UP').replace(/mwheel_down/ig,'WHEEL DOWN').replace(/\+/g,' + ').toUpperCase():'UNASSIGNED';}
function controlHTML(c){
  if(c.kind==='slider')return `<div class="slider-control"><div class="slider-head"><div><div class="slider-title">${esc(c.label)}</div><span class="ctl-mini">LOCAL VISUAL REFERENCE</span></div><div class="slider-val" id="val-${esc(c.id)}">${localSliders[c.id]??35}%</div></div><div class="slider-row"><button class="step-btn" data-step="${esc(c.id)}" data-direction="down" title="Decrease one step">−</button><input data-slider="${esc(c.id)}" type="range" min="0" max="100" value="${localSliders[c.id]??35}" aria-label="Local laser output preview"><button class="step-btn" data-step="${esc(c.id)}" data-direction="up" title="Increase one step">+</button></div><div class="slider-note">SLIDER IS A VISUAL GUIDE. ONLY THE ± BUTTONS SEND SINGLE INPUTS WHEN MAPPED.</div></div>`;
  let on=Boolean(localStates[c.id]);let symbol=c.kind==='toggle'?`<span class="micro-switch"><b></b></span>`:svg(c.kind==='hold'?'lock':c.confirm?'alert':'arrow');
  return `<button class="ctl ${c.confirm?'guarded ':''}${c.kind==='toggle'?'toggle-control ':''}${on?'active':''}" data-control="${esc(c.id)}" title="${esc(c.description)}"><span class="ctl-top"><span class="ctl-name">${esc(c.label)}</span><span class="ctl-glyph">${symbol}</span></span><span class="ctl-bottom"><span class="ctl-binding ${c.binding?'':'unmapped'}">${esc(bindingLabel(c))}</span><span class="ctl-mini">${c.kind==='toggle'?'COMMAND':c.kind==='hold'?'TOUCH + HOLD':c.confirm?'GUARDED':'EXECUTE'}</span></span></button>`;
}
function updateRail(){if(!app)return;
 const mapped=app.controls.filter(c=>c.binding||c.kind==='slider'&&(c.binding_up||c.binding_down)).length;
 const all=app.controls.length;
 const syncInfo=app.last_import?new Date(app.last_import).toLocaleString([], {month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}):'Not imported';
 el('status-rail').innerHTML=`<div class="rail-title">MISSION CONTROL / 01</div>
 <div class="rail-block"><div class="rail-kicker">LOCAL CONNECTION</div><div class="rail-value blue">● SERENITY LINK</div><div class="rail-small">Your iPad is connected to the Windows companion.</div><span class="rail-chip">LAN / CONNECTED</span></div>
 <div class="rail-block"><div class="rail-kicker">KEYBOARD OUTPUT</div><div class="rail-value ${app.armed?'blue':'red'}">${app.armed?'ARMED':'DISARMED'}</div><div class="rail-small">${app.armed?'Star Citizen must be the foreground window.':'Commands cannot reach the game until enabled in Settings.'}</div><button class="small-action" id="rail-arm">${app.armed?'DISARM OUTPUT':'OPEN SETTINGS TO ARM'}</button></div>
 <div class="rail-block"><div class="rail-kicker">BINDING COVERAGE</div><div class="rail-value">${mapped} <span style="color:#577f9f">/ ${all}</span> ASSIGNED</div><div class="rail-progress"><span style="width:${Math.round(100*mapped/all)}%"></span></div><div class="rail-small">From effective game bindings and manual shortcuts. Unassigned MFD actions need in-game keys.</div></div>
 <div class="rail-block"><div class="rail-kicker">LAST PROFILE IMPORT</div><div class="rail-value">${esc(syncInfo)}</div><div class="rail-small">${esc(app.last_file?app.last_file.split(/[\\/]/).pop():'No XML selected')}</div></div>
 <div class="rail-block"><div class="rail-kicker">STATE REPORTING</div><div class="rail-value">COMMAND ONLY</div><div class="rail-small">Toggle indicators are local estimates, not live readings from your ship.</div></div>
 <div class="rail-ornament"><svg viewBox="0 0 160 160"><circle cx="80" cy="80" r="65"/><circle cx="80" cy="80" r="49" stroke-dasharray="7 10"/><circle cx="80" cy="80" r="27"/><path d="M80 4v30M80 126v30M4 80h30M126 80h30M40 40l80 80M120 40l-80 80"/></svg></div>`;
 el('rail-arm').onclick=()=>{active='settings';settingsTab='connection';render();};
}
async function activate(id,direction){const ctl=app.controls.find(c=>c.id===id);if(!ctl)return;
  if(ctl.kind==='hold'){notify('Touch and hold '+ctl.label+' to activate; release to stop.',true);return;}
 if((!ctl.binding&&ctl.kind!=='slider')||(ctl.kind==='slider'&&!ctl['binding_'+direction])){
   notify('"'+ctl.label+'" has no keyboard shortcut assigned. Set its binding under Settings.',true);return;}
 if(!app.armed){notify('Output is disarmed. Open Settings → Connection to enable commands.',true);return;}
 if(ctl.confirm&&!window.confirm('Send '+ctl.label+' command to Star Citizen?'))return;
 try{await request('/api/action',{id,direction});
   // No ship-state telemetry: never latch a toggle LED after merely sending a command.
   if(ctl.kind==='slider')localSliders[id]=Math.max(0,Math.min(100,Number(localSliders[id]??35)+(direction==='up'?1:-1)));
   notify(ctl.label+' · command sent');if(ctl.kind==='slider')renderContent();
 }catch(e){notify(e.message,true);}
}
// Pointer-held buttons: release on touch-up, focus loss or disconnection.
function stopTouchHold(id){
 const h=activeHoldTouches.get(id);
 if(!h || h.ended)return;
 h.ended=true;
 clearInterval(h.heartbeat);
 h.button.classList.remove('pulse');
 activeHoldTouches.delete(id);
 h.start.then(()=>request('/api/hold',{id,phase:'stop'})).catch(()=>{});
}
function beginTouchHold(id,button,event){
 if(activeHoldTouches.has(id))return;
 const ctl=app?.controls.find(x=>x.id===id);
 if(!ctl || ctl.kind!=='hold')return;
 if(!ctl.binding){notify(ctl.label+' has no keyboard or mouse-button binding.',true);return;}
 if(!app.armed){notify('Output is disarmed. Arm it in Settings → Connection.',true);return;}
 if(ctl.confirm){notify('Guarded controls cannot use continuous hold.',true);return;}
 if(event.button!==undefined && event.button!==0)return;
 event.preventDefault();
 try{button.setPointerCapture(event.pointerId);}catch(_){}
 const h={button,ended:false,heartbeat:null,start:null};
 activeHoldTouches.set(id,h);button.classList.add('pulse');
 h.start=request('/api/hold',{id,phase:'start'});
 h.start.then(()=>{
   if(h.ended)return;
   h.heartbeat=setInterval(()=>{
     if(h.ended)return;
     request('/api/hold',{id,phase:'heartbeat'}).catch(error=>{
       if(!h.ended){notify('Hold ended: '+error.message,true);stopTouchHold(id);}
     });
   },550);
   const line=el('cockpit-action-line');
   if(line)line.textContent=ctl.label.toUpperCase()+' / HELD UNTIL RELEASED';
 }).catch(error=>{if(!h.ended){notify(error.message,true);stopTouchHold(id);}});
}
window.addEventListener('blur',()=>{for(const id of [...activeHoldTouches.keys()])stopTouchHold(id);});
document.addEventListener('visibilitychange',()=>{
 if(document.hidden)for(const id of [...activeHoldTouches.keys()])stopTouchHold(id);
});
window.addEventListener('pagehide',()=>{
 for(const id of [...activeHoldTouches.keys()]){
   stopTouchHold(id);
   if(token)fetch('/api/hold',{method:'POST',keepalive:true,
     headers:{'X-Deck-Token':token,'Content-Type':'application/json'},
     body:JSON.stringify({id,phase:'stop'})}).catch(()=>{});
 }
});
function renderSettings(){
 el('main-area').innerHTML=`<div class="eyebrow">PREFERENCES / CONFIGURATION</div><div class="page-title"><div><h1>Deck Settings</h1><p>Configure keybindings, connection and interface behavior.</p></div><div class="page-index">SYSTEM / CFG</div></div>
 <div class="settings-tabs"><button data-tab="bindings" class="tab ${settingsTab==='bindings'?'active':''}">KEYBINDINGS</button><button data-tab="connection" class="tab ${settingsTab==='connection'?'active':''}">CONNECTION</button><button data-tab="layout" class="tab ${settingsTab==='layout'?'active':''}">LAYOUT</button><button data-tab="updates" class="tab ${settingsTab==='updates'?'active':''}">UPDATES</button><button data-tab="about" class="tab ${settingsTab==='about'?'active':''}">ABOUT</button></div><div id="settings-body"></div>`;
 el('main-area').querySelectorAll('[data-tab]').forEach(btn=>btn.onclick=()=>{settingsTab=btn.dataset.tab;renderSettings();});
 if(settingsTab==='bindings')renderBindingSettings();else if(settingsTab==='connection')renderConnectionSettings();else if(settingsTab==='updates')renderUpdateSettings();else if(settingsTab==='layout')deckRenderLayoutSettings();else renderAbout();
}
function bindingPeers(control){
  const report=app?.binding_report||{};
  const ids=report.shared_by_id?.[control.id]||[];
  return ids.map(id=>app.controls.find(c=>c.id===id)?.label||id);
}
function bindingConflictLabels(control){
  const ids=app?.binding_report?.conflicts_by_id?.[control.id]||[];
  return ids.map(id=>app.controls.find(c=>c.id===id)?.label||id);
}
function renderBindingSettings(){
 const choices=app.profiles.map(p=>`<option value="${esc(p.id)}" ${profileFilter===p.id?'selected':''}>${esc(p.name)}</option>`).join('');
 el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">01 / XML PROFILE SYNCHRONIZATION</div><h3>Automatic keybinding import</h3><p>Combines custom bindings with an available local Star Citizen defaultProfile.xml and optionally monitors the live actionmaps.xml. The game's current files take precedence; default mappings are never guessed from external lists.</p>
 <div class="settings-row"><div class="field"><label for="xml-path">XML FILE OR MAPPINGS FOLDER ON SERENITY</label><input class="input" id="xml-path" value="${esc(app.source_path)}" placeholder="C:\\Program Files\\Roberts Space Industries\\StarCitizen\\LIVE\\USER\\Client\\0\\Controls\\Mappings"></div><button id="sync-btn" class="primary-btn">SYNC BINDINGS</button></div>
 <div class="settings-card defaults-import"><h3>Import current game bindings</h3><p>Merge your active Star Citizen <b>actionmaps.xml</b> customizations with a verified <b>4.10.2 LIVE default profile</b>, sourced from SC Keymap. No Data.p4k extraction or downloaded executable. Only the Deck's own mapping cache changes; your game settings and HOTAS are untouched. If Star Citizen updates beyond 4.10.2, review the baseline version before relying on new/changed game actions.</p><button id="get-game-defaults" class="primary-btn" type="button">IMPORT CURRENT BINDINGS</button><p id="defaults-import-status" class="hint" role="status">Currently ${app.defaults_count||0} game defaults available.</p></div>
 <div class="toggle-row"><div class="setting-meta"><strong>Automatically watch game bindings</strong><small>Checks selected profile, live actionmaps.xml and extracted defaultProfile.xml for changes every 3 seconds.</small></div><input id="auto-toggle" class="ios-switch" type="checkbox" ${app.auto_sync?'checked':''} aria-label="Automatic XML sync"></div>
 <div class="toggle-row"><div class="setting-meta"><strong>Prefer currently active game bindings</strong><small>Uses Star Citizen's live actionmaps.xml over saved exports when available.</small></div><input id="live-toggle" class="ios-switch" type="checkbox" ${app.prefer_live?'checked':''} aria-label="Use active game bindings"></div>
 <div class="warning-line">Last import: <b>${esc(app.last_import||'Never')}</b> · ${app.catalog.length} total actions · ${app.defaults_count||0} game defaults<br>Custom source: ${esc(app.sync_source||'None')} ${app.active_file?'<br>Active game file: '+esc(app.active_file):''}<br>Default source: ${app.defaults_file?esc(app.defaults_file)+(app.defaults_reference_version?' (reference '+esc(app.defaults_reference_version)+')':''):'Not found — optional extracted defaultProfile.xml needed for full defaults. Ship Lights L is included as your confirmed reference.'}${app.import_error?'<br><b>'+esc(app.import_error)+'</b>':''}</div></section>
 <section class="settings-card"><div class="settings-heading">02 / CONTROL MAPPING EDITOR</div><h3>Editable iPad controls</h3><p>Select an action to follow imported keyboard overrides and local game defaults. When defaults are unavailable, missing assignments stay unassigned instead of being guessed.</p><div class="binding-guidance">${app.binding_report?.shared_action_count||0} shared game actions · ${app.binding_report?.potential_conflict_count||0} potential shortcut overlaps. An overlap is only a warning: contexts may legitimately use the same key.</div>
 <div class="search-row"><input class="input" id="filter-text" placeholder="Search controls..." value="${esc(search)}"><select id="filter-profile" class="input" style="max-width:190px"><option value="all">All profiles</option>${choices}</select><button id="add-control-btn" class="primary-btn">+ ADD</button></div><div id="binding-results"></div></section>`;
 el('get-game-defaults').onclick=async()=>{
   if(!confirm('Import your effective keyboard bindings? This downloads a pinned 4.10.2 default XML (no executable), merges your live Star Citizen customizations and auto-links verified cockpit actions. Your game files and HOTAS settings will not change.'))return;
   const btn=el('get-game-defaults'),status=el('defaults-import-status');
   btn.disabled=true;btn.textContent='IMPORTING CURRENT BINDINGS…';status.textContent='Combining verified 4.10.2 defaults with your live game overrides. No game settings are being changed.';
   try{const result=await request('/api/defaults/extract',{confirm:'EXTRACT_DEFAULTS'});
       app=deckApplyUi(await request('/api/state'));renderSettings();updateRail();
       notify('Imported '+result.defaults+' default actions and your active overrides. '+result.assigned+'/'+result.controls+' cockpit controls have keyboard inputs. Baseline: '+result.reference_version);
   }catch(e){btn.disabled=false;btn.textContent='RETRY IMPORT CURRENT BINDINGS';status.textContent='Could not import defaults: '+e.message;notify(e.message,true);}
 };
 el('sync-btn').onclick=async()=>{try{const p=el('xml-path').value.trim();const res=await request('/api/import',p?{path:p}:{});notify(`Synced ${res.total} actions (${res.defaults} game defaults) from ${res.source}`);app=deckApplyUi(await request('/api/state'));renderSettings();updateRail();}catch(e){notify(e.message,true);}};
 el('auto-toggle').onchange=async ev=>{try{app=await request('/api/settings',{auto_sync:ev.target.checked});notify('Automatic sync '+(app.auto_sync?'enabled':'disabled'));}catch(e){notify(e.message,true);}};
 el('live-toggle').onchange=async ev=>{try{app=await request('/api/settings',{prefer_live:ev.target.checked});renderSettings();notify('Game binding source updated');}catch(e){notify(e.message,true);}};
 el('add-control-btn').onclick=()=>addControl();
 el('filter-text').oninput=e=>{search=e.target.value;renderBindingRows();};
 el('filter-profile').onchange=e=>{profileFilter=e.target.value;renderBindingRows();};
 renderBindingRows();
}
function renderBindingRows(){const term=search.toLowerCase().trim();const rows=app.controls.filter(c=>(profileFilter==='all'||c.profile===profileFilter)&&(!term||(c.label+' '+c.id+' '+c.section+' '+c.binding).toLowerCase().includes(term)));
 el('binding-results').innerHTML=`<div class="count-caption">${rows.length} CONTROLS</div><div class="binding-list">${rows.map(c=>`<div class="binding-row"><div><div class="binding-name">${esc(c.label)}</div><div class="binding-sub">${esc(c.profile.toUpperCase())} / ${esc(c.section)} · ${esc(c.manual?'MANUAL':c.action_ref?'XML LINKED':'NOT LINKED')}${bindingPeers(c).length?' · SHARED WITH '+esc(bindingPeers(c).join(', ')):''}${bindingConflictLabels(c).length?' · POSSIBLE SHORTCUT OVERLAP: '+esc(bindingConflictLabels(c).join(', ')):''}</div></div><div style="display:flex;align-items:center;gap:10px;min-width:0"><span class="binding-key ${c.binding?'':'empty'}" title="${esc(c.binding_source||'Not mapped')}">${esc(bindingLabel(c))}</span><button data-edit="${esc(c.id)}">EDIT</button></div></div>`).join('')}</div>`;
 el('binding-results').querySelectorAll('[data-edit]').forEach(btn=>btn.onclick=()=>editControl(btn.dataset.edit));
}
async function renderUpdateSettings(){
 el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">SOFTWARE / MAINTENANCE</div><h3>Companion updates</h3><p>Installed on Serenity: <strong>v${esc(app.version||'unknown')}</strong>. Existing controls, keyboard mappings, and pairing stay in your Windows user data folder.</p>
 <div class="update-console"><div class="update-indicator"><span class="update-led"></span><div><strong id="remote-update-title">Checking for releases…</strong><small id="remote-update-info">Public update mirror: GitHub Pages / star-citizen-deck.</small></div></div><button type="button" id="update-fetch" class="primary-btn" disabled>CHECKING…</button></div>
 <div class="modal-actions"><button id="update-check" type="button" class="secondary-btn">CHECK AGAIN</button></div>
 <details class="advanced-update"><summary>Advanced: install a trusted ZIP manually</summary><p>Use this only until the release channel is published or if Serenity cannot access GitHub. Keep the ZIP compressed.</p><div class="field"><label for="update-file">UPDATE PACKAGE (.ZIP)</label><input type="file" id="update-file" class="input" accept=".zip,application/zip"></div><div class="modal-actions"><button id="one-step-update" type="button" class="primary-btn">VERIFY ZIP, INSTALL &amp; RESTART</button></div></details>
 <div id="update-info" class="warning-line">Future updates use verified packages, persistent backups, and a Python import check. Keep START_DECK.bat open.</div></section>`;
 const info=el('remote-update-info'), title=el('remote-update-title'), fetchButton=el('update-fetch');
 async function check(){
  title.textContent='Checking release channel…'; fetchButton.disabled=true; fetchButton.textContent='CHECKING…';
  try {const r=await request('/api/update/check'); title.textContent=r.available?'UPDATE AVAILABLE: v'+r.latest:r.configured?'NO NEW RELEASE':'RELEASE CHANNEL NOT LIVE';
       info.textContent=r.note;fetchButton.disabled=!r.available;fetchButton.textContent=r.available?'INSTALL v'+r.latest:'UP TO DATE / OFFLINE';}
  catch(e){title.textContent='RELEASE CHECK FAILED';info.textContent=e.message;fetchButton.textContent='UNAVAILABLE';}
 }
 el('update-check').onclick=check;
 fetchButton.onclick=async()=>{
  if(!confirm('Install the verified published update and restart the Windows companion?'))return;
  fetchButton.disabled=true;fetchButton.textContent='VERIFYING RELEASE…';
  try{const r=await request('/api/update/fetch',{});await applyAndReconnect(r.version);}
  catch(e){info.textContent=e.message;notify(e.message,true);await check();}
 };
 el('one-step-update').onclick=async()=>{
  const file=el('update-file').files[0];if(!file)return notify('Select the trusted update ZIP first.',true);
  if(file.size>4_000_000)return notify('Update ZIP is larger than 4 MB.',true);
  if(!confirm('Verify this ZIP and install it on Serenity?'))return;
  const button=el('one-step-update');button.disabled=true;button.textContent='VERIFYING & INSTALLING…';
  try {
   const response=await fetch('/api/update/upload',{method:'POST',headers:{'X-Deck-Token':token,'Content-Type':'application/zip'},body:file,cache:'no-store'});
   const result=await response.json();if(!response.ok)throw new Error(result.error||'ZIP upload failed');
   await applyAndReconnect(result.version);
  } catch(e){button.disabled=false;button.textContent='VERIFY ZIP, INSTALL & RESTART';el('update-info').textContent=e.message;notify(e.message,true);}
 };
 async function applyAndReconnect(version){
  await request('/api/update/apply',{confirm:'INSTALL'});
  el('update-info').textContent='Installing v'+version+' on Serenity. Waiting for the companion to reconnect…';
  const started=Date.now();
  while(Date.now()-started<40000){
   await new Promise(resolve=>setTimeout(resolve,1250));
   try{const response=await fetch('/api/hello',{cache:'no-store'});if(!response.ok)continue;
       const state=await response.json();if(state.version===version){window.location.reload();return;}}
   catch(_){ /* Installer momentarily stops the old server. */ }
  }
  el('update-info').textContent='The restart has not been confirmed. Check the companion window on Serenity before trying again.';
 }
 await check();
}
function renderConnectionSettings(){
 el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">01 / INPUT SAFETY</div><h3>Live keyboard output</h3><p>Every button sends one user-requested keyboard press to the foreground Star Citizen window only. The deck never reads game memory, modifies game files, or runs automatic command sequences.</p>
 <div class="toggle-row"><div class="setting-meta"><strong>Arm keyboard controls</strong><small>Resets to OFF whenever you restart the companion. Available on Windows only.</small></div><input id="arm-toggle" class="ios-switch" type="checkbox" ${app.armed?'checked':''} ${!app.can_send?'disabled':''} aria-label="Arm keyboard output"></div>
 <div class="warning-line">CURRENT INPUT METHOD: <b>${esc(app.input_mode==='scan'?'SCAN-CODE TEST':'VIRTUAL KEY')}</b>. Scan-code mode was selected automatically on the v0.2.4 upgrade, with no extra setting needed.</div>
 <div class="field"><label>GAME KEYBOARD DELIVERY</label><select id="input-mode" class="input" ${app.can_send?'':'disabled'}><option value="virtual" ${(app.input_mode||'virtual')==='virtual'?'selected':''}>Standard virtual-key (original)</option><option value="scan" ${app.input_mode==='scan'?'selected':''}>Physical scan-code (test)</option></select><p class="hint">Star Citizen may process scan codes differently from virtual-key events. Both use Windows SendInput; neither guarantees the game will accept a command. Notepad diagnostic remains unchanged.</p></div>
 <div class="warning-line">${app.can_send?'Input is supported by this Windows companion, but compatibility with the game and its anti-cheat is not guaranteed.':'This preview is running on '+esc(app.system)+'. Live key input requires running the companion on Windows.'}</div><div class="toggle-row"><div class="setting-meta"><strong>Start companion automatically when signing in to Windows</strong><small>One-time setup on Serenity. No administrator access required. The companion runs before Star Citizen opens, so you won't need the BAT file each session. You still arm controls manually.</small></div><input id="autostart-toggle" class="ios-switch" type="checkbox" ${app.start_at_login?'checked':''} ${!app.can_send?'disabled':''} aria-label="Start Windows companion when signing in"></div></section>
 <section class="settings-card"><div class="settings-heading">02 / SAFE WINDOWS DIAGNOSTIC</div><h3>Notepad keyboard test</h3><p>Open Notepad on Serenity, click into a blank document, and keep it in the foreground. This sends exactly one <b>L</b> keystroke only if Windows confirms the foreground process is Notepad. Normal ship controls remain Star Citizen-only.</p>
 <div class="modal-actions"><button id="notepad-test" type="button" class="secondary-btn" ${app.can_send?'':'disabled'}>SEND TEST L TO NOTEPAD</button></div>
 <div id="notepad-result" class="warning-line">Requires keyboard output ARMED. The diagnostic is never sent to Star Citizen.</div></section>
 <section class="settings-card"><div class="settings-heading">03 / LOCAL GAME LOG</div><h3>Read-only Session Intelligence</h3><p>The companion monitors your latest Game.log for game events. No memory access, game changes, or network uploads. Auto-detection usually finds the game next to your imported keybindings.</p><div class="field"><label>GAME.LOG PATH — OPTIONAL OVERRIDE</label><input id="game-log-path" class="input" type="text" value="${esc(app.game_log_path||'')}" placeholder="Auto-detect from installation" autocomplete="off"></div><div class="modal-actions"><button type="button" id="save-game-log-path" class="secondary-btn">SAVE LOG PATH</button></div><p class="hint">Leave empty for automatic detection. If no events appear, paste the full path to your Star Citizen LIVE/Game.log file.</p></section>
 <section class="settings-card"><div class="settings-heading">04 / DEVICE INFO</div><h3>Serenity companion</h3><div class="toggle-row"><div class="setting-meta"><strong>Platform</strong><small>${esc(app.system)} / Star Citizen Deck companion v${esc(app.version||"unknown")}</small></div><span class="pill">CONNECTED</span></div><div class="toggle-row"><div class="setting-meta"><strong>Game profile</strong><small>${esc(app.profile_label)}</small></div><span class="pill">LOCAL</span></div><div class="toggle-row"><div class="setting-meta"><strong>Saved configuration</strong><small>Persistent on your PC; independent from Mongrel HUD</small></div><span class="pill">LOCAL</span></div></section>`;
 el('save-game-log-path').onclick=async()=>{
  try{app=await request('/api/settings',{game_log_path:el('game-log-path').value});renderConnectionSettings();refreshSession();notify('Game.log path saved; event monitor will refresh.');}
  catch(e){notify(e.message,true);}
 };
 el('notepad-test').onclick=async()=>{
   const target=el('notepad-result');target.textContent='Checking Notepad foreground window and sending one L...';
   try{const result=await request('/api/diagnostic/notepad',{});
     target.textContent='Windows accepted test L. Check whether lowercase l appeared in Notepad. This does not verify Star Citizen input.';
     notify('Notepad diagnostic sent — check Notepad on Serenity');
   }catch(err){target.textContent=err.message;notify(err.message,true);}
 };
 el('input-mode').onchange=async e=>{
   try{app=await request('/api/settings',{input_mode:e.target.value});renderConnectionSettings();updateRail();notify('Input mode set to '+(app.input_mode==='scan'?'physical scan-code test':'standard virtual-key'));}
   catch(err){notify(err.message,true);renderConnectionSettings();}
 };
 el('autostart-toggle').onchange=async e=>{
   try{app=await request('/api/settings',{start_at_login:e.target.checked});renderConnectionSettings();notify(app.start_at_login?'Windows sign-in startup enabled. Companion stays available for Star Citizen.':'Windows sign-in startup disabled. Launch with BAT file when needed.');}
   catch(err){notify(err.message,true);renderConnectionSettings();}
 };
 el('arm-toggle').onchange=async e=>{if(e.target.checked&&!confirm('Arm the deck to send keyboard inputs to Star Citizen when it is in the foreground?')){e.target.checked=false;return;}
 try{app=await request('/api/settings',{armed:e.target.checked});renderConnectionSettings();updateRail();notify(app.armed?'Output ARMED — use caution':'Output safely DISARMED');}catch(err){notify(err.message,true);}};
}
function renderAbout(){el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">CONTROL DECK / BUILD 01</div><h3>Star Citizen Deck v${esc(app.version||"unknown")}</h3><p>Independent personal touchscreen companion for Star Citizen. Built with standard Python and browser technologies, no third-party dependencies, no installation or modification of game files.</p><div class="warning-line">Ship Lights has been confirmed working in Star Citizen on Serenity using scan-code keyboard input. Other commands remain unverified and may be ignored. Use only if allowed by the game's current rules. No macros or repeated unattended automation are implemented.</div></section><section class="settings-card"><h3>Known limits</h3><p>• No official live ship-state feed. Toggles are visual estimates.<br>• Defaults use a pinned 4.10.2 LIVE reference with your active overrides.<br>• Mouse buttons 1–5 and single vertical mouse-wheel steps supported; mouse movement, analog axes, joystick output are not.<br>• Keybinding importer does not change controls inside Star Citizen.<br>• Use on trusted LAN only: HTTP connection is not encrypted.</p></section>`;}
function editControl(id){const c=app.controls.find(x=>x.id===id);if(!c)return;
 const kindOptions=['button','toggle','hold','slider'].map(k=>`<option value="${k}" ${c.kind===k?'selected':''}>${k.toUpperCase()}</option>`).join('');
  const modal=`<div class="modal-wrap"><div class="modal" role="dialog" aria-modal="true" aria-label="Edit control"><div class="eyebrow">BINDING EDITOR / ${esc(c.profile.toUpperCase())}</div><h2>${esc(c.label)}</h2><p>Choose a linked XML action for automatic updates, or enter a keyboard shortcut manually.</p><form id="edit-form"><div class="modal-grid"><div class="field"><label>DISPLAY LABEL</label><input class="input" id="edit-label" value="${esc(c.label)}" required></div><div class="field"><label>CONTROL TYPE</label><select class="input" id="edit-kind">${kindOptions}</select></div></div>
 <div class="modal-grid"><div class="field"><label>PROFILE / PAGE</label><select class="input" id="edit-profile">${app.profiles.map(p=>`<option value="${esc(p.id)}" ${p.id===c.profile?'selected':''}>${esc(p.name)}</option>`).join('')}</select></div><div class="field"><label>CONTROL GROUP / SECTION</label><input class="input" id="edit-section" value="${esc(c.section)}" required></div></div>
 <div class="field"><label>BINDING SOURCE</label><select class="input" id="edit-source"><option value="xml" ${!c.manual?'selected':''}>Imported XML action (auto sync)</option><option value="manual" ${c.manual?'selected':''}>Manual keyboard mapping</option></select></div>
 <div class="field" id="action-field"><label>STAR CITIZEN ACTION ID</label><input class="input" id="edit-action" placeholder="Use Browse Imported Actions below" value="${esc(c.action_ref||'')}" autocapitalize="off" autocomplete="off" spellcheck="false"><div class="action-picker-tools"><button id="browse-actions" type="button" class="secondary-btn">BROWSE ${app.catalog.length} AVAILABLE ACTIONS</button><span class="hint" id="selected-action-status"></span></div><div id="action-picker" class="action-picker" hidden><label for="action-search">SEARCH GAME KEYBINDINGS</label><input class="input" id="action-search" type="search" placeholder="Search name, group or keyboard shortcut" autocomplete="off" autocapitalize="off" spellcheck="false"><div id="action-search-results" class="action-search-results"></div></div><div class="field"><label for="edit-share-action">USE THE SAME GAME ACTION AS ANOTHER CONTROL</label><select class="input" id="edit-share-action"><option value="">Choose a linked control...</option>${app.controls.filter(other=>other.id!==c.id&&!other.manual&&other.action_ref).map(other=>`<option value="${esc(other.id)}">${esc(other.label)} (${esc(other.profile.toUpperCase())})</option>`).join('')}</select></div><p class="hint">Linked controls inherit the same game action and binding. Choosing a manual shortcut affects only this control. Unknown game actions remain unassigned.</p></div>
 <div class="field" id="manual-field"><label>KEY OR MOUSE COMBINATION</label><input class="input" id="edit-manual" placeholder="e.g. LALT+R or F6" value="${esc(c.manual?c.binding:'')}"><p class="hint">Supports keyboard chords, MOUSE1–MOUSE5, MWHEEL_UP/MWHEEL_DOWN and modifier + mouse/wheel. No mouse movement, axes or macros.</p></div>
 <div class="field"><label>TAP DURATION (40–3000 MS) · HOLD CONTROLS RELEASE ON TOUCH-UP</label><input type="number" min="40" max="3000" class="input" id="edit-hold" value="${Number(c.hold_ms)||100}"></div>
 <div id="step-settings" class="modal-grid"><div class="field"><label>SLIDER STEP UP</label><input class="input" id="edit-up" placeholder="e.g. LALT+UP" value="${esc(c.binding_up||'')}"></div><div class="field"><label>SLIDER STEP DOWN</label><input class="input" id="edit-down" placeholder="e.g. LALT+DOWN" value="${esc(c.binding_down||'')}"></div></div>
 <div class="modal-actions">${c.id.startsWith("custom_")?'<button id="edit-delete" type="button" class="danger-btn">DELETE</button>':''}<button id="edit-cancel" type="button" class="secondary-btn">CANCEL</button><button type="submit" class="primary-btn">SAVE CONTROL</button></div></form></div></div>`;
 el('modal-root').innerHTML=modal;
 const updateVisible=()=>{
   const xml=el('edit-source').value==='xml';el('action-field').style.display=xml?'block':'none';el('manual-field').style.display=xml?'none':'block';el('step-settings').style.display=el('edit-kind').value==='slider'?'grid':'none';
 };
 el('edit-source').onchange=updateVisible;el('edit-kind').onchange=updateVisible;updateVisible();
 // iPad Safari does not reliably show HTML datalist suggestions. Use a real, filtered list.
 const picker=el('action-picker');
 const selectedStatus=el('selected-action-status');
 const describeSelected=()=>{
   const ref=el('edit-action').value.trim();
   const found=app.catalog.find(a=>a.ref===ref);
   const others=app.controls.filter(other=>other.id!==c.id&&!other.manual&&other.action_ref===ref).map(other=>other.label);
   const state=!ref?'No action chosen':found?(found.keyboard?'INPUT: '+found.keyboard.replace(/^(kb1_|mo1_)/i,'').toUpperCase()+' ('+(found.origin||'imported')+')':'No supported keyboard/mouse binding'):'Not in the imported game profile';
   selectedStatus.textContent=state+(others.length?' · Linked with '+others.join(', '):'');
 };
 const showImported=()=>{
   const q=el('action-search').value.trim().toLowerCase();
   const matching=app.catalog.map((a,i)=>({...a,idx:i})).filter(a=>(a.ref+' '+a.map+' '+a.name+' '+a.keyboard+' '+(a.raw||[]).join(' ')).toLowerCase().includes(q));
   const html=matching.map(a=>`<button type="button" class="action-option" data-action-index="${a.idx}"><span class="action-title">${esc(a.name.replace(/_/g,' '))}</span><span class="action-ref">${esc(a.ref)}</span><span class="action-binding ${a.keyboard?'':'action-unavailable'}">${esc(a.keyboard?a.keyboard.replace(/^(kb1_|mo1_)/i,'').toUpperCase():'NO SUPPORTED INPUT')} · ${esc(a.origin||'custom')}</span></button>`).join('');
   el('action-search-results').innerHTML=matching.length?html:`<div class="action-empty">No matching actions in your imported 4.10.2 game profile. Assign a game binding and sync, or enter a manual shortcut.</div>`;
   el('action-search-results').querySelectorAll('[data-action-index]').forEach(btn=>btn.onclick=()=>{
     const a=app.catalog[Number(btn.dataset.actionIndex)];
     if(!a)return;
     el('edit-action').value=a.ref;
     picker.hidden=true;
     el('browse-actions').textContent=`BROWSE ${app.catalog.length} AVAILABLE ACTIONS`;
     describeSelected();
   });
 };
 el('browse-actions').onclick=()=>{
   picker.hidden=!picker.hidden;
   el('browse-actions').textContent=picker.hidden?`BROWSE ${app.catalog.length} AVAILABLE ACTIONS`:'CLOSE ACTION LIST';
   if(!picker.hidden){showImported();el('action-search').focus();}
 };
 el('action-search').oninput=showImported;
 el('edit-action').oninput=describeSelected;
 el('edit-share-action').onchange=ev=>{
   const other=app.controls.find(x=>x.id===ev.target.value);
   if(other && !other.manual && other.action_ref){el('edit-action').value=other.action_ref;describeSelected();}
 };
 describeSelected();
 el('edit-cancel').onclick=()=>el('modal-root').innerHTML='';
 if(c.id.startsWith('custom_'))el('edit-delete').onclick=async()=>{if(confirm('Delete this custom control?')){try{await request('/api/control/delete',{id:c.id});app=deckApplyUi(await request('/api/state'));el('modal-root').innerHTML='';render();}catch(e){notify(e.message,true);}}};
 el('edit-form').onsubmit=async e=>{e.preventDefault();const patch={id,label:el('edit-label').value,profile:el('edit-profile').value,section:el('edit-section').value,kind:el('edit-kind').value,hold_ms:Number(el('edit-hold').value)};
 if(el('edit-source').value==='xml')patch.action_ref=el('edit-action').value.trim();else patch.manual_binding=el('edit-manual').value.trim();
 if(patch.kind==='slider'){patch.binding_up=el('edit-up').value.trim();patch.binding_down=el('edit-down').value.trim();}
 try{await request('/api/control',patch);app=deckApplyUi(await request('/api/state'));el('modal-root').innerHTML='';render();notify('Saved '+patch.label);}catch(err){notify(err.message,true);}};
}
window.addEventListener('DOMContentLoaded',startup);

async function addControl(){
 const label=prompt('Name your new control:');if(!label)return;
 const profile=profileFilter==='all'?'home':profileFilter;
 try{const c=await request('/api/control/create',{label,profile});app=deckApplyUi(await request('/api/state'));render();editControl(c.id);}catch(e){notify(e.message,true);}
}


/* Cockpit Concept 02 — integrated with the existing controller's validated actions.
   No synthetic ship telemetry. No change to Windows keyboard injection. */
const cockpitLayouts = {home:'Overview',nav:'Navigation',scm:'Combat',scan:'Scanning',mfd:'MFD Control',systems:'Ship systems',mining:'Mining',foot:'On foot',utility:'Utilities'};
const cockpitOrderKey='scdeck-cockpit-order-v1';
let cockpitArrange=false, cockpitSelected=null;
let cockpitOrder={};
try {
  const saved=JSON.parse(localStorage.getItem(cockpitOrderKey)||'{}');
  if(saved && typeof saved==='object' && !Array.isArray(saved))cockpitOrder=saved;
} catch(_){ cockpitOrder={}; }
function cockpitLookup(id){return app?.controls.find(c=>c.id===id&&c.profile===active);}
function cockpitMeta(c){
  if(!c)return '';
  const assign=c.kind==='slider' ? (c.binding_up||c.binding_down?'STEP MAPPED':'STEP UNMAPPED') : (c.binding?bindingLabel(c):'UNMAPPED');
  return esc(assign);
}
function cockpitPanel(title,num,tag,body,extra=''){
  return `<section class="module ${extra}"><i class="screw"></i><i class="screw right"></i><div class="module-head"><h2>${esc(title)}</h2><small>${esc(num)} &nbsp; / &nbsp; ${esc(tag)}</small></div><div class="module-body">${body}</div></section>`;
}
function cockpitControl(id,kind='pad',sym='✧',style=''){
  const c=cockpitLookup(id);if(!c)return '';
  const name=esc(c.label);const binding=cockpitMeta(c);
  const safety=c.confirm||style==='amber';
  const accessible=`data-control="${esc(c.id)}" title="${name} / ${binding} / ${esc(c.description||'')}" aria-label="${name}: ${binding}"`;
  const mapped=Boolean(c.binding)||Boolean(c.binding_up||c.binding_down);
  const unmap=mapped?'':' unmapped';
  if(c.kind==='slider')return `<div class="slider-control cockpit-slider" data-slider-control="${esc(c.id)}"><div class="slider-title">${name}</div><div class="ctl-mini">STEP COMMANDS ONLY / NO ANALOG AXIS</div><div class="range-steps"><button type="button" data-slider-step="-1" data-step-id="${esc(c.id)}">− STEP</button><button type="button" data-slider-step="1" data-step-id="${esc(c.id)}">+ STEP</button></div><small>${binding}</small></div>`;
  const visualKind=deckUiStyles[c.id]||kind;
  if(visualKind==='switch')return `<button type="button" class="switch-row ${safety?'amber':''}${unmap}" ${accessible}><span class="switch-label"><b>${name}</b><small>${safety?'CONFIRM · ':''}${binding}</small></span><span class="mechanism"><span class="lever"></span><i class="lamp"></i></span></button>`;
  if(visualKind==='choice')return `<button type="button" class="power-choice${unmap}" ${accessible}><span><b>${name}</b><small>${binding}</small></span><span class="chev">›</span></button>`;
  const decor=safety?'amber':style;
  return `<button type="button" class="pad ${decor}${unmap}" ${accessible}><i class="pad-led"></i><span class="pad-icon">${safety?'⛨':sym}</span><b>${name}</b><small>${safety?'CONFIRM · ':''}${c.kind==='hold'?(mapped?'TOUCH + HOLD':'UNMAPPED'):binding}</small></button>`;
}
function cockpitBig(id,caption,secondary=false){
  const c=cockpitLookup(id);if(!c)return '';
  return `<button type="button" class="big-button ${secondary?'secondary':''} ${c.binding?'':'unmapped'}" data-control="${esc(id)}" title="${esc(c.description||c.label)}"><b>${esc(c.label)}</b><span>${esc(c.binding?caption:'UNMAPPED / CONFIGURE IN SETTINGS')}</span></button>`;
}
function cockpitPair(ids,signs=[],style=''){return `<div class="control-grid">${ids.map((id,i)=>cockpitControl(id,'pad',signs[i]||'✧',style)).join('')}</div>`;}
function cockpitDisplay(kind='quantum'){
  const combat=kind==='target';
  return `<div class="display ${combat?'target':''}" aria-label="Schematic only; no live telemetry"><div class="readout-top"><span>${combat?'SENSORS / STANDBY':'NAV COMP / STANDBY'}</span><span>${combat?'NO LOCK DATA':'QUANTUM / UNKNOWN'}</span></div><div class="orbital"><i class="circle"></i><i class="circle two"></i><i class="circle three"></i><i class="sweep"></i><span class="symbol">${combat?'⊕':'⌾'}</span></div><div class="readout-label">${combat?'NO TARGET DATA':'NO ROUTE DATA'}</div><div class="readout-caption">${combat?'TARGET TELEMETRY NOT LINKED':'SHIP TELEMETRY NOT LINKED'}</div><div class="readout-bottom">SCHEMATIC DISPLAY ONLY &nbsp; / &nbsp; SCD-02</div></div>`;
}
function cockpitFooter(){return `<div class="bottom-strip"><div class="mini-module"><span class="mark">✦</span><div><b>INPUT PATH · WINDOWS SCAN-CODE</b><small>Game commands require a mapped control, armed output and Star Citizen in foreground.</small></div><span class="index">AUX 01</span></div><div class="mini-module"><span class="mark">⌁</span><div><b>ACTUAL SHIP STATE · UNKNOWN</b><small>Sending a command does not confirm a toggle, power level or system state.</small></div><span class="index">AUX 02</span></div></div>`;}
const panel=cockpitPanel,ctl=cockpitControl,pair=cockpitPair,display=cockpitDisplay,landingFooter=cockpitFooter;

function navScreen(){return `<div class="dashboard">
 ${panel('Flight control','01','MOBILITY',`<div class="microhead"><span>FLIGHT CONTROL MATRIX</span><span>SCM / NAV</span></div><div class="control-block">${['nav_cruise','nav_decouple','nav_vtol','nav_gear'].map(id=>ctl(id,'switch')).join('')}</div><div class="module-bottom">${pair(['nav_mode','nav_speed_reset'],['↔','↺'])}<div class="microhead"><span>SPEED LIMIT</span><span>STEP / TAP</span></div>${pair(['nav_speed_down','nav_speed_up'],['−','+'])}</div>`)}
 ${panel('Quantum operations','02','TRANSIT',`<div id="quantum-intelligence">${quantumIntelligenceHTML()}</div><div class="two-action">${cockpitBig('nav_spool','PREPARE QUANTUM',true)}${cockpitBig('nav_quantum','TOUCH + HOLD',false)}</div><div class="two-action">${cockpitBig('nav_cancel','SINGLE INPUT',true)}${cockpitBig('nav_request','LANDING SERVICES',true)}</div><div class="microhead"><span>STARMAP / CONTRACTS</span><span>IN-GAME UI</span></div>${pair(['nav_starmap','nav_mobiglas'],['⌖','▣'])}<div class="microhead"><span>DIRECT OPERATOR MODE</span><span>USER-BOUND</span></div>${pair(['nav_quantum_direct','nav_flight_direct'],['◈','➤'])}<p class="subtle-note">A map shortcut opens the map; it cannot identify or automatically route to a mission. Direct mode controls require an in-game binding if shown unmapped.</p>`)}
 ${panel('Power distribution','03','ENERGY',`<div class="statlines"><div class="statline"><b>THRUSTER DISTRIBUTION</b><span>UNKNOWN</span></div><div class="statline"><b>SHIELD DISTRIBUTION</b><span>UNKNOWN</span></div><div class="statline"><b>WEAPON DISTRIBUTION</b><span>UNKNOWN</span></div></div><div class="microhead"><span>FOCUS COMMANDS</span><span>MANUAL</span></div><div class="control-block">${['nav_power_thrusters','nav_power_shields','nav_power_weapons','nav_power_reset'].map(id=>ctl(id,'choice')).join('')}</div><div class="microhead"><span>CYCLE OPERATOR MODE</span><span>ONE STEP PER TAP</span></div>${pair(['nav_operator_next','nav_operator_prev'],['▸','◂'])}<p class="subtle-note">Cycles available operating modes, not a confirmed QT/FLT status. Previous mode has no default key.</p><p class="subtle-note">Distribution percentages deliberately hidden: no live data source is connected.</p>`)}
 </div>${landingFooter()}`;}
function scmScreen(){return `<div class="dashboard">
 ${panel('Target acquisition','01','SENSORS',`<div class="microhead"><span>CONTACT / SELECTION</span><span>MANUAL</span></div>${pair(['scm_hostiles','scm_nearest'],['◎','◉'])}${pair(['scm_lock1','scm_lock2'],['①','②'])}<div class="module-bottom"><p class="subtle-note">The targeting reticle is a visual instrument. Target selections cannot be confirmed without game telemetry.</p></div>`)}
 ${panel('Combat operations','02','WEAPONS',`${display('target')}<div class="two-action">${cockpitBig('scm_aimmode','CYCLE',true)}${cockpitBig('scm_missiles','SINGLE INPUT',false)}</div>`)}
 ${panel('Defense matrix','03','PROTECTION',`<div class="microhead"><span>COUNTERMEASURES</span><span>CMD</span></div>${pair(['scm_decoy_less','scm_decoy','scm_decoy_more'],['−','✹','+'])}${pair(['scm_noise'],['◈'])}<div class="microhead"><span>POWER / DEFENSE</span><span>FOCUS</span></div>${['scm_shields','scm_weapons','scm_reset','scm_shield_reset'].map(id=>ctl(id,'choice')).join('')}<p class="subtle-note">These are command senders, not shield or weapon-state indicators.</p>`)}
 </div>${landingFooter()}`;}

function scanScreen(){return `<div class="dashboard scan-suite">
 ${panel('Scan operations','01','ACTIVE SCANNING',`<div class="microhead"><span>MODE / SCAN / PING</span><span>DIRECT INPUT</span></div>${pair(['scan_mode','scan_trigger','scan_ping'],['◈','◎','⌁'])}<p class="subtle-note">SCAN TARGET and RADAR PING use touch-and-hold. Ship telemetry and scan results are not available to this controller.</p>`)}
 ${panel('Scanning angle','02','ADJUST',`<div class="microhead"><span>SCAN CONE ANGLE</span><span>ONE STEP PER TAP</span></div>${pair(['scan_focus_less','scan_focus_more'],['−','+'])}<p class="subtle-note">Uses your current binding. Star Citizen defaults these actions to mouse wheel down/up; each tap sends one step.</p>`)}
 ${panel('Scan display navigation','03','CONTACT DATA',`<div class="microhead"><span>SCAN TABS</span><span>PREV / NEXT</span></div>${pair(['scan_tab_prev','scan_tab_next'],['◂','▸'])}<div class="microhead"><span>SCAN PAGES</span><span>PREV / NEXT</span></div>${pair(['scan_page_prev','scan_page_next'],['◂','▸'])}<div class="microhead"><span>CONTACTS</span><span>PREV / NEXT</span></div>${pair(['scan_contact_prev','scan_contact_next'],['◂','▸'])}<div class="microhead"><span>CONTACT PAGES</span><span>PREV / NEXT</span></div>${pair(['scan_contact_page_prev','scan_contact_page_next'],['◂','▸'])}`)}
 </div>${landingFooter()}`;}
function mfdScreen(){return `<div class="dashboard mfd-suite">
 ${panel('Select a cockpit display','01','FOCUS',`<div class="microhead"><span>FIRST SELECT AN MFD</span><span>STEP 1</span></div>${pair(['mfd_primary','mfd_cast_left','mfd_cast_right'],['▣','◂','▸'])}<div class="microhead"><span>NUMBERED SLOTS</span><span>1–10</span></div><div class="control-grid mfd-slots">${Array.from({length:10},(_,i)=>ctl('mfd_'+(i+1),'pad',String(i+1))).join('')}</div><p class="subtle-note">MFD focus shortcuts are unassigned in the 4.10.2 defaults. Configure only the displays you use, in the game keybindings.</p>`)}
 ${panel('Choose a screen','02','PAGE',`<div class="microhead"><span>THEN CHOOSE A VIEW</span><span>STEP 2</span></div><div class="control-grid mfd-pages">${['mfd_self','mfd_target','mfd_scanning','mfd_config','mfd_comms','mfd_ifcs','mfd_diagnostics','mfd_resources'].map(id=>ctl(id,'pad','▤')).join('')}</div><p class="subtle-note">Screen shortcuts are also unbound by default. Selecting a page sends one game action to the focused MFD; it does not detect or remember the ship's display state.</p>`)}
 ${panel('Cycle the focused display','03','ALTERNATIVE',`<div class="microhead"><span>PREVIOUS / NEXT PAGE</span><span>DEFAULT BINDINGS</span></div>${pair(['mfd_page_prev','mfd_page_next'],['◂','▸'])}<p class="subtle-note">LALT+Q / LALT+E are the 4.10.2 default cycle shortcuts. Your live game overrides still take precedence.</p>`)}
 </div>${landingFooter()}`;}
function sysDockingControlIds(){
 // Use the existing custom control on Serenity, not a new hardcoded binding.
 // The control ID, shortcut and action mapping remain server-owned.
 return (app?.controls||[]).filter(c=>
  c.profile==='systems' && c.id.startsWith('custom_') && c.kind!=='slider' &&
  (/(^|[^a-z])dock(ing)?([^a-z]|$)/i.test(c.label||'') ||
   (/(^|[^a-z])snub([^a-z]|$)/i.test(c.label||'') &&
    /(^|[^a-z])(land(ing)?|dock(ing)?)([^a-z]|$)/i.test(c.section||'')))
 ).map(c=>c.id);
}
function sysScreen(){return `<div class="dashboard systems">
 ${panel('Electrical bus','01','CORE',`<div class="microhead"><span>HARDWARE COMMANDS</span><span>MANUAL</span></div><div class="control-block">${['ship_power','engine_power','sys_shields','sys_weapons','sys_lights'].map(id=>ctl(id,'switch')).join('')}</div><div class="module-bottom">${pair(['sys_flight_ready'],['ϟ'])}</div>`)}
 ${panel('Access & hatches','02','GUARDED',`<div class="guard-hardware"><div class="guard-symbol">⌑</div><div class="guard-desc">SAFETY COVER / CONFIRM BEFORE ACTION</div>${pair(['open_all_doors','close_all_doors'],['↟','↡'],'amber')}</div><div class="control-block">${['sys_lock','sys_ramp'].map(id=>ctl(id,'switch')).join('')}</div><p class="subtle-note">Guard confirmation will be required when the real controller is armed.</p>`)}
 ${panel('Landing config','03','GROUND',`<div class="microhead"><span>LANDING SUPPORT</span><span>CMD</span></div><div class="control-block">${['sys_gear','sys_vtol',...sysDockingControlIds()].map(id=>ctl(id,'switch')).join('')}</div><div class="module-bottom">${pair(['sys_atc'],['⌂'],'accent')}</div><div class="statlines"><div class="statline"><b>LANDING GEAR</b><span>UNKNOWN</span></div><div class="statline"><b>VTOL STATE</b><span>UNKNOWN</span></div></div>`)}
 </div>${landingFooter()}`;}
function miningScreen(){return `<div class="dashboard mining">
 ${panel('Laser operations','01','EXTRACTION',`<div class="microhead"><span>INDUSTRIAL INPUT</span><span>CMD</span></div>${pair(['mine_mode','mine_laser'],['◆','⇧'])}${pair(['mine_switch','mine_ping'],['↻','⌁'])}${pair(['mine_gimbal'],['⊕'])}<p class="subtle-note">Controls send your assigned keyboard or mouse inputs only while armed.</p>`)}
 ${panel('Laser output','02','REFERENCE',`<div class="range-display"><span class="range-label">LOCAL VISUAL REFERENCE</span><span class="range-value" id="range-value">${localSliders['mining_power']??37}<span style="font-size:28px">%</span></span><span class="subtle-note">NOT A LIVE LASER POWER READING</span></div><input class="range-slider" type="range" min="0" max="100" value="${localSliders['mining_power']??37}" id="power-slider" data-source-control="mining_power" aria-label="Local example slider"><div class="range-steps"><button data-slider-step="-1">− STEP</button><button data-slider-step="1">+ STEP</button></div><p class="subtle-note">Dragging is preview-only. The real deck's ± step keys send a single mapped keystroke, if configured.</p>`)}
 ${panel('Consumables','03','UTILITY',`<div class="microhead"><span>ASSIGNABLE SLOTS</span><span>3 BANKS</span></div>${pair(['mine_slot1','mine_slot2'],['Ⅰ','Ⅱ'])}${pair(['mine_slot3'],['Ⅲ'])}<div class="module-bottom"><div class="statline"><b>LASER HEAT</b><span>UNKNOWN</span></div><div class="statline"><b>ROCK STABILITY</b><span>UNKNOWN</span></div><div class="statline"><b>RESOURCES</b><span>UNKNOWN</span></div></div>`)}
 </div>${landingFooter()}`;}
function genericScreen(){
 const mine=app.controls.filter(c=>c.profile===active&&!c._deckHidden);
 const groups=[...new Set(mine.map(c=>c.section))];
 const banks=groups.map((g,i)=>panel(g,String(i+1).padStart(2,'0'),'CONTROL BANK',`<div class="control-grid">${mine.filter(c=>c.section===g).map(c=>active==='home'&&g==='Quick actions'?ctl(c.id,'pad'):c.kind==='toggle'?ctl(c.id,'switch'):ctl(c.id)).join('')}</div>`)).join('');
 const session=panel('Session intelligence','03','GAME.LOG',`<div id="session-intelligence">${sessionIntelligenceHTML()}</div>`,active==='home'?'home-session-panel':'');
 // Home is a command surface first: ship specifications follow the control banks.
 const ship=active==='home'?'<section id="ship-intelligence" class="ship-banner" aria-label="Ship intelligence">'+shipIntelligenceHTML()+'</section>':'';
 return `<div class="dashboard generic ${active==='home'?'home-dashboard':''}">${banks}${ship}${session}</div>${landingFooter()}`;
}

function renderCockpitContent(){
  const main=el('main-area');
  const selected=app.profiles.find(p=>p.id===active); if(!selected)return;
  const title=cockpitLayouts[active]||selected.name;
  cockpitSelected=null;
  const layout=(active==='nav'?navScreen():active==='scm'?scmScreen():active==='systems'?sysScreen():active==='mining'?miningScreen():active==='scan'?scanScreen():active==='mfd'?mfdScreen():genericScreen());
  const homeCompact=active==='home';
  const heading=homeCompact?'HOME / FLIGHT CONTROLS':esc(selected.short||active.toUpperCase())+' / '+esc(title.toUpperCase());
  main.innerHTML=`<section class="cockpit2">
    <div class="cockpit2-heading compact-profile-heading ${homeCompact?'home-compact-heading':''}"><div class="eyebrow">${heading}</div><div class="lab-heading-actions"><button type="button" id="cockpit-edit" class="secondary-btn ${deckEditMode?'deck-edit-active':''}" aria-pressed="${deckEditMode}">${deckEditMode?'✓ EDIT MODE ON':'✎ EDIT MODE'}</button><button type="button" id="cockpit-arrange" class="secondary-btn" aria-pressed="${cockpitArrange}">${cockpitArrange?'✓ FINISH ARRANGING':'◈ ARRANGE CONTROLS'}</button></div></div>
    ${homeCompact?'':''}
    <div id="cockpit-arrange-tools" class="arrange-toolbar ${cockpitArrange?'open':''}"><strong>ARRANGE MODE / THIS iPAD ONLY</strong><span class="hint" id="cockpit-selection">Select a control to move within its bank.</span><button type="button" data-shift="back">◀ MOVE</button><button type="button" data-shift="forward">MOVE ▶</button></div>
    <div id="cockpit-layout" class="cockpit-layout">${layout}</div><div class="cockpit-action-line" id="cockpit-action-line" aria-live="polite">${app.armed?'KEYBOARD OUTPUT ARMED':'OUTPUT DISARMED'} / SHIP STATE NOT VERIFIED</div>
   </section>`;
  const visible=new Set([...main.querySelectorAll('[data-control]')].map(b=>b.dataset.control));
  main.querySelectorAll('[data-source-control],[data-slider-control]').forEach(e=>visible.add(e.dataset.sourceControl||e.dataset.sliderControl));
  const extra=app.controls.filter(c=>c.profile===active && !c._deckHidden && !visible.has(c.id));
  if(extra.length){
    const bank=document.createElement('section');bank.className='module cockpit-extra';
    bank.innerHTML=`<div class="module-head"><h2>Additional controls</h2><small>USER CONFIGURED / ${extra.length}</small></div><div class="module-body"><div class="control-grid">${extra.map(c=>cockpitControl(c.id,c.kind==='toggle'?'switch':'pad')).join('')}</div></div>`;
    main.querySelector('.dashboard').appendChild(bank);
  }
  applyCockpitOrder();
  main.querySelectorAll('[data-control]').forEach(btn=>{
    const id=btn.dataset.control;
    const model=app.controls.find(c=>c.id===id);
    if(model?.kind==='hold'){
      btn.style.touchAction='none';
      btn.onpointerdown=e=>{if(!cockpitArrange&&!deckEditMode){deckFlash(btn);beginTouchHold(id,btn,e);}};
      btn.onpointerup=()=>stopTouchHold(id);
      btn.onpointercancel=()=>stopTouchHold(id);
      btn.onlostpointercapture=()=>stopTouchHold(id);
    }
    btn.onclick=()=>{
      if(cockpitArrange){cockpitSelected=id;
        main.querySelectorAll('.edit-selected').forEach(e=>e.classList.remove('edit-selected'));
        btn.classList.add('edit-selected');
        el('cockpit-selection').textContent=(cockpitLookup(cockpitSelected)?.label||'Control')+' selected';
        return;}
      if(deckEditMode){deckEditControl(id);return;}
      if(model?.kind==='hold')return;
      deckFlash(btn);
      activate(id);
    };
  });
  main.querySelectorAll('[data-slider-step]').forEach(b=>b.onclick=()=>{
    if(cockpitArrange)return;
    if(deckEditMode)return deckEditControl(b.dataset.stepId||'mining_power');
    deckFlash(b);
    activate(b.dataset.stepId||'mining_power',Number(b.dataset.sliderStep)>0?'up':'down');
  });
  const slider=main.querySelector('#power-slider');
  if(slider){slider.oninput=()=>{
    localSliders['mining_power']=Number(slider.value);
    const label=el('range-value');if(label)label.innerHTML=esc(slider.value)+'<span style="font-size:28px">%</span>';
    el('cockpit-action-line').textContent='LOCAL VISUAL REFERENCE ONLY / DRAGGING DOES NOT SEND KEYS';
  };}
  main.querySelectorAll('[data-shift]').forEach(b=>b.onclick=()=>shiftCockpitControl(b.dataset.shift));
  el('cockpit-edit').onclick=()=>{deckEditMode=!deckEditMode;if(deckEditMode)cockpitArrange=false;renderCockpitContent();};
  el('cockpit-arrange').onclick=()=>{cockpitArrange=!cockpitArrange;if(cockpitArrange)deckEditMode=false;renderCockpitContent();};
}
function applyCockpitOrder(){
 const layout=el('cockpit-layout');if(!layout)return;
 const groups=cockpitOrder[active]||{};
 layout.querySelectorAll('.control-grid,.control-block').forEach((parent,index)=>{
  const saved=Array.isArray(groups[index])?groups[index]:[];
  for(const id of saved){const node=[...parent.children].find(child=>child.dataset.control===id);if(node)parent.appendChild(node);}
 });
}
function shiftCockpitControl(direction){
 if(!cockpitSelected)return;
 const layout=el('cockpit-layout');
 const node=[...layout.querySelectorAll('[data-control]')].find(e=>e.dataset.control===cockpitSelected);
 if(!node)return;
 const group=node.parentElement;
 const items=[...group.children].filter(e=>e.dataset.control);
 const index=items.indexOf(node);
 const target=direction==='back'?items[index-1]:items[index+1];
 if(!target)return;
 if(direction==='back')group.insertBefore(node,target);else group.insertBefore(target,node);
 const bank=[...layout.querySelectorAll('.control-grid,.control-block')].indexOf(group);
 if(bank>=0){cockpitOrder[active]??={};cockpitOrder[active][bank]=[...group.children].filter(e=>e.dataset.control).map(e=>e.dataset.control);
  try{localStorage.setItem(cockpitOrderKey,JSON.stringify(cockpitOrder));}catch(_){}
 }
 el('cockpit-selection').textContent='Saved on this iPad only. Game mappings unchanged.';
}


/* Vessel reference and editable build seeds. Verified against Star Citizen 4.10.2-4.10.3
   ship files and reported market listings in November 2026. Prices are estimates. */
const shipLibrary={
 ion:{name:"Ares Star Fighter Ion",short:"Ares Ion",manufacturer:"Crusader Industries",
  role:"Heavy anti-capital fighter",focus:"PvE · occasional PvP",crew:"1",cargo:"Personal storage",
  image:"https://media.starcitizen.tools/9/99/Ares_Ion_in_space_-_Front.jpg",
  source:"https://starcitizen.tools/Ares_Star_Fighter_Ion",
  description:"Single-seat heavy fighter centered on its exclusive Size 7 SF7E laser cannon. This shop-focused plan emphasizes shield recovery, robust power, cooling and sensors.",
  specs:[["PILOT WEAPON","1 × S7 SF7E cannon"],["SHIELDS","2 × S2"],["POWER","2 × S2"],["COOLERS","3 × S2"],["QUANTUM","1 × S2"],["MISSILES","20 × S3 stock capacity"]],
  pros:["Heavy cannon delivers excellent punch against large targets","Signature energy weapon avoids ballistic ammunition costs","Compact one-pilot combat ship"],
  cons:["Not ideal for close dogfights against agile fighters","Bespoke primary weapon limits build flexibility","Requires deliberate positioning in PvP"],
  stock:"Keep the unique SF7E cannon. Retain the two MSD-543 racks and the integrated missile launcher until deciding on a missile strategy."},
 andromeda:{name:"Constellation Mk IV Andromeda",short:"Constellation Andromeda",manufacturer:"Roberts Space Industries",
  role:"Multi-crew gunship / cargo",focus:"PvE · crew combat",crew:"4",cargo:"96 SCU",
  image:"https://cdn.star-citizen.wiki/images/f/f6/RSI_Constellation_Andromeda_Frontansicht_links.jpg",
  source:"https://starcitizen.tools/Andromeda",
  description:"Versatile RSI gunship with four Size 5 pilot weapons, two manned turrets, missile racks, 96 SCU cargo and the P-52 Merlin. This starter plan emphasizes defenses while retaining the stock gun setup.",
  specs:[["PILOT GUNS","4 × S5 CF-557 Galdereen"],["TURRETS","2 × dual S3"],["SHIELD","1 × S3"],["POWER","2 × S2"],["COOLERS","2 × S2"],["CARGO","96 SCU"]],
  pros:["Four strong pilot-operated Size 5 repeaters","Two turrets and docked Merlin support multicrew play","Cargo hold broadens mission options"],
  cons:["Large silhouette and slower handling than fighters","Turrets require crew for best results","Power, cooling and shield choices interact"],
  stock:"Keep the four stock CF-557 pilot repeaters and stock turret guns initially. Baseline shield: 5CA Akura; power: DayBreak pair; coolers: Frost-Star EX pair; quantum: Bolon."},
  gladius:{name:"Aegis Gladius",short:"Gladius",manufacturer:"Aegis Dynamics",
   role:"Light fighter / interceptor",focus:"PvP dogfighting · shop-only",crew:"1",cargo:"0 SCU",
   image:"https://media.starcitizen.tools/1/13/Gladius_in_space_-_Isometric.jpg",
   source:"https://everark-sc.com/en/ships/gladius",
   description:"Agile single-seat Gladius. This 4.10.3 LIVE PvP shopping plan favors matched, fast-projectile Size 3 guns and repeatable shield recovery. All recommended purchases are reported available at in-game shops; no event or loot-only components.",
   specs:[["PILOT GUNS","3 × S3 · 2 Panthers + 1 Mantis stock"],["SHIELDS","2 × S1 · AllStop stock"],["POWER","1 × S1 · Regulus stock"],["COOLERS","2 × S1 · Bracer stock"],["QUANTUM","1 × S1 · Beacon stock"],["RADAR","1 × S1 · Ecouter military C stock"],["MISSILES","2 × S3 Arrester + 4 × S2 Ignite stock"]],
   pros:["Three matching Panther repeaters offer 1,480 m/s projectiles, practical hits against agile opponents and no ballistic rearming","Concord shield alternative can recover faster than the stock AllStop pair","Small profile and agile maneuvering reward accurate positioning and disengagement"],
   cons:["Light hull cannot sustain prolonged trading against heavier fighters","Stock AllStop shields have more maximum HP than buyable Concords; shield swap is a tradeoff, not a strict upgrade","Ballistic alternative has finite ammunition and lower projectile velocity"],
   stock:"The standard Gladius starts with two CF-337 Panther S3 laser repeaters and one Mantis GT-220 S3 Gatling, two AllStop shields, Regulus power plant, Bracer coolers and Beacon quantum drive. Keep the default missile racks: two Size 3 Arrester and four Size 2 Ignite. The AllStop shields are already strong and need not be replaced. Stock radar: S1 Ecouter Military C; V801-11 Military A is a shop-buyable durability/EM-signature refinement, not a verified target-lock range increase."}
};
const shipSeed={
 ion:[
 {id:"i-shield",cat:"Shields",name:"7MA 'Lorica'",size:"S2 · Civilian A",qty:2,price:120000,shop:"Cousin Crow's — Orison",alt:"Omega Pro — New Babbage",image:"https://media.starcitizen.tools/5/5b/7MA_Lorica_SG_in-game_cutout_-_Mesh_BG_SCT_logo.jpg",source:"https://starcitizen.tools/7MA_%27Lorica%27",pro:"Strong S2 civilian shield regeneration and reset timing.",con:"Does not maximize raw shield HP; value is in recovery.",verify:"Shop reports 4.10.2"},
 {id:"i-plant",cat:"Power plants",name:"Genoa",size:"S2 · Industrial A",qty:2,price:451440,shop:"Platinum Bay — Everus Harbor",alt:"Omega Pro — New Babbage (costs more)",image:"https://cdn.star-citizen.wiki/images/e/eb/Genoa.jpg",source:"https://starcitizen.tools/Genoa",pro:"Durable industrial-grade power plant for a systems-heavy loadout.",con:"Expensive and potentially more detectable than quiet alternatives.",verify:"Shop reports 4.10.2"},
 {id:"i-cool",cat:"Coolers",name:"Snowpack",size:"S2 · Industrial A",qty:3,price:172800,shop:"Omega Pro — New Babbage",alt:"Area18 Dumper's Depot (reported)",source:"https://starcitizen.tools/Snowpack",pro:"Strong cooling and durability.",con:"Higher IR/EM signature and draw than low-profile coolers.",verify:"Price 4.10.3; shop reports 2026"},
 {id:"i-qt",cat:"Quantum",name:"Hemera",size:"S2 · Civilian A",qty:1,price:168000,shop:"Cousin Crow's — Orison (earlier listing)",source:"https://starcitizen.tools/Hemera",pro:"High-tier civilian travel drive to compare with the Crossfield.",con:"Current 4.10.3 shop availability unconfirmed; fuel/range may trade off.",verify:"Earlier price / shop; verify"},
 {id:"i-radar",cat:"Radar",name:"V801-12",size:"S2 · Military A",qty:1,price:352000,shop:"Omega Pro — New Babbage",source:"https://starcitizen.tools/V801-12",pro:"Higher-tier radar option for sensor-focused engagements.",con:"Costly; practical sensor benefits vary with mechanics.",verify:"Shop reports 4.10.2"},
 {id:"i-rack",cat:"Missiles",name:"MSD-515 rack",size:"S5 missile rack",qty:1,price:48913,shop:"Crusader Showroom ship weapons — Orison",source:"https://starcitizen.tools/MSD-515_Missile_Rack",pro:"Fits one Size 5 missile on a compatible hardpoint.",con:"Fewer total missiles than the stock multi-missile rack; verify fitment.",verify:"Optional, 4.10.1 price"},
 {id:"i-stalker",cat:"Missiles",name:"Stalker V",size:"S5 missile",qty:1,price:2474,shop:"Orison ship weapons (earlier plan)",source:"https://starcitizen.tools/Stalker_V",pro:"Optional single heavy missile strike.",con:"Limited ammo and current listing not verified.",verify:"Earlier shopping-plan estimate"},
 {id:"i-thunder",cat:"Missiles",name:"Thunderbolt III",size:"S3 missile",qty:4,price:2712,shop:"Orison ship weapons (earlier plan)",source:"https://starcitizen.tools/Thunderbolt_III",pro:"Size 3 alternative for a compatible stock rack.",con:"Pricing and missile balancing may have changed.",verify:"Earlier shopping-plan estimate"}
 ],
 andromeda:[
 {id:"a-shield",cat:"Shields",name:"7CA 'Nargun'",size:"S3 · Civilian A",qty:1,price:240000,shop:"Cousin Crow's — Orison (earlier listing)",alt:"Omega Pro — New Babbage (earlier listing)",source:"https://starcitizen.tools/7CA_%27Nargun%27",pro:"Faster shield regeneration than stock Akura while remaining in the 100,000 HP class.",con:"Current 4.10.3 terminal stock unconfirmed.",verify:"Historical shop price; verify"},
 {id:"a-plant",cat:"Power plants",name:"Genoa",size:"S2 · Industrial A",qty:2,price:451440,shop:"Platinum Bay — Everus Harbor",alt:"Omega Pro — New Babbage",image:"https://cdn.star-citizen.wiki/images/e/eb/Genoa.jpg",source:"https://starcitizen.tools/Genoa",pro:"Durable replacement candidate for the DayBreak pair.",con:"Expensive; evaluate power and emissions versus actual demand.",verify:"Shop reports 4.10.2"},
 {id:"a-cool",cat:"Coolers",name:"Snowpack",size:"S2 · Industrial A",qty:2,price:172800,shop:"Omega Pro — New Babbage",alt:"Area18 Dumper's Depot (reported)",source:"https://starcitizen.tools/Snowpack",pro:"Greater cooling capability than Frost-Star EX.",con:"Higher signature and cooling power use.",verify:"Price 4.10.3"},
 {id:"a-qt",cat:"Quantum",name:"Hemera",size:"S2 · Civilian A",qty:1,price:168000,shop:"Cousin Crow's — Orison (earlier listing)",source:"https://starcitizen.tools/Hemera",pro:"Higher-tier alternative to compare against stock Bolon.",con:"Unconfirmed shop listing in latest patch; compare fuel, range and speed first.",verify:"Earlier price / shop; verify"}
 ],
 gladius:[
  {id:"g-concord",cat:"Shields",name:"7SA 'Concord'",size:"S1 · Civilian A · fast recovery",qty:2,price:60000,shop:"Platinum Bay — Baijini Point, Stanton",alt:"Omega Pro — New Babbage; Cousin Crow's — Orison",source:"https://everark-sc.com/en/components/SHLD_BEHR_S01_7SA_SCItem",
   pro:"3,000 HP and 660/s regeneration per shield, 8.33 s downed restart and 4.17 s damaged restart. Two Concords exchange some stock tank for faster shield recovery and lower power use.",
   con:"Two stock AllStop shields have 3,168 HP each (vs 3,000). Some pilots will prefer to keep both AllStops.",
   verify:"4.10.3 LIVE · 60,000 aUEC each · Baijini reported Nov 19"},
  {id:"g-breton",cat:"Power plants",name:"Breton",size:"S1 · Industrial A",qty:1,price:237600,shop:"Omega Pro — New Babbage, Stanton",alt:"Dumper's Depot — Area18",source:"https://everark-sc.com/en/components/POWR_JUST_S01_Breton_SCItem",optional:true,
   pro:"16 power units and 300 component health; a durable shop-available alternative to the stock Regulus.",
   con:"Expensive. Does not add power output above the stock 16-output Regulus; weigh extra resilience against the price.",
   verify:"4.10.3 LIVE · 237,600 aUEC · New Babbage reported Nov 18"},
  {id:"g-iceplunge",cat:"Coolers",name:"IcePlunge",size:"S1 · Competition C",qty:2,price:22000,shop:"Platinum Bay — HUR-L2, Stanton",alt:"Platinum Bay — Nyx Gateway (Stanton)",source:"https://everark-sc.com/en/components/COOL_ACOM_S01_IcePlunge_SCItem",optional:true,
   pro:"34 cooling each, same as stock Bracer; lower power draw (2 vs 3) and lower EM/IR emissions.",
   con:"Only 69 component HP each and lower distortion resilience; stock military Bracers may be preferable in PvP. Not a cooling-performance upgrade.",
   verify:"4.10.3 LIVE · 22,000 aUEC each · HUR-L2 reported Nov 19"},
  {id:"g-radar",cat:"Radar",name:"V801-11",size:"S1 · Military A · optional PvP",qty:1,price:176000,shop:"Omega Pro — New Babbage, microTech (Stanton)",source:"https://everark-sc.com/en/components/RADR_GRNP_S01_V80111",optional:true,
   pro:"Military A alternative to the stock Ecouter Military C. Component health 690 vs 600 (+15%), EM signature 1,440 vs 1,800 (-20%); same 5 power requirement. Swap-compatible S1 radar slot.",
   con:"Expensive for modest measurable benefits. The current figures do not establish a specific improvement in detection, aim-assist or target-lock range; keep the stock Ecouter if prioritizing other upgrades.",
   verify:"4.10.3 LIVE · Omega Pro report Nov 9, 2026 · 176,000 aUEC"},
  {id:"g-atlas",cat:"Quantum",name:"Atlas",size:"S1 · Civilian A",qty:1,price:84000,shop:"Platinum Bay — HUR-L5, Stanton",source:"https://everark-sc.com/en/components/QDRV_RSI_S01_Atlas_SCItem",optional:true,
   pro:"259,055 km/s quantum speed, 4.2 s spool and 7.6 s cooldown; better travel convenience than Beacon.",
   con:"No direct advantage during an SCM dogfight. Buy after weapons and shields.",
   verify:"4.10.3 LIVE · 84,000 aUEC · HUR-L5 reported Sep 19"},
  {id:"g-thunder",cat:"Missiles",name:"Thunderbolt III Missile",size:"S3 · EM tracking",qty:2,price:523,shop:"Ship Weapons — Pyro Gateway (Stanton)",alt:"Ship Weapons — HUR-L2 (550 aUEC each)",source:"https://everark-sc.com/en/components/MISL_S03_EM_FSKI_Thunderbolt",optional:true,
   pro:"EM-guided alternative to the two stock Size 3 Arrester III missiles; 2,900 listed physical damage and 8 m blast radius.",
   con:"Replaces the S3 CS-guided Arrester pair (3,200 listed damage each). Keep four Size 2 Ignite missiles and original racks.",
   verify:"4.10.3 LIVE · 523 aUEC each · Pyro Gateway reported Oct 30"},
  {id:"g-panther",cat:"Weapons",loadout:"laser",name:"CF-337 Panther Repeater",size:"S3 · laser · buy 1 of 3",qty:1,price:36308,shop:"CenterMass — New Babbage, Stanton",alt:"CenterMass — Area18",source:"https://everark-sc.com/en/components/KLWE_LaserRepeater_S3",
   pro:"Buy one to replace the stock Mantis: three 1,480 m/s energy repeaters, matched shot lead and no ammunition restocks.",
   con:"43.7 alpha per shot, low single-hit impact against some armor thresholds. Stock supplies the other two Panthers.",
   verify:"4.10.3 LIVE · 36,308 aUEC · New Babbage reported Nov 9"},
  {id:"g-mantis",cat:"Weapons",loadout:"ballistic",name:"Mantis GT-220 Gatling",size:"S3 · ballistic · buy 2 of 3",qty:2,price:24045,shop:"Ship Weapons — Crusader Showroom, Orison",alt:"Cousin Crow's — Orison; CenterMass — Area18 (28,116 each)",source:"https://everark-sc.com/en/components/GATS_BallisticGatling_S3",
   pro:"Buy two to match the stock Mantis: three 853.3 listed DPS Gatlings offer high physical-damage pressure and low power draw.",
   con:"32 alpha per shot, 1,332 m/s projectiles, finite ammunition and frequent rearming. Not automatically better than Panthers in light-fighter duels.",
   verify:"4.10.3 LIVE · 24,045 aUEC each · Orison reported Oct 26"}
 ]
};
const shipCategories=["Shields","Power plants","Coolers","Quantum","Radar","Weapons","Missiles","Other"];


/* Andromeda selectable, individually trackable weapon configurations (4.10.3).
 * Common ship upgrades are shared across every configuration. Alternate guns stay
 * in inventory even when the pilot switches the displayed configuration.
 */
const shipLoadouts={
 ion:[{id:"standard",name:"Heavy Fighter",tag:"SF7E + missile systems",summary:"Standard Ares Ion heavy fighter configuration.",pilot:"Fixed 1 × SF7E S7 laser cannon",turrets:"None",practical:"Built for large targets; its unique gun is not interchangeable.",pro:"High single-weapon impact, no ballistic restocks.",con:"Limited options against agile opponents."}],
 andromeda:[
  {id:"balanced",name:"Balanced PvE",tag:"Stock repeaters · everyday",summary:"Retain the stock pilot guns and turrets; a dependable starting point for PvE contracts and occasional defensive PvP.",
   pilot:"4 × CF-557 Galdereen S5 laser repeaters (already fitted)",
   turrets:"4 × CF-337 Panther S3 laser repeaters (already fitted)",
   practical:"No gun purchases needed. Maintain the original four S5 pilot mounts and both S3 manned turrets.",
   pro:"Good sustained laser fire and projectile velocity. No ballistic ammunition cost. Zero gun-upgrade cost.",
   con:"Not the strongest single-volley impact and no dedicated disabling damage."},
  {id:"disable",name:"Disabling / Capture",tag:"2 distortion cannons · crew",summary:"Keep the four stock S5 pilot guns. Swap both guns on one manned turret for S3 Suckerpunch-XL distortion cannons.",
   pilot:"4 × CF-557 Galdereen S5 laser repeaters (stock)",
   turrets:"Upper manned turret: 2 × Suckerpunch-XL S3 distortion cannons; lower turret: 2 × CF-337 Panthers (stock)",
   practical:"Requires a turret gunner to aim and fire the distortion cannons. Suckerpunch-XL effective range is about 1.8 km; it drains systems rather than hull. Disabling effectiveness depends on target and current tuning.",
   pro:"Adds non-lethal subsystem-disruption capability while preserving all four pilot laser repeaters.",
   con:"Not usable as a dedicated distortion setup when flying solo. More coordination and short-range accuracy required."},
  {id:"ballistic",name:"Ballistic Brawler",tag:"4 × AD5B · pressure",summary:"Swap the four S5 pilot guns for AD5B ballistic gatlings for hard-hitting, sustained physical damage.",
   pilot:"4 × AD5B Size 5 ballistic gatlings",
   turrets:"4 × CF-337 Panther S3 laser repeaters (stock)",
   practical:"One AD5B per pilot S5 mount. Shop-reported Orison price: 121,735 aUEC each. Inventory counts persist when you change loadouts.",
   pro:"Excellent direct damage and low weapons power draw; rewarding for close-to-midrange PvE combat.",
   con:"Requires ammunition and restocking; gun choice makes long uninterrupted sessions less convenient."},
  {id:"precision",name:"Heavy-Target Precision",tag:"4 × M7A · alpha",summary:"Use four Size 5 Behring M7A laser cannons for deliberate, higher-impact volleys against larger PvE targets.",
   pilot:"4 × Behring M7A S5 energy cannons",
   turrets:"4 × CF-337 Panther S3 laser repeaters (stock)",
   practical:"Four matching cannons avoid mixed projectile leads; plan for lower projectile velocity than the stock repeaters.",
   pro:"Powerful single-shot damage, no ballistic ammunition expense, and strong focused-fire potential.",
   con:"Slower follow-up shots and less forgiving aim against fast fighters; higher acquisition cost."}

 ],
 gladius:[
  {id:"laser",name:"Laser Interceptor",tag:"3 × Panther · recommended",summary:"Preferred light-fighter PvP configuration. Keep the factory Panthers and replace the original Mantis with one additional CF-337 S3.",
   pilot:"3 × CF-337 Panther S3 laser repeaters (2 stock + 1 purchased)",turrets:"None · one pilot",
   practical:"Matched 1,480 m/s projectiles simplify lead calculations. Try stock AllStops first, then choose between their higher capacity and the buyable Concords' faster recovery.",
   pro:"Consistent lead and hits against agile opponents; no ammo restocking.",
   con:"Low per-shot alpha; depends on accuracy and disengaging to recharge."},
  {id:"ballistic",name:"Ballistic Pressure",tag:"3 × Mantis · close range",summary:"High-rate-of-fire alternative for brief close combat. Retain the factory Mantis and buy two more from shops.",
   pilot:"3 × Mantis GT-220 S3 ballistic Gatlings (1 stock + 2 purchased)",turrets:"None · one pilot",
   practical:"1,332 m/s projectiles and 1,600 RPM each reward close-range tracking. Armor thresholds, shields and ammunition limit practical DPS.",
   pro:"High listed burst DPS, low power draw, affordable matching guns and physical-damage pressure.",
   con:"Finite ammunition, slower projectiles, low 32 alpha per round and rearm stops."}
 ]
};
const validShipLoadout=(ship,id)=>shipLoadouts[ship]?.some(x=>x.id===id);
shipLibrary.ion.image="https://media.starcitizen.tools/7/79/Ares_ION_Firing_Concept.jpg";
shipLibrary.andromeda.image="https://robertsspaceindustries.com/i/f0849b37f272a9b2082fa321bf708a2f2678bd0c/resize%281500%2C643%2Ccrop%283840%2C1645%2C329%2C0%2CADdPNihJzmPbNuTnFsH1DqUeqBRpXdSXVVtgJTyDDgscGKrzJuoFjReseeMUUrjZ3TdRz4XZrMKyTPp8RTLWuzRTU%29%29/75/constellationandromeda-4k-072020-min.webp";
shipLibrary.andromeda.specs.push(["MISSILES","52 stock · 24 × S2 + 28 × S1"]);
shipLibrary.andromeda.stock+=" Stock missile capacity is 52 (24 Size 2 and 28 Size 1).";
shipLibrary.ion.stock+=" Stock missile capacity is 20 Size 3 across three racks (12 internal, 8 on replaceable racks).";
shipSeed.andromeda.push(
 {id:"a-suckerxl",cat:"Weapons",loadout:"disable",name:"Suckerpunch-XL Cannon",size:"S3 · Distortion cannon · manned turret",qty:2,price:94920,
  shop:"Cousin Crow's — Orison",alt:"New Babbage, MIC-L2 and Grim HEX also reported",image:"https://cdn.star-citizen.wiki/images/8/8e/Suckerpunch-XL_Cannon.jpg",
  source:"https://starcitizen.tools/Suckerpunch-XL_Cannon",
  pro:"Drains target ship systems without relying on hull damage; useful to help disable a vessel.",
  con:"Requires a manned turret gunner. About 1,801 m listed range, slower 1,066 m/s projectiles; cannot deliver this distortion damage from the solo pilot seat in this configuration.",
  verify:"4.10.3 game data; shop price/location reported via EverArk/Citadel"},
 {id:"a-ad5b",cat:"Weapons",loadout:"ballistic",name:"AD5B Ballistic Gatling",size:"S5 · Pilot gun",qty:4,price:121735,
  shop:"Ship Weapons — Crusader Showroom, Orison",alt:"CenterMass — Area18 (reported)",source:"https://everark-sc.com/en/components/BEHR_BallisticGatling_S5",
  pro:"Strong ballistic output, low power draw and large per-gun ammunition supply (reported 5,004).",
  con:"Needs rearming, and kinetic performance against armor may differ from laser setup.",
  verify:"4.10.3 game data; Orison market report"},
 {id:"a-m7a",cat:"Weapons",loadout:"precision",name:"Behring M7A Cannon",size:"S5 · Pilot energy cannon",qty:4,price:380430,
  shop:"Ship Weapons — Crusader Showroom, Orison",alt:"Other sellers may be cheaper; verify terminal",source:"https://starcitizen.tools/M7A_Cannon",
  pro:"High alpha per hit (reported ~922); focused energy fire, no physical ammunition.",
  con:"~1,112 m/s projectiles are slower than stock repeaters (~1,390 m/s); requires better lead and tracking.",
  verify:"4.10.3 game stats; Orison market report"}
);


/* Ship Information — saved locally as part of Layout Lab exports. */
'use strict';
let shipSelected="ion",shipTab="overview";
let shipTracker={ion:{owned:{},notes:{},shipNotes:"",loadout:"standard",loadoutNotes:{},custom:[]},andromeda:{owned:{},notes:{},shipNotes:"",loadout:"balanced",loadoutNotes:{},custom:[]},gladius:{owned:{},notes:{},shipNotes:"",loadout:"laser",loadoutNotes:{},custom:[]}};
const shipExpandedParts=new Set(),shipExpandedGroups=new Set(["ion:Shields","andromeda:Shields","gladius:Shields"]);
const shipURL=x=>typeof x==="string"&&/^https:\/\/[^ "'<>]+$/i.test(x)&&x.length<650?x:"";
const shipText=(x,max=500)=>String(x||"").slice(0,max);
const shipMoney=n=>n>0?Number(n).toLocaleString("en-US")+" aUEC":"Price TBD";
function shipStateNormalize(input){
 const out={};
 for(const ship of Object.keys(shipLibrary)){
  const raw=input&&typeof input==="object"&&input[ship]&&typeof input[ship]==="object"?input[ship]:{};
  const custom=[];
  if(Array.isArray(raw.custom))for(const item of raw.custom.slice(0,40)){
   if(!item||!/^c-[a-z0-9-]{4,40}$/.test(item.id||""))continue;
   if(custom.some(i=>i.id===item.id)||!String(item.name||"").trim())continue;
   custom.push({id:item.id,name:shipText(item.name,90),cat:shipCategories.includes(item.cat)?item.cat:"Other",
    size:shipText(item.size,70),qty:Math.max(1,Math.min(24,Number(item.qty)||1)),
    price:Math.max(0,Math.min(50000000,Math.round(Number(item.price)||0))),
    shop:shipText(item.shop,180),alt:shipText(item.alt,180),image:shipURL(item.image),source:shipURL(item.source),
    loadout:validShipLoadout(ship,item.loadout)?item.loadout:"shared",
    pro:shipText(item.pro),con:shipText(item.con),verify:"My added part"});
  }
  const owned={},notes={};
  for(const item of [...shipSeed[ship],...custom]){
   if(Array.isArray(raw.owned?.[item.id]))
    owned[item.id]=Array.from({length:item.qty},(_,index)=>raw.owned[item.id][index]===true);
   if(typeof raw.notes?.[item.id]==="string")notes[item.id]=raw.notes[item.id].slice(0,3000);
  }
  const loadout=validShipLoadout(ship,raw.loadout)?raw.loadout:shipLoadouts[ship][0].id;
  const loadoutNotes={};
  if(raw.loadoutNotes&&typeof raw.loadoutNotes==="object")for(const preset of shipLoadouts[ship]){
   if(typeof raw.loadoutNotes[preset.id]==="string")loadoutNotes[preset.id]=raw.loadoutNotes[preset.id].slice(0,5000);
  }
  out[ship]={owned,notes,shipNotes:shipText(raw.shipNotes,8000),custom,loadout,loadoutNotes};
 }
 return out;
}
const shipItems=id=>[...shipSeed[id],...shipTracker[id].custom].filter(p=>!p.loadout||p.loadout==="shared"||p.loadout===shipTracker[id].loadout);
const shipFlags=(id,item)=>Array.from({length:item.qty},(_,i)=>shipTracker[id].owned[item.id]?.[i]===true);
function shipTotals(id){
 let all=0,done=0,cost=0,left=0,coreCost=0,optionalCost=0;
 for(const item of shipItems(id)){
  const bought=shipFlags(id,item).filter(Boolean).length;
  all+=item.qty;done+=bought;cost+=item.price*item.qty;left+=item.price*(item.qty-bought);if(item.optional)optionalCost+=item.price*item.qty;else coreCost+=item.price*item.qty;
 }
 return {all,done,cost,left,coreCost,optionalCost};
}
function shipPartCard(id,item){
 const flags=shipFlags(id,item),done=flags.filter(Boolean).length;
 const photo=shipURL(item.image)?'<img class="ship-part-image" src="'+esc(item.image)+'" alt="'+esc(item.name)+' component" loading="lazy">':"";
 const source=shipURL(item.source)?'<a href="'+esc(item.source)+'" target="_blank" rel="noopener noreferrer">COMPONENT REFERENCE</a>':"";
 const boxes=flags.map((checked,i)=>'<label class="ship-unit '+(checked?"checked":"")+'"><input type="checkbox" data-ship-unit="'+esc(item.id)+'" data-index="'+i+'" '+(checked?"checked":"")+' aria-label="'+esc(item.name)+' unit '+(i+1)+'"><span>'+(i+1)+'</span></label>').join("");
 const remove=item.id.startsWith("c-")?'<button type="button" class="ship-remove" data-ship-remove="'+esc(item.id)+'">REMOVE CUSTOM PART</button>':"";
 return '<details class="ship-part" data-ship-detail="'+esc(item.id)+'" '+(shipExpandedParts.has(id+":"+item.id)?"open":"")+'>'
  +'<summary><span class="ship-part-name"><b>'+esc(item.name)+'</b><small>'+esc((item.optional?'OPTIONAL · ':'')+item.size)+'</small></span>'
  +'<span class="ship-part-price">'+shipMoney(item.price)+' <small>each</small></span>'
  +'<span class="ship-part-progress '+(done===item.qty?"complete":"")+'">'+done+' / '+item.qty+' purchased</span></summary>'
  +'<div class="ship-part-detail"><div class="ship-item-identity">'+photo+'<div><div class="ship-detail-row"><small>WHERE TO BUY</small><b>'+esc(item.shop||"Not entered")+'</b></div>'
  +(item.alt?'<p>'+esc(item.alt)+'</p>':"")+'<div class="ship-detail-row"><small>PRICE PER UNIT</small><b>'+shipMoney(item.price)+'</b></div>'
  +'<small>'+esc(item.verify||"Estimate")+'</small><div class="ship-link">'+source+'</div></div></div>'
  +'<div class="ship-procons"><div><h4>PROS</h4><p>'+esc(item.pro||"Add advantages to your notes.")+'</p></div><div><h4>CONS / TRADEOFFS</h4><p>'+esc(item.con||"Add tradeoffs to your notes.")+'</p></div></div>'
  +'<div class="ship-purchased"><b>PURCHASED · '+done+' OF '+item.qty+'</b><div class="ship-unit-list">'+boxes+'</div></div>'
  +'<label class="ship-note-label">MY NOTES<textarea rows="2" data-ship-part-note="'+esc(item.id)+'" placeholder="Build and installation notes…">'+esc(shipTracker[id].notes[item.id]||"")+'</textarea></label>'+remove+'</div></details>';
}
function renderShipInfo(){
 const id=shipSelected,ship=shipLibrary[id],parts=shipItems(id),tot=shipTotals(id);
 const shipTabs=Object.keys(shipLibrary).map(k=>'<button type="button" data-ship-choice="'+k+'" class="'+(k===id?"active":"")+'">'+esc(shipLibrary[k].short)+'</button>').join("");
 const specs='<div class="ship-specs">'+ship.specs.map(([label,value])=>'<div><small>'+esc(label)+'</small><b>'+esc(value)+'</b></div>').join("")+'</div>';
 const prose=(title,lines)=>'<section class="ship-prose"><h3>'+title+'</h3>'+lines.map(x=>'<p>• '+esc(x)+'</p>').join("")+'</section>';
 const presets=shipLoadouts[id];
 const activePreset=presets.find(x=>x.id===shipTracker[id].loadout)||presets[0];
 const loadoutButtons=presets.length>1?'<div class="ship-loadout-picker"><div class="ship-loadout-title"><b>SELECT WEAPON LOADOUT</b><small>Shared component upgrades carry across all builds</small></div><div class="ship-loadout-grid">'
 +presets.map(x=>'<button type="button" data-ship-loadout="'+x.id+'" class="'+(x.id===activePreset.id?'active':'')+'"><b>'+esc(x.name)+'</b><small>'+esc(x.tag)+'</small></button>').join("")
 +'</div></div>':'';
 const loadoutOverview='<div class="ship-loadout-overview"><h3>'+esc(activePreset.name)+' · WEAPON CONFIGURATION</h3>'
  +'<p>'+esc(activePreset.summary)+'</p><div class="ship-loadout-specs"><div><small>PILOT-OPERATED</small><b>'+esc(activePreset.pilot)+'</b></div><div><small>MANNED TURRETS</small><b>'+esc(activePreset.turrets)+'</b></div></div>'
  +'<p>'+esc(activePreset.practical)+'</p><div class="ship-procons"><div><h4>ADVANTAGES</h4><p>'+esc(activePreset.pro)+'</p></div><div><h4>TRADEOFFS</h4><p>'+esc(activePreset.con)+'</p></div></div></div>';
 const loadoutNotes='<div class="ship-note-card"><h3>'+esc(activePreset.name.toUpperCase())+' · MY LOADOUT NOTES</h3><textarea id="ship-loadout-notes" rows="3" placeholder="Testing, target types, fitting order…">'+esc(shipTracker[id].loadoutNotes?.[activePreset.id]||"")+'</textarea></div>';
 const overview=specs+'<div class="ship-procons">'+prose("STRENGTHS",ship.pros)+prose("TRADEOFFS",ship.cons)+'</div>'
  +'<div class="ship-note-card"><h3>STOCK LOADOUT / BUILD STARTING POINT</h3><p>'+esc(ship.stock)+'</p><a href="'+esc(ship.source)+'" target="_blank" rel="noopener noreferrer">SHIP REFERENCE</a>'+(id==='gladius'?'<p class="ship-market-note">Ship image: <a href="https://starcitizen.tools/File:Gladius_in_space_-_Isometric.jpg" target="_blank" rel="noopener noreferrer">Weehamster / Star Citizen Wiki</a> · CC BY-SA 4.0</p>':'')+'</div>';
 let categories="";
 for(const category of shipCategories){
  const group=parts.filter(p=>p.cat===category);if(!group.length)continue;
  const bought=group.reduce((n,item)=>n+shipFlags(id,item).filter(Boolean).length,0),total=group.reduce((n,item)=>n+item.qty,0);
  const key=id+":"+category;
  categories+='<details class="ship-category" data-ship-category="'+esc(category)+'" '+(shipExpandedGroups.has(key)?"open":"")+'>'
  +'<summary><b>'+esc(category)+'</b><span>'+bought+" / "+total+' units</span></summary><div class="ship-part-list">'
  +group.map(item=>shipPartCard(id,item)).join("")+'</div></details>';
 }
 const build='<div class="ship-budget"><div><small>PURCHASED</small><b>'+tot.done+' / '+tot.all+' units</b></div>'
 +'<div><small>BUILD ESTIMATE</small><b>'+shipMoney(tot.cost)+'</b></div>'
 +'<div><small>EST. REMAINING</small><b>'+shipMoney(tot.left)+'</b></div></div>'
 +(id==='gladius'?'<p class="ship-market-note"><b>CORE PVP PURCHASES:</b> '+shipMoney(tot.coreCost)+' · <b>OPTIONAL REFINEMENTS:</b> '+shipMoney(tot.optionalCost)+'. The build estimate above includes both; optional parts can be skipped. Stock AllStop shields and Bracer coolers remain viable. Prices are 4.10.3 player-reported shop listings, not guaranteed terminal inventory.</p>':'<p class="ship-market-note">Prices are aUEC estimates from 4.10.2–4.10.3 market reports; older or unconfirmed sellers are identified in the part details. Only parts for the selected loadout are counted. Missile options represent purchases, not the ship’s entire missile capacity.</p>')
 +'<div class="ship-build-heading"><h2>PARTS CHECKLIST</h2><button id="ship-add-part" class="primary-btn" type="button">+ ADD PART</button></div>'
 +categories+loadoutNotes+'<div class="ship-note-card"><h3>MY SHIP BUILD NOTES</h3><textarea id="ship-global-notes" rows="4" placeholder="Overall strategy, remaining tasks, flight test observations…">'+esc(shipTracker[id].shipNotes)+'</textarea></div>';
 const main=el("main-area");
 main.innerHTML='<section class="ship-workspace"><div class="ship-title-line"><div class="eyebrow">SHIP INFORMATION / MY HANGAR</div></div>'
  +'<div class="ship-switch">'+shipTabs+'</div>'
  +'<div class="ship-hero"><img src="'+esc(ship.image)+'" alt="'+esc(ship.name)+' ship photograph" loading="eager">'
  +'<div class="ship-hero-info"><small>'+esc(ship.manufacturer)+'</small><h1>'+esc(ship.name)+'</h1><p>'+esc(ship.description)+'</p>'
  +'<div class="ship-chips"><span>'+esc(ship.role)+'</span><span>CREW '+esc(ship.crew)+'</span><span>'+esc(ship.focus)+'</span></div></div></div>'
  +'<div class="ship-tabs"><button data-ship-tab="overview" class="'+(shipTab==="overview"?"active":"")+'">SHIP OVERVIEW</button>'
  +'<button data-ship-tab="build" class="'+(shipTab==="build"?"active":"")+'">BUILD & PURCHASE TRACKER</button></div>'
  +(shipTab==="overview"?overview:loadoutButtons+loadoutOverview+build)+'</section>';
 main.querySelectorAll("[data-ship-choice]").forEach(btn=>btn.onclick=()=>{shipSelected=btn.dataset.shipChoice;shipTab="overview";renderShipInfo();});
 main.querySelectorAll("[data-ship-tab]").forEach(btn=>btn.onclick=()=>{shipTab=btn.dataset.shipTab;renderShipInfo();});
 main.querySelectorAll("[data-ship-loadout]").forEach(btn=>btn.onclick=()=>{
  if(!validShipLoadout(id,btn.dataset.shipLoadout))return;
  shipTracker[id].loadout=btn.dataset.shipLoadout;labSave();renderShipInfo();
 });
 if(shipTab==="build"){
  main.querySelectorAll("[data-ship-category]").forEach(d=>d.ontoggle=()=>{const key=id+":"+d.dataset.shipCategory;if(d.open)shipExpandedGroups.add(key);else shipExpandedGroups.delete(key);});
  main.querySelectorAll("[data-ship-detail]").forEach(d=>d.ontoggle=()=>{const key=id+":"+d.dataset.shipDetail;if(d.open)shipExpandedParts.add(key);else shipExpandedParts.delete(key);});
  main.querySelectorAll("[data-ship-unit]").forEach(box=>box.onchange=()=>{
   const item=shipItems(id).find(p=>p.id===box.dataset.shipUnit);if(!item)return;
   const flags=shipFlags(id,item);flags[Number(box.dataset.index)]=box.checked;
   shipTracker[id].owned[item.id]=flags;labSave();
   shipExpandedGroups.add(id+":"+item.cat);shipExpandedParts.add(id+":"+item.id);renderShipInfo();
  });
  main.querySelectorAll("[data-ship-part-note]").forEach(box=>box.oninput=()=>{shipTracker[id].notes[box.dataset.shipPartNote]=box.value.slice(0,3000);labSave();});
  main.querySelectorAll("[data-ship-remove]").forEach(btn=>btn.onclick=()=>{
   if(!window.confirm("Remove this custom part?"))return;
   const key=btn.dataset.shipRemove;
   shipTracker[id].custom=shipTracker[id].custom.filter(p=>p.id!==key);
   delete shipTracker[id].owned[key];delete shipTracker[id].notes[key];labSave();renderShipInfo();
  });
  const loadoutNote=el("ship-loadout-notes");
  if(loadoutNote)loadoutNote.oninput=e=>{
   shipTracker[id].loadoutNotes??={};
   shipTracker[id].loadoutNotes[shipTracker[id].loadout]=e.target.value.slice(0,5000);labSave();
  };
  el("ship-global-notes").oninput=e=>{shipTracker[id].shipNotes=e.target.value.slice(0,8000);labSave();};
  el("ship-add-part").onclick=shipAddPart;
 }
}


/* Personal build additions. Never sends to the game. */
'use strict';
function shipAddPart(){
 const cats=shipCategories.map(c=>'<option value="'+esc(c)+'">'+esc(c)+'</option>').join("");
 const loadoutChoices='<option value="shared">ALL LOADOUTS (SHARED)</option>'+shipLoadouts[shipSelected].map(item=>
  '<option value="'+item.id+'" '+(item.id===shipTracker[shipSelected].loadout?'selected':'')+'>'+esc(item.name)+'</option>').join("");

 el("modal-root").innerHTML='<div class="modal-wrap"><div class="modal ship-add-modal" role="dialog" aria-modal="true"><div class="eyebrow">MY SHIP BUILD</div><h2>Add a part</h2>'
  +'<form id="ship-add-form"><label class="field">PART NAME<input id="ship-new-name" class="input" required maxlength="90" placeholder="Component name"></label>'
  +'<label class="field">APPLIES TO<select id="ship-new-loadout" class="input">'+loadoutChoices+'</select></label>'
  +'<div class="modal-grid"><label class="field">CATEGORY<select id="ship-new-cat" class="input">'+cats+'</select></label>'
  +'<label class="field">QUANTITY<input id="ship-new-qty" class="input" type="number" min="1" max="24" value="1"></label></div>'
  +'<div class="modal-grid"><label class="field">PRICE EACH (aUEC)<input id="ship-new-price" class="input" type="number" min="0" placeholder="Optional"></label>'
  +'<label class="field">SIZE / GRADE<input id="ship-new-size" class="input" maxlength="70" placeholder="S2 · Grade A"></label></div>'
  +'<label class="field">PURCHASE LOCATION<input id="ship-new-shop" class="input" maxlength="180" placeholder="Store / station"></label>'
  +'<label class="field">PROS<textarea id="ship-new-pro" class="input" rows="2" maxlength="500"></textarea></label>'
  +'<label class="field">CONS / TRADEOFFS<textarea id="ship-new-con" class="input" rows="2" maxlength="500"></textarea></label>'
  +'<label class="field">COMPONENT PHOTO URL (OPTIONAL)<input id="ship-new-image" class="input" type="url" placeholder="https://..."></label>'
  +'<label class="field">SOURCE / REFERENCE URL (OPTIONAL)<input id="ship-new-source" class="input" type="url" placeholder="https://..."></label>'
  +'<div class="settings-row"><button class="primary-btn" type="submit">SAVE PART</button>'
  +'<button id="ship-add-cancel" class="secondary-btn" type="button">CANCEL</button></div></form></div></div>';
 el("ship-add-cancel").onclick=()=>el("modal-root").innerHTML="";
 el("ship-add-form").onsubmit=e=>{
  e.preventDefault();
  const get=id=>el(id).value.trim();
  const name=get("ship-new-name"),image=get("ship-new-image"),source=get("ship-new-source");
  if(!name)return;
  if((image&&!shipURL(image))||(source&&!shipURL(source))){notify("Photo and reference links must use HTTPS.",true);return;}
  const id="c-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,7);
  shipTracker[shipSelected].custom.push({
   id,name:shipText(name,90),cat:get("ship-new-cat"),loadout:get("ship-new-loadout"),size:shipText(get("ship-new-size"),70),
   qty:Math.max(1,Math.min(24,Number(get("ship-new-qty"))||1)),
   price:Math.max(0,Math.min(50000000,Math.round(Number(get("ship-new-price"))||0))),
   shop:shipText(get("ship-new-shop"),180),alt:"",image,source,
   pro:shipText(get("ship-new-pro")),con:shipText(get("ship-new-con")),verify:"My added part"
  });
  shipExpandedGroups.add(shipSelected+":"+get("ship-new-cat"));
  shipExpandedParts.add(shipSelected+":"+id);
  labSave();el("modal-root").innerHTML="";renderShipInfo();notify("Part added to build.");
 };
}



/* Live presentation preferences. This does not change bindings or command kinds.
 * The public Layout Lab is a separate origin: import its JSON to transfer choices.
 */
const deckLayoutKey='scdeck-live-layout-v1';
const deckShipProfile={id:'ships',name:'Ship Information',short:'SHIPS',subtitle:'Vessel data and build tracking',icon:'ship'};
let deckEditMode=false,deckServerApp=null;
let deckUiEdits={},deckUiStyles={},deckProfileOrder=[];
function deckRestore(){
 try{
  const raw=JSON.parse(localStorage.getItem(deckLayoutKey)||'{}');
  if(raw&&typeof raw==='object'){
   if(raw.controls&&typeof raw.controls==='object')deckUiEdits=raw.controls;
   if(Array.isArray(raw.profileOrder))deckProfileOrder=raw.profileOrder;
   if(raw.ships)shipTracker=shipStateNormalize(raw.ships);
   if(raw.order&&typeof raw.order==='object'&&!Array.isArray(raw.order)){
    cockpitOrder=raw.order;
    localStorage.setItem(cockpitOrderKey,JSON.stringify(cockpitOrder));
   }
  }
 }catch(_){}
}
function deckSaveLayout(){
 try{localStorage.setItem(deckLayoutKey,JSON.stringify({
  schema:'scdeck-layout-lab-v1',source_version:app?.version||'0.2.24',
  controls:deckUiEdits,order:cockpitOrder,
  profileOrder:deckProfileOrder.length?deckProfileOrder:deckOrderedProfiles().map(x=>x.id),
  ships:shipTracker
 }));}catch(_){notify('Unable to save this layout in local browser storage.',true);}
}
function labSave(){deckSaveLayout();}
function deckValidProfiles(){return [...(app?.profiles||[]),deckShipProfile];}
function deckOrderedProfiles(){
 const profiles=deckValidProfiles();
 const ordered=[...new Set([...deckProfileOrder,...profiles.map(x=>x.id)])];
 return ordered.map(id=>profiles.find(x=>x.id===id)).filter(Boolean);
}
function deckApplyUi(fresh){
 deckServerApp=fresh;
 const safe=fresh.controls.map(c=>({...c}));
 const ids=new Set(safe.map(c=>c.id));
 deckUiStyles={};
 const validProfiles=new Set(fresh.profiles.map(p=>p.id));
 for(const c of safe){
  const custom=deckUiEdits[c.id]||{};
  if(typeof custom.label==='string'&&custom.label.trim()&&custom.label.length<=90)c.label=custom.label;
  if(typeof custom.section==='string'&&custom.section.trim()&&custom.section.length<=90)c.section=custom.section;
  if(validProfiles.has(custom.profile))c.profile=custom.profile;
  if(['pad','switch','choice'].includes(custom.style))deckUiStyles[c.id]=custom.style;
  if(c.id==='home_flight_ready'&&(!custom.section||!custom.section.trim()))c.section='Flight essentials';
  if(c.profile==='home'&&(c.id==='home_cruise'||c.id==='home_decouple'))c._deckHidden=true;
 }
 return {...fresh,controls:safe};
}
function deckFlash(btn){
 if(!btn)return;
 btn.classList.add('lab-flash');
 if(btn._deckFlashTimer)clearTimeout(btn._deckFlashTimer);
 btn._deckFlashTimer=setTimeout(()=>btn.classList.remove('lab-flash'),340);
}
function deckEditControl(id){
 const c=app?.controls.find(x=>x.id===id);
 if(!c)return;
 const change=deckUiEdits[id]||{};
 const style=change.style||'auto';
 const opts=app.profiles.map(p=>'<option value="'+esc(p.id)+'" '+(p.id===c.profile?'selected':'')+'>'+esc(p.name)+'</option>').join('');
 const kinds=['auto','pad','switch','choice'].map(k=>'<option value="'+k+'" '+(style===k?'selected':'')+'>'+k.toUpperCase()+'</option>').join('');
 el('modal-root').innerHTML='<div class="modal-wrap"><div class="modal" role="dialog" aria-modal="true" aria-label="Edit visual layout"><div class="eyebrow">EDIT CONTROL LAYOUT</div><h2>'+esc(c.label)+'</h2><p>Visual changes only. Existing Star Citizen commands and keybindings are preserved.</p><form id="deck-layout-form">'
  +'<div class="field"><label>BUTTON LABEL</label><input id="deck-label" class="input" required maxlength="90" value="'+esc(c.label)+'"></div>'
  +'<div class="modal-grid"><div class="field"><label>PAGE</label><select id="deck-profile" class="input">'+opts+'</select></div>'
  +'<div class="field"><label>BUTTON APPEARANCE</label><select id="deck-style" class="input">'+kinds+'</select></div></div>'
  +'<div class="field"><label>SECTION / GROUP</label><input id="deck-section" class="input" required maxlength="90" value="'+esc(c.section)+'"></div>'
  +'<div class="settings-row"><button type="submit" class="primary-btn">SAVE LAYOUT</button><button id="deck-cancel" class="secondary-btn" type="button">CANCEL</button></div>'
  +'</form></div></div>';
 el('deck-cancel').onclick=()=>el('modal-root').innerHTML='';
 el('deck-layout-form').onsubmit=ev=>{
  ev.preventDefault();
  const label=el('deck-label').value.trim(),section=el('deck-section').value.trim();
  if(!label||!section)return;
  deckUiEdits[id]={label:label.slice(0,90),section:section.slice(0,90),profile:el('deck-profile').value,style:el('deck-style').value};
  deckSaveLayout();app=deckApplyUi(deckServerApp);el('modal-root').innerHTML='';render();notify('Layout saved.');
 };
}
function deckMoveProfile(id,direction){
 const ids=deckOrderedProfiles().map(p=>p.id),i=ids.indexOf(id),other=i+direction;
 if(i<0||other<0||other>=ids.length)return;
 [ids[i],ids[other]]=[ids[other],ids[i]];
 deckProfileOrder=ids;deckSaveLayout();renderNav();deckRenderLayoutSettings();
}
function deckExport(){
 const text=JSON.stringify({schema:'scdeck-layout-lab-v1',controls:deckUiEdits,order:cockpitOrder,
  profileOrder:deckOrderedProfiles().map(p=>p.id),ships:shipTracker,source_version:app.version},null,2);
 const url=URL.createObjectURL(new Blob([text],{type:'application/json'}));
 const a=document.createElement('a');a.href=url;a.download='star-citizen-deck-layout-and-ships.json';
 document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);
}
function deckImport(data){
 if(!data||data.schema!=='scdeck-layout-lab-v1'||!data.controls||typeof data.controls!=='object'||Array.isArray(data.controls))
  throw new Error('Not a Layout Lab export.');
 const validIds=new Set(deckServerApp.controls.map(x=>x.id));
 const validProfiles=new Set(deckServerApp.profiles.map(x=>x.id));
 const edits={};
 for(const [id,e] of Object.entries(data.controls)){
  if(!validIds.has(id)||!e||typeof e!=='object')continue;
  const next={};
  if(typeof e.label==='string'&&e.label.trim()&&e.label.length<=90)next.label=e.label;
  if(typeof e.section==='string'&&e.section.trim()&&e.section.length<=90)next.section=e.section;
  if(validProfiles.has(e.profile))next.profile=e.profile;
  const style=['pad','switch','choice'].includes(e.style)?e.style:
   e.kind==='toggle'?'switch':e.kind==='button'?'pad':null;
  if(style)next.style=style;
  if(Object.keys(next).length)edits[id]=next;
 }
 const ids=[...validProfiles,'ships'];
 const order=Array.isArray(data.profileOrder)?data.profileOrder.filter(id=>ids.includes(id)):[];
 let safeOrder={};
 if(data.order&&typeof data.order==='object'&&!Array.isArray(data.order)){
  for(const [page,groups] of Object.entries(data.order)){
   if(!validProfiles.has(page)||!groups||typeof groups!=='object')continue;
   const safe={};
   for(const [index,arr] of Object.entries(groups))if(/^\d{1,3}$/.test(index)&&Array.isArray(arr))
    safe[index]=[...new Set(arr.filter(id=>typeof id==='string'&&validIds.has(id)))].slice(0,180);
   safeOrder[page]=safe;
  }
 }
 deckUiEdits=edits;deckProfileOrder=[...new Set([...order,...ids])];cockpitOrder=safeOrder;
 if(data.ships)shipTracker=shipStateNormalize(data.ships);
 localStorage.setItem(cockpitOrderKey,JSON.stringify(cockpitOrder));
 deckSaveLayout();app=deckApplyUi(deckServerApp);render();
}
function deckRenderLayoutSettings(){
 const profiles=deckOrderedProfiles();
 const rows=profiles.map((p,i)=>'<div class="lab-profile-row"><span><b>'+esc(p.name)+'</b><small>'+esc(p.short)+' · position '+(i+1)+'</small></span>'
  +'<div class="lab-profile-actions"><button type="button" data-deck-move="'+p.id+'" data-dir="-1" '+(i===0?'disabled':'')+' aria-label="Move up">↑</button>'
  +'<button type="button" data-deck-move="'+p.id+'" data-dir="1" '+(i===profiles.length-1?'disabled':'')+' aria-label="Move down">↓</button></div></div>').join('');
 el('settings-body').innerHTML='<section class="settings-card"><h3>Sidebar order</h3><p>Move your profiles without shrinking their icons.</p><div class="lab-profile-list">'+rows+'</div></section>'
  +'<section class="settings-card"><h3>Transfer Layout Lab work</h3><p>Import an export from Layout Lab to bring over your ship checklists, notes and visual control layout. Game bindings and commands are never overwritten.</p>'
  +'<div class="settings-row"><button id="deck-export" class="primary-btn" type="button">EXPORT LAYOUT + SHIPS</button>'
  +'<label class="secondary-btn lab-import-label" for="deck-import">IMPORT LAYOUT LAB JSON</label>'
  +'<input id="deck-import" type="file" accept=".json,application/json" hidden></div></section>';
 el('settings-body').querySelectorAll('[data-deck-move]').forEach(b=>b.onclick=()=>deckMoveProfile(b.dataset.deckMove,Number(b.dataset.dir)));
 el('deck-export').onclick=deckExport;
 el('deck-import').onchange=async ev=>{
  const file=ev.target.files?.[0];if(!file)return;
  if(file.size>200000){notify('Layout file exceeds the supported limit.',true);return;}
  try{deckImport(JSON.parse(await file.text()));notify('Layout and ship notes imported.');}
  catch(e){notify(e.message||'Import failed',true);}
 };
}


// Restore preferences after all build-tracker definitions are loaded.
deckRestore();
