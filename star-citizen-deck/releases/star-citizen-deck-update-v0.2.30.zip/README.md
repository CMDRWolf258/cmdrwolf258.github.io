### v0.2.30 — Gladius PvP complete 4.10.3 shop-only audit

- Rechecked the original Gladius stock equipment and four missile racks against 4.10.3-LIVE.13165946 game-file references (Nov 21, 2026). All current ship component sizes and the existing Panther/Mantis/Concord/Breton/IcePlunge/Atlas/V801-11/Thunderbolt listings were cross-checked against the game's 4.10.3 component database and dated UEX shop reports; no made-up real-time stock claims.
- **Concord shields are now correctly marked optional**. Two stock AllStops provide the greatest S1 shield HP (3,168 vs Concord 3,000 each). Concords trade 168 HP each for faster regen/restart; the genuinely essential Laser Interceptor purchase is *one CF-337 Panther, 36,308 aUEC*. Laser and Mantis preset totals still account for all optional wishlist items, but the core subtotal is corrected.
- Power plant Breton is now explicitly a small 270→300 HP refinement (same 16 power segments, same 7,920 EM signature); two IcePlunges have only 69 HP each versus stock Bracers 180 HP, with equal cooling 34, and are not recommended for hard PvP duels. Atlas QT shop report is from Sep 19 (older/verify). Shop prices reflect last reported observations rather than live availability.
- Adds two shop-buyable alternative Gladius weapon presets without changing existing IDs: **Armor Pressure** with 3 × M5A S3 laser cannons (75,145 aUEC each, Orison) for high individual damage against tougher armor and **Revenant Burst** with 3 × Revenant S3 Gatlings (56,955 aUEC each, Orison) for greater listed ballistic DPS. The existing 3 × Panther and 3 × Mantis presets remain, as do all saved purchases, notes and selected presets.
- Sledge III S3 mass drivers, FR-66 military shields, Glacier military coolers and military 17-output power plants were considered but not added as core recommendations: the first is slow for agile-fighter duels; the latter three have no shop listings in the current buy-only catalog. A stock Explorer quantum jump module is noted for completeness; it is not a necessary PvP upgrade.
- No changes to game input, companion telemetry, mappings, paired devices, or the iPad layout system. Regression tests include optional-vs-core totals, all four weapon presets and state persistence.

### v0.2.29 — Shop-only Gladius radar option

- Adds the missing **V801-11 (S1 Military A)** to the Gladius shared parts checklist, with current 4.10.3 shop listing at Omega Pro, New Babbage: 176,000 aUEC.
- Lists the original Gladius **Ecouter (S1 Military C)** as stock. Compared to Ecouter, V801-11 has +15% component health (690 vs 600), -20% EM signature (1,440 vs 1,800), and the same 5 power draw. Detection/lock-range gains are unverified and are not promised.
- Marked as optional. Existing Laser Interceptor and Ballistic Pressure builds, purchased flags, layout customizations, pairing and other ship records are preserved.

### v0.2.28: Fix broken Gladius hero image

- Replaced the v0.2.27 Gladius photo URL, which returned HTTP 404, with a directly verified image of the Aegis Gladius from Star Citizen Wiki (Weehamster, CC BY-SA 4.0), including attribution in the ship overview.
- Preserves existing Ion/Andromeda/Gladius ship builds, purchase checkboxes, layouts, and app keybindings; no changes to game input or data integration.

### v0.2.27: Shop-only Gladius PvP builds in SHIPS

- Adds an Aegis Gladius ship overview with current 4.10.3 LIVE hardpoints, realistic strengths/tradeoffs and stock equipment.
- Adds two selectable gun loadouts: **Laser Interceptor** (3 × CF-337 Panthers; buy only one because two are stock) and **Ballistic Pressure** (3 × Mantis GT-220; buy two because one is stock). Only the chosen configuration's weapon purchases are counted.
- Shared shop-only parts: 2 × 7SA Concord shields (faster recovery, slightly less HP than stock AllStops), optional Breton power plant (same 16 output, more resilience), optional IcePlunge coolers (lower power/signature but weaker HP), optional Atlas S1 quantum (travel utility), optional S3 Thunderbolt III EM missiles. Current locations, shop-report dates, aUEC prices, sources and explicit tradeoffs are recorded per part.
- Core vs optional purchase totals are shown separately; a full build estimate includes both, so skipping optional items is straightforward.
- All updates are presentation and browser-local checklist data. The Gladius uses the existing per-ship note, per-loadout note, per-part purchased checkboxes, custom-part editor and Layout export/import. Upgrading existing layouts retains Ion and Andromeda notes, checked items, custom lists and loadout choices; Gladius starts with a separate blank tracker.
- No access to restricted components, unreleased game telemetry, gameplay input or injected keybind changes. Prices are player-reported and should be verified at in-game shop terminals.

### v0.2.26: NAV route-access and operator-mode controls

- Adds eight standard NAV controls: Open Starmap (game-default F2), Open mobiGlas (F1), Next / Previous Operator Mode (forward defaults to middle mouse, reverse unassigned), direct Select Quantum / Flight Mode (unassigned unless configured in-game), and Speed Limit − / + (game-default Left Alt + mouse wheel).
- These are exact actions from the pinned Star Citizen 4.10.2 keyboard/action reference. As with other built-in controls, the installed game profile and explicit manual bindings take precedence. Unassigned game actions stay UNMAPPED; no invented shortcuts or sticky system-state indicators.
- New controls appear in the existing three NAV cockpit panels. A map button opens the game's Starmap; no automatic mission identification or route plotting is claimed. Touches send a single existing mapped action.
- The existing companion input protocol and Game.log monitor are unchanged. Factory IDs are additive so custom controls, saved docking binding, control edits, pairing, ship checklists, and per-device layout settings remain intact.

### v0.2.25: Constellation snub docking button in SYS Landing Config

- The custom Docking button added through Settings → Keybindings now appears directly below VTOL in SYS → Landing Config, ahead of ATC.
- It reuses the existing custom control ID and its user-defined shortcut (Right Alt + N on Serenity), without changing the actual action mapping, control registry, or stored settings. It does not duplicate the button under Additional Controls.
- This is a presentation-only change to the existing web/app.js. The companion input path, startup permissions and existing Game.log integration are unchanged.
- Docking buttons added to another profile remain there; unrelated user-created controls stay under Additional Controls.

### v0.2.24: Layout Lab visual and ship-workspace integration

- Adopts compact headers, individually shaded opaque buttons, touch flash confirmation (never latched system states), independent Edit Mode, scrollable profile sidebar and the new SHIPS page.
- Ships provides Ares Ion and Constellation Andromeda photo/reference pages, four Andromeda weapon configurations, shared upgrades, per-unit purchase checkboxes, shop/price notes, custom items and separate loadout notes.
- Settings → Layout imports/exports the Layout Lab JSON (ship notes, control placement and sidebar order) without modifying the server's game bindings or sending fake telemetry. The Home screen's Flight Ready placement, Quick Action presentation and radar profile icon are adopted.
- Windows companion input delivery, authentication, Game.log inference and mapped actions remain unchanged. All new JavaScript is bundled into the existing web/app.js to satisfy the installed updater's eight-file allowlist. Browser localStorage is device/origin-specific; use export/import to migrate Lab work to the live controller.
- Existing paired device settings and game mappings remain in %%LOCALAPPDATA%%\\StarCitizenDeck and are not touched by the update package.

### v0.2.22: Home Ship Intelligence and compact event feed

- **Home:** A dedicated Detected Vessel banner now identifies the last Game.log-associated ship, including the ship evidence type. For the Ares Ion, a validated public Star Citizen Wiki record supplies a compact reference specification summary: crew, cargo capacity, SCM/max speed, published shield/hull HP, plus manufacturer, role and dimensions under expandable details. The ship name displays even with no network.
- **Reference lookup:** Only a validated public *vehicle class identifier* (for example `CRUS_Starfighter_Ion`) is sent to the fixed `https://api.star-citizen.wiki/api/vehicles/` endpoint. No player, ship instance IDs, account names, or game-log content leave Serenity. The companion selects a matching versioned ship record, caches it for 6 hours, bounds response sizes and response fields, and marks component names as *factory/reference equipment*—never the current fitted loadout. The Ares Ion has an offline 4.10.2 reference snapshot derived from `https://api.star-citizen.wiki/vehicles/crus-starfighter-ion`; other ships simply retain their detected name if lookup is unavailable. Neither shield HP nor speed is a live reading.
- **Session Intelligence:** Shows just the three latest game events by default, with earlier events in an expandable section. The existing detected-vehicle evidence and other session fields remain visible. Expanded details remain open as the Game.log updates.
- **Compatibility:** Reuses existing `companion.py`, browser assets and original eight-path update package. No new companion app, account/API keys, game memory access, or input-mapping changes. In-game data remains event-driven and explicitly marked inferred/stale when appropriate.

### v0.2.21: Detect piloted vehicles from Game.log control events

- Fixed missing ship identification: we previously relied only on ship comms-channel notifications. Read-only monitoring now recognizes **local pilot-control grants and releases** in `<Vehicle Control Flow>` lines, with matching instance IDs. A control grant identifies the last vehicle for which the local client was granted control; a matching release clears it. Unrelated/remote players' vehicles, generic entities, and merely requested controls are ignored.
- Where direct local control is not logged, ship IDs associated with **selected quantum targets** or the ship's **Starmap navigation component** provide clearly labeled lower-confidence vehicle inference. A navigation event cannot replace an active local pilot-control observation. Mere quantum arrivals are never used to infer your ship because other vessels' arrivals may appear in Game.log.
- Session Intelligence now displays **Detected Vehicle** and **Ship Evidence**, distinguishing local pilot control from inferred navigation or an unverified ship comms channel. Unknown remains honest if the current game build reports none of these events.
- Uses the existing `companion.py`, eight-file updater contract and Game.log monitor. No game memory access, file writes or other programs; no changes to button mappings.
- Detection patterns cross-checked with Picologs/pico's `log-parser.ts` and tests and D3adly/sc-toolkit's `gamelog.py`. The user's build still requires real-session validation.

### v0.2.20: Compatibility fix for Game.log Session Intelligence installer

- Fixes the `Update includes unexpected application files` error seen when upgrading directly from v0.2.18. The existing updater permits only eight known runtime file paths, so the v0.2.19 release containing a new `sc_game_log.py` file was rejected before installation.
- The **same read-only Game.log intelligence** is now embedded into the already-allowed `companion.py` file. The ZIP contains **only the eight original runtime paths**. No manual install or separate Python module is needed, and the preinstalled updater's integrity checks remain unchanged.
- Release regression test ensures packages can be accepted by the v0.2.18 updater without modifying or bypassing its allowlist.

### v0.2.19: Read-only Star Citizen Game.log intelligence

- The existing Windows companion now monitors **Game.log** locally, without modifying the game, hooking processes, reading memory or uploading log content. No new background application is needed. It starts with the companion and updates its session snapshot as game log events arrive.
- Home, On Foot and Utilities replace the static **Command Guidance / No Route Data** placeholder with **Session Intelligence**: last observed ship communication channel (not guaranteed piloted ship), location-related inventory event (not precise position), jurisdiction, quantum target code and recent contract/event activity. NAV replaces the fake route diagram with an honest **last logged quantum target** readout.
- Structured data is served only via paired `GET /api/session`; arbitrary raw log lines, player handles and account IDs are not returned. Each value is labeled as observed evidence rather than confirmed live ship telemetry. Stale or missing logs are explicitly identified; target code is **not** an active Starmap route, distance or ETA.
- Path auto-detection uses the synced game profile's installation and common LIVE/PTU paths. A manual **Settings → Connection → Game.log path** override is available for other installation locations. Only a file named `Game.log` can be selected, and it is opened **read-only**.
- The parser handles game-log truncation/replacement, incomplete lines, bounded reads and an event history limit. Patterns follow current 4.x community-observed logs but may require revisions when CIG changes the format. In particular, no reliable general-purpose shield, fuel or hull telemetry is available.
- This release makes no changes to existing key/mouse injection or user mappings. The Windows admin permission issue for Star Citizen commands remains separate.

Sources for the event signatures: SC-Bridge/sc-companion `internal/logtailer/parser.go` (MIT license); CIG support article on `Game.log`.

# Star Citizen Control Deck v0.2.6 — Public Update Channel

## Windows companion upgrade

- v0.2.6 changes the release checker to the dedicated public GitHub Pages channel at `https://cmdrwolf258.github.io/star-citizen-deck/latest.json`. The private development repository stays private.
- The installed v0.2.5 still points at the previous inactive feed. To activate future one-button remote updates, install **star-citizen-deck-update-v0.2.6.zip once** using Settings → Updates → Advanced: install a trusted ZIP manually. **Do not unzip.**
- After restarting into v0.2.6, future newer versions appear under Settings → Updates → Install. The file size, HTTPS-origin, SHA-256 digest, allowed internal paths and per-file hashes are verified before an update is installed.
- Your current user settings, pairing and keyboard controls remain outside the app folder; the installer creates persistent backups and runs an import smoke test.
- SHA-256 is an integrity check, not a developer signature. The public Pages repository is the trusted delivery location.
- The Win32 scan-code injection functions have not been changed, and in-game verification still covers **only Ship Lights**.

## Developer release

Run `python -m unittest discover -s windows/tests -v` and `python scripts/build_update.py` from the private repo. Publish the versioned ZIP to the public Pages repository at `star-citizen-deck/releases/` and publish `star-citizen-deck/latest.json` **after** verifying the ZIP is publicly accessible. See root README.

## Input behavior and limits

- Only Ship Lights has been validated in-game. Other controls, modifiers, axes and held inputs remain unverified.
- The browser panel shows sent commands, **not** confirmed game state.
- No ship telemetry, true analog axis controls, or GameGlass dependencies.
- Port 8765 is HTTP on trusted Wi-Fi, not an internet-facing service. Do not port-forward it.
- This update does not change HOTAS mappings or Star Citizen files.


### v0.2.7 Cockpit Concept 02
The existing browser iPad interface now uses the approved cockpit instrument layout on the seven profile pages. `Settings`, local pairing, XML imports, the updater, and scan-code command delivery remain unchanged. Each control reads the current server action and mapping by its stable ID; any control reassigned to a new profile appears in Additional Controls. Reordering within a bank saves only in that iPad browser's local storage and does not affect bindings or other devices. The mining range slider is visual-only; ± keys use their existing single-step mapped action. No ship telemetry is inferred from command delivery.

### v0.2.8: cockpit fit and action-linked binding visibility

- Narrow iPad panels now give single/odd-last buttons the full row and allow control banks to become single-column when space is tight. Hardware lever mechanisms remain inside their frames with wrapping labels.
- A read-only binding report shows which controls intentionally share a Star Citizen action reference and which different actions may overlap on the same keyboard shortcut. Overlap warnings are **advisory**, since ship and on-foot contexts may share keys. No mappings are changed automatically.
- The control editor now lets you copy an existing action reference from another button. Manual overrides remain per-control and survive restarts.
- Hold-type buttons show configured timed-keypress durations; this is **not** a press-and-hold-until-release input. No live ship-state telemetry or true axes have been added.
- Windows scan-code delivery, settings, pairing, updater, and saved control IDs are preserved.


### v0.2.9: Import game defaults with one explicit action

Users whose controller shows `0 game defaults` can choose **Settings → Keybindings → IMPORT GAME DEFAULTS**. The companion downloads an independently maintained, pinned SHA-256-verified SSCM v1.4.0 Windows full release, and only if the user confirms it runs the extractor against Serenity's installed Star Citizen data in read-only print mode. The resulting XML is validated and saved outside Star Citizen at `%LOCALAPPDATA%\StarCitizenDeck\defaultProfile.xml`. The existing override synchronization then runs again, preserving manual controls and joystick bindings.

SSCM is a separate upstream program; internet and a local LIVE game install are required. This operation's Windows/Data.p4k path is not tested on the user's PC yet. The action catalog will improve substantially if extraction succeeds, but unmapped cockpit controls with no valid Star Citizen action reference remain unmapped until their action is identified.

### v0.2.10: Game defaults import location fix
The verified SSCM extractor now uses the same Star Citizen environment as the synced XML profile, not SSCM's Program Files fallback. The temporary SSCM working directory receives a temporary appsettings.local.json with GameRoot and environment. No game files or mappings are modified. Report the first meaningful extractor error if the tool still fails; the last stack-trace line is not useful.

### v0.2.11: Current LIVE effective keybindings
User-initiated IMPORT CURRENT BINDINGS downloads an exact pinned 4.10.2 LIVE defaultProfile.xml (data only, no downloaded executables), verifies its Git blob checksum and checks the catalog, then overlays the current game's active actionmaps.xml overrides. A curated exact action mapping links known cockpit buttons but never overwrites manual shortcuts or previously working lights. Controls without supported keyboard inputs remain unassigned; the 4.10.2 reference version is displayed and must not be confused with a live archive extraction.

### v0.2.12: Mouse buttons and actual touch-held controls

- Read game defaults and current keyboard/mouse rebinds, including `kb1_mouse1` and `mo1_mouse1`. Support **MOUSE1–MOUSE5** on Windows using actual Win32 SendInput mouse-button down/up, plus keyboard modifiers. Mouse axes/wheel and joystick output remain deliberately unsupported.
- Holding a control on the iPad now sends a real input-down event and releases on finger/pointer up. The browser sends a small heartbeat; the companion automatically releases if it loses contact for 1.8 seconds, when disarmed, or when a stop command arrives. No repeated automatic game actions.
- Link a few high-confidence additional Star Citizen actions (NAV master mode, holster, third-person camera). Preserve manual overrides and working lights.
- Display which actions use mouse input and clarify that a mapped control is not yet verified as working in Star Citizen. Existing scan-code keyboard path and updater remain unchanged.
- Automated tests check mouse event flags, modifier ordering, quick touch-up, disarm release, expiry, and XML override provenance. Actual acceptance by Star Citizen on Serenity is still unverified.

### v0.2.13: HOTAS companion Scan and MFD workspaces

- **Two new cockpit pages:** Scanning (mode, trigger, ping, focus up/down, tab/page/contact navigation) and MFD Control (focus primary/casts/slots 1–10, choose 8 display-page categories, cycle previous/next). Screen actions are *individual* game actions, not macros: select an MFD and then a display page using your own in-game shortcuts.
- **Combat decoys:** − / Deploy / + group. The increase/decrease actions follow exact 4.10.2 keys (RALT+H and LALT+H unless customized).
- **ATC:** factory "Request Landing"/"Call ATC" labels migrate to "Takeoff / Landing Request" on existing installs, without altering user-renamed labels, button IDs, or mapped bindings.
- **No fabricated shortcuts or ship-state feedback.** MFD slot and view shortcut actions have no default keyboard bindings in the reference; assign only the useful ones in Star Citizen and sync normally. Mouse-wheel/analog axes remain unsupported. Existing HOTAS mappings and game files are read-only.
- Native SwiftUI project in `ipad/` remains unsigned development source; signed iPad installation requires an Apple build/distribution step separate from the Windows updater.

### v0.2.18: Home Quick Actions — Light Amplification and Radar Ping

- The Home Quick Actions bank now includes **Light Amplification** (Star Citizen action `seat_general/v_light_amplification_toggle`, default Right Alt+L) and automatically imports the live game binding. This is a toggle input; no game telemetry is available to confirm its actual state.
- Home's original Sensor Ping becomes **Radar Ping**, using the same action as Scanning (`spaceship_radar/v_invoke_ping`, default Tab). It now uses **touch-and-hold**, matching the actual held game action. Upgrades migrate the original factory tap control once, without resetting user-renamed labels, manual input overrides, or custom control types.
- No changes to game files, the current Windows input delivery mechanism, the iPad app mode, or other control profiles.

### v0.2.17: iPad Home Screen app and automatic Windows sign-in startup

- The iPad web interface includes Apple standalone web-app metadata. In Safari choose Share → Add to Home Screen → Open as Web App to launch without browser navigation bars. This does not require a paid Apple developer membership and does not make the local controller usable when Serenity is off. It is intentionally not an offline service worker.
- Settings → Connection offers an optional "Start companion automatically when signing in to Windows" switch. It registers the existing updater-aware START_DECK.bat in HKCU Run (current user, not all users). No elevation, scheduler or background polling. This starts with Windows login rather than waiting for Star Citizen's process to appear, so the iPad controller is ready when Star Citizen launches.
- Startup is opt-in and can be disabled with the same switch. Starting the companion always leaves game output disarmed. The Windows registry entry is kept outside the app's JSON state, and its current status is read live.
- Apple Home Screen web-app storage may need pairing once; the local host address and LAN-only requirements remain unchanged.

### v0.2.16: Scan angle wheel steps

- Import Star Citizen 4.10.2 default mouse-wheel up/down controls for scanning-angle increase/decrease when no keyboard assignment exists. Live imported keyboard/mouse overrides still take priority; other mouse axes and joystick inputs remain unsupported.
- Send exactly one vertical Win32 wheel notch per tap (120 delta) with optional keyboard modifiers. No continuous scroll automation; physical hold controls reject wheel events.
- Existing Scan Angle +/- controls now show and send the actual wheel bindings. The original user-customized control names/shortcuts are preserved.
- Unit tests cover both wheel directions, modifiers, XML overrides/defaults, safe release and unsupported input cases; real acceptance inside Star Citizen needs a short in-game test.
