/* Star Citizen Control Deck — version from Windows companion API. */
'use strict';
const icons = {
 grid:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
 compass:'<circle cx="12" cy="12" r="9"/><path d="m15.9 8.1-3 6-4.8 2.1 2-5.4z"/>',
 target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 1v5m0 12v5M1 12h5m12 0h5"/>',
 cpu:'<rect x="5" y="5" width="14" height="14" rx="2"/><path d="M9 9h6v6H9zM9 1v4m6-4v4M9 19v4m6-4v4M1 9h4M1 15h4m14-6h4m-4 6h4"/>',
 pickaxe:'<path d="m14 8-7 13M2 5c7-4 14-3 19 3-8-1-13 1-16 8"/>',
 person:'<circle cx="12" cy="6" r="3.2"/><path d="M5 21v-3c0-7 14-7 14 0v3M9 12v7m6-7v7"/>',
 sliders:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="8" cy="6" r="2" fill="#07111d"/><circle cx="15" cy="12" r="2" fill="#07111d"/><circle cx="10" cy="18" r="2" fill="#07111d"/>',
 settings:'<circle cx="12" cy="12" r="3.5"/><path d="M9 2h6l.5 2.5 2 1 2.2-1.2 3 5-2 1.7v2.2l2 1.7-3 5-2.2-1.2-2 1L15 22H9l-.5-2.3-2-1-2.2 1.2-3-5 2-1.7v-2.2l-2-1.7 3-5 2.2 1.2 2-1z"/>',
 bolt:'<path d="m13 2-9 12h7l-1 8 10-13h-7z"/>',
 toggle:'<path d="M12 2v10M6.4 6.5a9 9 0 1 0 11.2 0"/>',
 circle:'<circle cx="12" cy="12" r="8"/><path d="m9 12 2 2 4-4"/>',
 arrow:'<path d="M4 12h16M14 6l6 6-6 6"/>',
 lock:'<rect x="5" y="10" width="14" height="12" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
 sync:'<path d="M21 11A9 9 0 0 0 5 5L3 7m0-5v5h5M3 13a9 9 0 0 0 16 6l2-2m0 5v-5h-5"/>',
 shield:'<path d="m12 2 9 4v6c0 5-3.3 8.3-9 10-5.7-1.7-9-5-9-10V6z"/>',
 chevron:'<path d="m5 9 7 7 7-7"/>',
 edit:'<path d="M3 21l5-1 13-13-4-4L4 16zM14 6l4 4"/>',
 alert:'<path d="m12 2 10 19H2zM12 8v6m0 3v1"/>',
};
const svg=(name,css='')=>`<svg class="${css}" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" fill="none" aria-hidden="true">${icons[name]||icons.circle}</svg>`;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let token=localStorage.getItem('scdeck-token')||'';
let app=null,active='home',settingsTab='bindings',profileFilter='all',search='',localStates={},localSliders={};
let toastTimer=null;
const el=id=>document.getElementById(id);
async function request(path,data){
  let resp=await fetch(path,{method:data===undefined?'GET':'POST',headers:{...(token?{'X-Deck-Token':token}:{}),...(data===undefined?{}:{'Content-Type':'application/json'})},body:data===undefined?undefined:JSON.stringify(data),cache:'no-store'});
  const j=await resp.json();
  if(!resp.ok)throw Object.assign(new Error(j.error||`HTTP ${resp.status}`),{status:resp.status});
  return j;
}
function notify(message,isError=false){
  const root=el('toast-root');
  root.innerHTML=`<div class="toast ${isError?'error':''}"><strong>${isError?'COMMAND NOT SENT':'CONTROL DECK'}</strong>${esc(message)}</div>`;
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>root.innerHTML='',3700);
}
function clock(){const d=new Date();el('top-time').textContent=d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',hour12:false});}
function linkStatus(ok){const node=el('top-link');node.className='connection-chip'+(ok?'':' offline');node.innerHTML=`<span class="dot"></span>${ok?'LINK ESTABLISHED':'OFFLINE'}`;}
async function startup(){
  el('settings-icon').innerHTML=svg('settings'); clock();setInterval(clock,15000);
  if(!token){showPairing();return;}
  await loadState();
  setInterval(async()=>{
    if(!token||!app)return;
    try{
      const fresh=await request('/api/state');
      const changed=fresh.last_import!==app.last_import||fresh.armed!==app.armed||fresh.version!==app.version||JSON.stringify(fresh.controls)!==JSON.stringify(app.controls);
      app=fresh;linkStatus(true);updateRail();
      if(changed && !el('modal-root').innerHTML){render();}
    }catch(err){linkStatus(false);if(err.status===401){token='';localStorage.removeItem('scdeck-token');showPairing();}}
  },9000);
}
async function loadState(){
  try{app=await request('/api/state');linkStatus(true);render();}
  catch(err){linkStatus(false);if(err.status===401){token='';localStorage.removeItem('scdeck-token');showPairing();}else notify(err.message,true);}
}
function showPairing(){
  const template=`<div class="modal-wrap pair-wrap"><div class="modal" role="dialog" aria-modal="true" aria-label="Pair companion"><div class="pair-logo">${svg('compass')}</div><div class="eyebrow" style="justify-content:center">INITIAL CONNECTION</div><h2>Pair with Serenity</h2><p>Start <b>START_DECK.bat</b> on your PC, then enter the six-digit PIN displayed in the companion window.</p><form id="pair-form"><div class="field"><label for="pair-pin">PAIRING CODE</label><input id="pair-pin" class="input" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]{6}" placeholder="••••••" required></div><button class="primary-btn" type="submit">CONNECT CONTROL DECK</button></form><p class="hint">Both devices must be on the same trusted local network.</p></div></div>`;
  el('modal-root').innerHTML=template;
  el('pair-form').onsubmit=async ev=>{ev.preventDefault();try{
    const result=await request('/api/pair',{pin:el('pair-pin').value});token=result.token;
    localStorage.setItem('scdeck-token',token);el('modal-root').innerHTML='';await loadState();
  }catch(e){notify(e.message,true);}};
}
function render(){
 if(!app)return;
 const version=app.version||'unknown';
 if(el('deck-footer-version'))el('deck-footer-version').innerHTML='<b>STAR CITIZEN DECK</b> / V'+esc(version);
 if(el('top-version'))el('top-version').textContent='v'+version;
 renderNav();renderContent();updateRail();
}
function renderNav(){
  el('profile-nav').innerHTML=app.profiles.map(p=>`<button data-profile="${esc(p.id)}" class="sidebar-button ${active===p.id?'active':''}" aria-label="${esc(p.name)}"><span>${svg(p.icon)}</span><small>${esc(p.short)}</small></button>`).join('');
  el('profile-nav').querySelectorAll('[data-profile]').forEach(node=>node.onclick=()=>{active=node.dataset.profile;render();el('main-area').scrollTop=0;});
  const btn=el('settings-nav');btn.classList.toggle('active',active==='settings');btn.onclick=()=>{active='settings';render();el('main-area').scrollTop=0;};
}
const heroTexts={
  home:['SYSTEM OVERVIEW','Your ship. One command center.','Favorite controls and quick access. Labels and bindings are editable in Settings.'],
  nav:['NAVIGATION SUITE','Travel without reaching for the keyboard.','Quantum travel, flight modes and energy distribution.'],
  scm:['COMBAT SUITE','Stay focused on the fight.','Targeting, weapons and defensive systems within easy reach.'],
  systems:['SHIP SYSTEMS','Every switch has a purpose.','Electrical systems, flight readiness, access and landing configuration.'],
  mining:['INDUSTRIAL SUITE','Precision at your fingertips.','Mining operator controls and an experimental local-value power slider.'],
  foot:['PERSONNEL SUITE','Equipment ready.','Useful on-foot controls for FPS activities and ground operations.'],
  utility:['AUXILIARY SUITE','Everything else, organized.','Cargo, salvage, EVA, camera and communication controls.'],
};
function renderContent(){if(active==='settings')return renderSettings();const p=app.profiles.find(x=>x.id===active)||app.profiles[0];const msgs=heroTexts[active];let filtered=app.controls.filter(c=>c.profile===active);const groups=[...new Set(filtered.map(c=>c.section))];
  el('main-area').innerHTML=`<div class="eyebrow">FLIGHT OPERATIONS / ${esc(p.short)}</div><div class="page-title"><div><h1>${esc(p.name)}</h1><p>${esc(p.subtitle)} · customizable control layout</p></div><div class="page-index">DECK ${String(app.profiles.findIndex(x=>x.id===active)+1).padStart(2,'0')} / 07</div></div>
  <section class="hero-card"><div><div class="hero-code">${esc(msgs[0])} / ACTIVE PANEL</div><h2>${esc(msgs[1])}</h2><p>${esc(msgs[2])}</p></div><div class="hero-orbit">${svg(p.icon)}</div></section>
  <div class="group-grid">${groups.map((group,index)=>`<section class="control-panel"><div class="panel-heading"><h3>${esc(group)}</h3><span>BUS ${String(index+1).padStart(2,'0')} / ${String(filtered.filter(c=>c.section===group).length).padStart(2,'0')}</span></div><div class="panel-controls">${filtered.filter(c=>c.section===group).map(controlHTML).join('')}</div></section>`).join('')}</div>`;
  el('main-area').querySelectorAll('[data-control]').forEach(btn=>btn.onclick=()=>activate(btn.dataset.control));
  el('main-area').querySelectorAll('[data-step]').forEach(btn=>btn.onclick=()=>activate(btn.dataset.step,btn.dataset.direction));
  el('main-area').querySelectorAll('[data-slider]').forEach(slider=>slider.oninput=()=>{
    localSliders[slider.dataset.slider]=slider.value;
    document.getElementById('val-'+slider.dataset.slider).textContent=slider.value+'%';
  });
}
function bindingLabel(control){return control.kind==='slider'?'STEP KEYS': control.binding?control.binding.replace(/^kb1_/i,'').replace(/\+/g,' + ').toUpperCase():'UNASSIGNED';}
function controlHTML(c){
  if(c.kind==='slider')return `<div class="slider-control"><div class="slider-head"><div><div class="slider-title">${esc(c.label)}</div><span class="ctl-mini">LOCAL VISUAL REFERENCE</span></div><div class="slider-val" id="val-${esc(c.id)}">${localSliders[c.id]??35}%</div></div><div class="slider-row"><button class="step-btn" data-step="${esc(c.id)}" data-direction="down" title="Decrease one step">−</button><input data-slider="${esc(c.id)}" type="range" min="0" max="100" value="${localSliders[c.id]??35}" aria-label="Local laser output preview"><button class="step-btn" data-step="${esc(c.id)}" data-direction="up" title="Increase one step">+</button></div><div class="slider-note">SLIDER IS A VISUAL GUIDE. ONLY THE ± BUTTONS SEND SINGLE INPUTS WHEN MAPPED.</div></div>`;
  let on=Boolean(localStates[c.id]);let symbol=c.kind==='toggle'?`<span class="micro-switch"><b></b></span>`:svg(c.kind==='hold'?'lock':c.confirm?'alert':'arrow');
  return `<button class="ctl ${c.confirm?'guarded ':''}${c.kind==='toggle'?'toggle-control ':''}${on?'active':''}" data-control="${esc(c.id)}" title="${esc(c.description)}"><span class="ctl-top"><span class="ctl-name">${esc(c.label)}</span><span class="ctl-glyph">${symbol}</span></span><span class="ctl-bottom"><span class="ctl-binding ${c.binding?'':'unmapped'}">${esc(bindingLabel(c))}</span><span class="ctl-mini">${c.kind==='toggle'?'COMMAND':c.kind==='hold'?'HOLD':c.confirm?'GUARDED':'EXECUTE'}</span></span></button>`;
}
function updateRail(){if(!app)return;
 const mapped=app.controls.filter(c=>c.binding||c.kind==='slider'&&(c.binding_up||c.binding_down)).length;
 const all=app.controls.length;
 const syncInfo=app.last_import?new Date(app.last_import).toLocaleString([], {month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}):'Not imported';
 el('status-rail').innerHTML=`<div class="rail-title">MISSION CONTROL / 01</div>
 <div class="rail-block"><div class="rail-kicker">LOCAL CONNECTION</div><div class="rail-value blue">● SERENITY LINK</div><div class="rail-small">Your iPad is connected to the Windows companion.</div><span class="rail-chip">LAN / CONNECTED</span></div>
 <div class="rail-block"><div class="rail-kicker">KEYBOARD OUTPUT</div><div class="rail-value ${app.armed?'blue':'red'}">${app.armed?'ARMED':'DISARMED'}</div><div class="rail-small">${app.armed?'Star Citizen must be the foreground window.':'Commands cannot reach the game until enabled in Settings.'}</div><button class="small-action" id="rail-arm">${app.armed?'DISARM OUTPUT':'OPEN SETTINGS TO ARM'}</button></div>
 <div class="rail-block"><div class="rail-kicker">BINDING COVERAGE</div><div class="rail-value">${mapped} <span style="color:#577f9f">/ ${all}</span> ASSIGNED</div><div class="rail-progress"><span style="width:${Math.round(100*mapped/all)}%"></span></div><div class="rail-small">From manual shortcuts and custom XML overrides.</div></div>
 <div class="rail-block"><div class="rail-kicker">LAST PROFILE IMPORT</div><div class="rail-value">${esc(syncInfo)}</div><div class="rail-small">${esc(app.last_file?app.last_file.split(/[\\/]/).pop():'No XML selected')}</div></div>
 <div class="rail-block"><div class="rail-kicker">STATE REPORTING</div><div class="rail-value">COMMAND ONLY</div><div class="rail-small">Toggle indicators are local estimates, not live readings from your ship.</div></div>
 <div class="rail-ornament"><svg viewBox="0 0 160 160"><circle cx="80" cy="80" r="65"/><circle cx="80" cy="80" r="49" stroke-dasharray="7 10"/><circle cx="80" cy="80" r="27"/><path d="M80 4v30M80 126v30M4 80h30M126 80h30M40 40l80 80M120 40l-80 80"/></svg></div>`;
 el('rail-arm').onclick=()=>{active='settings';settingsTab='connection';render();};
}
async function activate(id,direction){const ctl=app.controls.find(c=>c.id===id);if(!ctl)return;
 if((!ctl.binding&&ctl.kind!=='slider')||(ctl.kind==='slider'&&!ctl['binding_'+direction])){
   notify('"'+ctl.label+'" has no keyboard shortcut assigned. Set its binding under Settings.',true);return;}
 if(!app.armed){notify('Output is disarmed. Open Settings → Connection to enable commands.',true);return;}
 if(ctl.confirm&&!window.confirm('Send '+ctl.label+' command to Star Citizen?'))return;
 try{await request('/api/action',{id,direction});
   // No ship-state telemetry: never latch a toggle LED after merely sending a command.
   if(ctl.kind==='slider')localSliders[id]=Math.max(0,Math.min(100,Number(localSliders[id]??35)+(direction==='up'?1:-1)));
   notify(ctl.label+' → command sent (ship state not verified)');renderContent();
 }catch(e){notify(e.message,true);}
}
function renderSettings(){
 el('main-area').innerHTML=`<div class="eyebrow">PREFERENCES / CONFIGURATION</div><div class="page-title"><div><h1>Deck Settings</h1><p>Configure keybindings, connection and interface behavior.</p></div><div class="page-index">SYSTEM / CFG</div></div>
 <div class="settings-tabs"><button data-tab="bindings" class="tab ${settingsTab==='bindings'?'active':''}">KEYBINDINGS</button><button data-tab="connection" class="tab ${settingsTab==='connection'?'active':''}">CONNECTION</button><button data-tab="updates" class="tab ${settingsTab==='updates'?'active':''}">UPDATES</button><button data-tab="about" class="tab ${settingsTab==='about'?'active':''}">ABOUT</button></div><div id="settings-body"></div>`;
 el('main-area').querySelectorAll('[data-tab]').forEach(btn=>btn.onclick=()=>{settingsTab=btn.dataset.tab;renderSettings();});
 if(settingsTab==='bindings')renderBindingSettings();else if(settingsTab==='connection')renderConnectionSettings();else if(settingsTab==='updates')renderUpdateSettings();else renderAbout();
}
function renderBindingSettings(){
 const choices=app.profiles.map(p=>`<option value="${esc(p.id)}" ${profileFilter===p.id?'selected':''}>${esc(p.name)}</option>`).join('');
 el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">01 / XML PROFILE SYNCHRONIZATION</div><h3>Automatic keybinding import</h3><p>Combines custom bindings with an available local Star Citizen defaultProfile.xml and optionally monitors the live actionmaps.xml. The game's current files take precedence; default mappings are never guessed from external lists.</p>
 <div class="settings-row"><div class="field"><label for="xml-path">XML FILE OR MAPPINGS FOLDER ON SERENITY</label><input class="input" id="xml-path" value="${esc(app.source_path)}" placeholder="C:\\Program Files\\Roberts Space Industries\\StarCitizen\\LIVE\\USER\\Client\\0\\Controls\\Mappings"></div><button id="sync-btn" class="primary-btn">SYNC BINDINGS</button></div>
 <div class="toggle-row"><div class="setting-meta"><strong>Automatically watch game bindings</strong><small>Checks selected profile, live actionmaps.xml and extracted defaultProfile.xml for changes every 3 seconds.</small></div><input id="auto-toggle" class="ios-switch" type="checkbox" ${app.auto_sync?'checked':''} aria-label="Automatic XML sync"></div>
 <div class="toggle-row"><div class="setting-meta"><strong>Prefer currently active game bindings</strong><small>Uses Star Citizen's live actionmaps.xml over saved exports when available.</small></div><input id="live-toggle" class="ios-switch" type="checkbox" ${app.prefer_live?'checked':''} aria-label="Use active game bindings"></div>
 <div class="warning-line">Last import: <b>${esc(app.last_import||'Never')}</b> · ${app.catalog.length} total actions · ${app.defaults_count||0} game defaults<br>Custom source: ${esc(app.sync_source||'None')} ${app.active_file?'<br>Active game file: '+esc(app.active_file):''}<br>Default source: ${app.defaults_file?esc(app.defaults_file):'Not found — optional extracted defaultProfile.xml needed for full defaults. Ship Lights L is included as your confirmed reference.'}${app.import_error?'<br><b>'+esc(app.import_error)+'</b>':''}</div></section>
 <section class="settings-card"><div class="settings-heading">02 / CONTROL MAPPING EDITOR</div><h3>Editable iPad controls</h3><p>Select an action to follow imported keyboard overrides and local game defaults. When defaults are unavailable, missing assignments stay unassigned instead of being guessed.</p>
 <div class="search-row"><input class="input" id="filter-text" placeholder="Search controls..." value="${esc(search)}"><select id="filter-profile" class="input" style="max-width:190px"><option value="all">All profiles</option>${choices}</select><button id="add-control-btn" class="primary-btn">+ ADD</button></div><div id="binding-results"></div></section>`;
 el('sync-btn').onclick=async()=>{try{const p=el('xml-path').value.trim();const res=await request('/api/import',p?{path:p}:{});notify(`Synced ${res.total} actions (${res.defaults} game defaults) from ${res.source}`);app=await request('/api/state');renderSettings();updateRail();}catch(e){notify(e.message,true);}};
 el('auto-toggle').onchange=async ev=>{try{app=await request('/api/settings',{auto_sync:ev.target.checked});notify('Automatic sync '+(app.auto_sync?'enabled':'disabled'));}catch(e){notify(e.message,true);}};
 el('live-toggle').onchange=async ev=>{try{app=await request('/api/settings',{prefer_live:ev.target.checked});renderSettings();notify('Game binding source updated');}catch(e){notify(e.message,true);}};
 el('add-control-btn').onclick=()=>addControl();
 el('filter-text').oninput=e=>{search=e.target.value;renderBindingRows();};
 el('filter-profile').onchange=e=>{profileFilter=e.target.value;renderBindingRows();};
 renderBindingRows();
}
function renderBindingRows(){const term=search.toLowerCase().trim();const rows=app.controls.filter(c=>(profileFilter==='all'||c.profile===profileFilter)&&(!term||(c.label+' '+c.id+' '+c.section+' '+c.binding).toLowerCase().includes(term)));
 el('binding-results').innerHTML=`<div class="count-caption">${rows.length} CONTROLS</div><div class="binding-list">${rows.map(c=>`<div class="binding-row"><div><div class="binding-name">${esc(c.label)}</div><div class="binding-sub">${esc(c.profile.toUpperCase())} / ${esc(c.section)} · ${esc(c.manual?'MANUAL':c.action_ref?'XML LINKED':'NOT LINKED')}</div></div><div style="display:flex;align-items:center;gap:10px;min-width:0"><span class="binding-key ${c.binding?'':'empty'}" title="${esc(c.binding_source||'Not mapped')}">${esc(bindingLabel(c))}</span><button data-edit="${esc(c.id)}">EDIT</button></div></div>`).join('')}</div>`;
 el('binding-results').querySelectorAll('[data-edit]').forEach(btn=>btn.onclick=()=>editControl(btn.dataset.edit));
}
async function renderUpdateSettings(){
 el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">SOFTWARE / MAINTENANCE</div><h3>Companion updates</h3><p>Installed on Serenity: <strong>v${esc(app.version||'unknown')}</strong>. Existing controls, keyboard mappings, and pairing stay in your Windows user data folder.</p>
 <div class="update-console"><div class="update-indicator"><span class="update-led"></span><div><strong id="remote-update-title">Checking for releases…</strong><small id="remote-update-info">Public update mirror: GitHub Pages / star-citizen-deck.</small></div></div><button type="button" id="update-fetch" class="primary-btn" disabled>CHECKING…</button></div>
 <div class="modal-actions"><button id="update-check" type="button" class="secondary-btn">CHECK AGAIN</button></div>
 <details class="advanced-update"><summary>Advanced: install a trusted ZIP manually</summary><p>Use this only until the release channel is published or if Serenity cannot access GitHub. Keep the ZIP compressed.</p><div class="field"><label for="update-file">UPDATE PACKAGE (.ZIP)</label><input type="file" id="update-file" class="input" accept=".zip,application/zip"></div><div class="modal-actions"><button id="one-step-update" type="button" class="primary-btn">VERIFY ZIP, INSTALL &amp; RESTART</button></div></details>
 <div id="update-info" class="warning-line">Future updates use verified packages, persistent backups, and a Python import check. Keep START_DECK.bat open.</div></section>`;
 const info=el('remote-update-info'), title=el('remote-update-title'), fetchButton=el('update-fetch');
 async function check(){
  title.textContent='Checking release channel…'; fetchButton.disabled=true; fetchButton.textContent='CHECKING…';
  try {const r=await request('/api/update/check'); title.textContent=r.available?'UPDATE AVAILABLE: v'+r.latest:r.configured?'NO NEW RELEASE':'RELEASE CHANNEL NOT LIVE';
       info.textContent=r.note;fetchButton.disabled=!r.available;fetchButton.textContent=r.available?'INSTALL v'+r.latest:'UP TO DATE / OFFLINE';}
  catch(e){title.textContent='RELEASE CHECK FAILED';info.textContent=e.message;fetchButton.textContent='UNAVAILABLE';}
 }
 el('update-check').onclick=check;
 fetchButton.onclick=async()=>{
  if(!confirm('Install the verified published update and restart the Windows companion?'))return;
  fetchButton.disabled=true;fetchButton.textContent='VERIFYING RELEASE…';
  try{const r=await request('/api/update/fetch',{});await applyAndReconnect(r.version);}
  catch(e){info.textContent=e.message;notify(e.message,true);await check();}
 };
 el('one-step-update').onclick=async()=>{
  const file=el('update-file').files[0];if(!file)return notify('Select the trusted update ZIP first.',true);
  if(file.size>4_000_000)return notify('Update ZIP is larger than 4 MB.',true);
  if(!confirm('Verify this ZIP and install it on Serenity?'))return;
  const button=el('one-step-update');button.disabled=true;button.textContent='VERIFYING & INSTALLING…';
  try {
   const response=await fetch('/api/update/upload',{method:'POST',headers:{'X-Deck-Token':token,'Content-Type':'application/zip'},body:file,cache:'no-store'});
   const result=await response.json();if(!response.ok)throw new Error(result.error||'ZIP upload failed');
   await applyAndReconnect(result.version);
  } catch(e){button.disabled=false;button.textContent='VERIFY ZIP, INSTALL & RESTART';el('update-info').textContent=e.message;notify(e.message,true);}
 };
 async function applyAndReconnect(version){
  await request('/api/update/apply',{confirm:'INSTALL'});
  el('update-info').textContent='Installing v'+version+' on Serenity. Waiting for the companion to reconnect…';
  const started=Date.now();
  while(Date.now()-started<40000){
   await new Promise(resolve=>setTimeout(resolve,1250));
   try{const response=await fetch('/api/hello',{cache:'no-store'});if(!response.ok)continue;
       const state=await response.json();if(state.version===version){window.location.reload();return;}}
   catch(_){ /* Installer momentarily stops the old server. */ }
  }
  el('update-info').textContent='The restart has not been confirmed. Check the companion window on Serenity before trying again.';
 }
 await check();
}
function renderConnectionSettings(){
 el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">01 / INPUT SAFETY</div><h3>Live keyboard output</h3><p>Every button sends one user-requested keyboard press to the foreground Star Citizen window only. The deck never reads game memory, modifies game files, or runs automatic command sequences.</p>
 <div class="toggle-row"><div class="setting-meta"><strong>Arm keyboard controls</strong><small>Resets to OFF whenever you restart the companion. Available on Windows only.</small></div><input id="arm-toggle" class="ios-switch" type="checkbox" ${app.armed?'checked':''} ${!app.can_send?'disabled':''} aria-label="Arm keyboard output"></div>
 <div class="warning-line">CURRENT INPUT METHOD: <b>${esc(app.input_mode==='scan'?'SCAN-CODE TEST':'VIRTUAL KEY')}</b>. Scan-code mode was selected automatically on the v0.2.4 upgrade, with no extra setting needed.</div>
 <div class="field"><label>GAME KEYBOARD DELIVERY</label><select id="input-mode" class="input" ${app.can_send?'':'disabled'}><option value="virtual" ${(app.input_mode||'virtual')==='virtual'?'selected':''}>Standard virtual-key (original)</option><option value="scan" ${app.input_mode==='scan'?'selected':''}>Physical scan-code (test)</option></select><p class="hint">Star Citizen may process scan codes differently from virtual-key events. Both use Windows SendInput; neither guarantees the game will accept a command. Notepad diagnostic remains unchanged.</p></div>
 <div class="warning-line">${app.can_send?'Input is supported by this Windows companion, but compatibility with the game and its anti-cheat is not guaranteed.':'This preview is running on '+esc(app.system)+'. Live key input requires running the companion on Windows.'}</div></section>
 <section class="settings-card"><div class="settings-heading">02 / SAFE WINDOWS DIAGNOSTIC</div><h3>Notepad keyboard test</h3><p>Open Notepad on Serenity, click into a blank document, and keep it in the foreground. This sends exactly one <b>L</b> keystroke only if Windows confirms the foreground process is Notepad. Normal ship controls remain Star Citizen-only.</p>
 <div class="modal-actions"><button id="notepad-test" type="button" class="secondary-btn" ${app.can_send?'':'disabled'}>SEND TEST L TO NOTEPAD</button></div>
 <div id="notepad-result" class="warning-line">Requires keyboard output ARMED. The diagnostic is never sent to Star Citizen.</div></section>
 <section class="settings-card"><div class="settings-heading">03 / DEVICE INFO</div><h3>Serenity companion</h3><div class="toggle-row"><div class="setting-meta"><strong>Platform</strong><small>${esc(app.system)} / Star Citizen Deck companion v${esc(app.version||"unknown")}</small></div><span class="pill">CONNECTED</span></div><div class="toggle-row"><div class="setting-meta"><strong>Game profile</strong><small>${esc(app.profile_label)}</small></div><span class="pill">LOCAL</span></div><div class="toggle-row"><div class="setting-meta"><strong>Saved configuration</strong><small>Persistent on your PC; independent from Mongrel HUD</small></div><span class="pill">LOCAL</span></div></section>`;
 el('notepad-test').onclick=async()=>{
   const target=el('notepad-result');target.textContent='Checking Notepad foreground window and sending one L...';
   try{const result=await request('/api/diagnostic/notepad',{});
     target.textContent='Windows accepted test L. Check whether lowercase l appeared in Notepad. This does not verify Star Citizen input.';
     notify('Notepad diagnostic sent — check Notepad on Serenity');
   }catch(err){target.textContent=err.message;notify(err.message,true);}
 };
 el('input-mode').onchange=async e=>{
   try{app=await request('/api/settings',{input_mode:e.target.value});renderConnectionSettings();updateRail();notify('Input mode set to '+(app.input_mode==='scan'?'physical scan-code test':'standard virtual-key'));}
   catch(err){notify(err.message,true);renderConnectionSettings();}
 };
 el('arm-toggle').onchange=async e=>{if(e.target.checked&&!confirm('Arm the deck to send keyboard inputs to Star Citizen when it is in the foreground?')){e.target.checked=false;return;}
 try{app=await request('/api/settings',{armed:e.target.checked});renderConnectionSettings();updateRail();notify(app.armed?'Output ARMED — use caution':'Output safely DISARMED');}catch(err){notify(err.message,true);}};
}
function renderAbout(){el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">CONTROL DECK / BUILD 01</div><h3>Star Citizen Deck v${esc(app.version||"unknown")}</h3><p>Independent personal touchscreen companion for Star Citizen. Built with standard Python and browser technologies, no third-party dependencies, no installation or modification of game files.</p><div class="warning-line">Ship Lights has been confirmed working in Star Citizen on Serenity using scan-code keyboard input. Other commands remain unverified and may be ignored. Use only if allowed by the game's current rules. No macros or repeated unattended automation are implemented.</div></section><section class="settings-card"><h3>Known limits</h3><p>• No official live ship-state feed. Toggles are visual estimates.<br>• Full default coverage requires an extracted local defaultProfile.xml.<br>• Joystick axes and true analog sliders are not implemented.<br>• Keybinding importer does not change controls inside Star Citizen.<br>• Use on trusted LAN only: HTTP connection is not encrypted.</p></section>`;}
function editControl(id){const c=app.controls.find(x=>x.id===id);if(!c)return;
 const kindOptions=['button','toggle','hold','slider'].map(k=>`<option value="${k}" ${c.kind===k?'selected':''}>${k.toUpperCase()}</option>`).join('');
  const modal=`<div class="modal-wrap"><div class="modal" role="dialog" aria-modal="true" aria-label="Edit control"><div class="eyebrow">BINDING EDITOR / ${esc(c.profile.toUpperCase())}</div><h2>${esc(c.label)}</h2><p>Choose a linked XML action for automatic updates, or enter a keyboard shortcut manually.</p><form id="edit-form"><div class="modal-grid"><div class="field"><label>DISPLAY LABEL</label><input class="input" id="edit-label" value="${esc(c.label)}" required></div><div class="field"><label>CONTROL TYPE</label><select class="input" id="edit-kind">${kindOptions}</select></div></div>
 <div class="modal-grid"><div class="field"><label>PROFILE / PAGE</label><select class="input" id="edit-profile">${app.profiles.map(p=>`<option value="${esc(p.id)}" ${p.id===c.profile?'selected':''}>${esc(p.name)}</option>`).join('')}</select></div><div class="field"><label>CONTROL GROUP / SECTION</label><input class="input" id="edit-section" value="${esc(c.section)}" required></div></div>
 <div class="field"><label>BINDING SOURCE</label><select class="input" id="edit-source"><option value="xml" ${!c.manual?'selected':''}>Imported XML action (auto sync)</option><option value="manual" ${c.manual?'selected':''}>Manual keyboard mapping</option></select></div>
 <div class="field" id="action-field"><label>STAR CITIZEN ACTION ID</label><input class="input" id="edit-action" placeholder="Use Browse Imported Actions below" value="${esc(c.action_ref||'')}" autocapitalize="off" autocomplete="off" spellcheck="false"><div class="action-picker-tools"><button id="browse-actions" type="button" class="secondary-btn">BROWSE ${app.catalog.length} AVAILABLE ACTIONS</button><span class="hint" id="selected-action-status"></span></div><div id="action-picker" class="action-picker" hidden><label for="action-search">SEARCH GAME KEYBINDINGS</label><input class="input" id="action-search" type="search" placeholder="Search name, group or keyboard shortcut" autocomplete="off" autocapitalize="off" spellcheck="false"><div id="action-search-results" class="action-search-results"></div></div><p class="hint">Choose an action with a keyboard binding. The source label distinguishes local game defaults, custom keyboard overrides and your confirmed fallback.</p></div>
 <div class="field" id="manual-field"><label>KEY COMBINATION</label><input class="input" id="edit-manual" placeholder="e.g. LALT+R or F6" value="${esc(c.manual?c.binding:'')}"><p class="hint">Keyboard only; accepts modifiers and ordinary keys. No mouse movement, joystick input, or multi-action macros.</p></div>
 <div class="field"><label>KEY HOLD DURATION (40–3000 MS)</label><input type="number" min="40" max="3000" class="input" id="edit-hold" value="${Number(c.hold_ms)||100}"></div>
 <div id="step-settings" class="modal-grid"><div class="field"><label>SLIDER STEP UP</label><input class="input" id="edit-up" placeholder="e.g. LALT+UP" value="${esc(c.binding_up||'')}"></div><div class="field"><label>SLIDER STEP DOWN</label><input class="input" id="edit-down" placeholder="e.g. LALT+DOWN" value="${esc(c.binding_down||'')}"></div></div>
 <div class="modal-actions">${c.id.startsWith("custom_")?'<button id="edit-delete" type="button" class="danger-btn">DELETE</button>':''}<button id="edit-cancel" type="button" class="secondary-btn">CANCEL</button><button type="submit" class="primary-btn">SAVE CONTROL</button></div></form></div></div>`;
 el('modal-root').innerHTML=modal;
 const updateVisible=()=>{
   const xml=el('edit-source').value==='xml';el('action-field').style.display=xml?'block':'none';el('manual-field').style.display=xml?'none':'block';el('step-settings').style.display=el('edit-kind').value==='slider'?'grid':'none';
 };
 el('edit-source').onchange=updateVisible;el('edit-kind').onchange=updateVisible;updateVisible();
 // iPad Safari does not reliably show HTML datalist suggestions. Use a real, filtered list.
 const picker=el('action-picker');
 const selectedStatus=el('selected-action-status');
 const describeSelected=()=>{
   const ref=el('edit-action').value.trim();
   const found=app.catalog.find(a=>a.ref===ref);
   selectedStatus.textContent=!ref?'No action chosen':found?(found.keyboard?'Keyboard: '+found.keyboard.replace(/^kb1_/i,'').toUpperCase()+' ('+(found.origin||'imported')+')':'No supported keyboard binding'):'Not in this exported profile';
 };
 const showImported=()=>{
   const q=el('action-search').value.trim().toLowerCase();
   const matching=app.catalog.map((a,i)=>({...a,idx:i})).filter(a=>(a.ref+' '+a.map+' '+a.name+' '+a.keyboard+' '+(a.raw||[]).join(' ')).toLowerCase().includes(q));
   const html=matching.map(a=>`<button type="button" class="action-option" data-action-index="${a.idx}"><span class="action-title">${esc(a.name.replace(/_/g,' '))}</span><span class="action-ref">${esc(a.ref)}</span><span class="action-binding ${a.keyboard?'':'action-unavailable'}">${esc(a.keyboard?a.keyboard.replace(/^kb1_/i,'').toUpperCase():'NO KEYBOARD BINDING')} · ${esc(a.origin||'custom')}</span></button>`).join('');
   el('action-search-results').innerHTML=matching.length?html:`<div class="action-empty">No available actions match “${esc(q)}”. Install or extract a current defaultProfile.xml into the companion data directory for full default coverage, or assign a manual keyboard shortcut.</div>`;
   el('action-search-results').querySelectorAll('[data-action-index]').forEach(btn=>btn.onclick=()=>{
     const a=app.catalog[Number(btn.dataset.actionIndex)];
     if(!a)return;
     el('edit-action').value=a.ref;
     picker.hidden=true;
     el('browse-actions').textContent=`BROWSE ${app.catalog.length} AVAILABLE ACTIONS`;
     describeSelected();
   });
 };
 el('browse-actions').onclick=()=>{
   picker.hidden=!picker.hidden;
   el('browse-actions').textContent=picker.hidden?`BROWSE ${app.catalog.length} AVAILABLE ACTIONS`:'CLOSE ACTION LIST';
   if(!picker.hidden){showImported();el('action-search').focus();}
 };
 el('action-search').oninput=showImported;
 el('edit-action').oninput=describeSelected;
 describeSelected();
 el('edit-cancel').onclick=()=>el('modal-root').innerHTML='';
 if(c.id.startsWith('custom_'))el('edit-delete').onclick=async()=>{if(confirm('Delete this custom control?')){try{await request('/api/control/delete',{id:c.id});app=await request('/api/state');el('modal-root').innerHTML='';render();}catch(e){notify(e.message,true);}}};
 el('edit-form').onsubmit=async e=>{e.preventDefault();const patch={id,label:el('edit-label').value,profile:el('edit-profile').value,section:el('edit-section').value,kind:el('edit-kind').value,hold_ms:Number(el('edit-hold').value)};
 if(el('edit-source').value==='xml')patch.action_ref=el('edit-action').value.trim();else patch.manual_binding=el('edit-manual').value.trim();
 if(patch.kind==='slider'){patch.binding_up=el('edit-up').value.trim();patch.binding_down=el('edit-down').value.trim();}
 try{await request('/api/control',patch);app=await request('/api/state');el('modal-root').innerHTML='';render();notify('Saved '+patch.label);}catch(err){notify(err.message,true);}};
}
window.addEventListener('DOMContentLoaded',startup);

async function addControl(){
 const label=prompt('Name your new control:');if(!label)return;
 const profile=profileFilter==='all'?'home':profileFilter;
 try{const c=await request('/api/control/create',{label,profile});app=await request('/api/state');render();editControl(c.id);}catch(e){notify(e.message,true);}
}
