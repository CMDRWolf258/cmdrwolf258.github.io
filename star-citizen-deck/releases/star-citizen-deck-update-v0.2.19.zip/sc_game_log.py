"""Read-only, local Star Citizen Game.log intelligence for the iPad Deck.

Parses only specific documented community-observed 4.x event signatures.
Never returns raw log lines, credentials, account IDs or arbitrary log content.
Not a gameplay telemetry API: location, ship and quantum target are last
observed log events, not confirmed continuous in-game state.
"""
from __future__ import annotations

import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

CHANNELS = ("LIVE", "PTU", "EPTU", "TECH-PREVIEW", "HOTFIX")
MAX_BACKFILL = 2_000_000
MAX_READ = 256_000
MAX_EVENTS = 12
MAX_LINE = 8_192

SHIP_JOIN = re.compile(r'Added notification "You have joined channel \'@vehicle_Name([^\':]+)\s*:\s*[^\']+\'')
SHIP_EXIT = re.compile(r'Added notification "You have left the channel \'@vehicle_Name([^\':]+)\s*:\s*[^\']+\'')
QT_TARGET = re.compile(r'Player has selected point ([A-Za-z0-9_.-]+) as their destination')
QT_FUEL = re.compile(r'<Player Requested Fuel to Quantum Target - Local>.*destination ([A-Za-z0-9_.-]+)')
QT_ARRIVED = re.compile(r'Quantum Drive has arrived at final destination')
LOCATION_REQUEST = re.compile(r'<RequestLocationInventory> Player\[[^\]]+\] requested inventory for Location\[([^\]]+)\]')
CONTRACT = re.compile(r'Added notification "Contract (Accepted|Complete|Failed):\s*(.{1,150}?):\s*"')
JURISDICTION = re.compile(r'Added notification "Entered ([^"]{1,90}) Jurisdiction')
LOGIN = re.compile(r'nickname="[^"]+"\s+playerGEID=\d+')


def safe_label(value, max_length=90):
    """Restrict all user-facing strings and prohibit raw log fragments."""
    cleaned = re.sub(r'[\x00-\x1f\x7f<>]', '', str(value)).strip()
    return cleaned[:max_length]


def game_log_candidates(source_xml="", explicit_path=""):
    """Ordered, nonrecursive install-path checks; no game modifications."""
    if explicit_path:
        candidate = Path(explicit_path).expanduser()
        return [candidate]
    candidates = []
    if source_xml:
        source = Path(source_xml).expanduser()
        for parent in (source, *source.parents):
            if parent.name.upper() in CHANNELS:
                candidates.append(parent / "Game.log")
                break
    for drive in "CDEFGH":
        for prefix in (
            f"{drive}:/Program Files/Roberts Space Industries/StarCitizen",
            f"{drive}:/Roberts Space Industries/StarCitizen",
            f"{drive}:/StarCitizen",
            f"{drive}:/Games/StarCitizen",
            f"{drive}:/Games/Roberts Space Industries/StarCitizen",
        ):
            for channel in CHANNELS:
                candidates.append(Path(prefix) / channel / "Game.log")
    unique = []
    seen = set()
    for candidate in candidates:
        key = str(candidate).casefold()
        if key not in seen:
            seen.add(key)
            unique.append(candidate)
    return unique


def find_game_log(source_xml="", explicit_path=""):
    paths = game_log_candidates(source_xml, explicit_path)
    if explicit_path:
        path = paths[0]
        if path.name.lower() != "game.log":
            return None, "Selected path must end with Game.log"
        if not path.is_file():
            return None, "Selected Game.log does not exist or cannot be read"
        return path, ""
    for path in paths:
        if path.is_file():
            return path, ""
    return None, "No Game.log detected. Check the game installation or set its path in Settings."


class GameLogMonitor:
    def __init__(self, get_settings):
        self._get_settings = get_settings
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread = None
        self._path = None
        self._ident = None
        self._offset = 0
        self._partial = b""
        self._error = ""
        self._backfilling = False
        self._modified = None
        self._reset()

    def _reset(self):
        self._events = []
        self._backfilling = False
        self._ship = ""
        self._location_event = ""
        self._quantum_target = ""
        self._quantum_status = "Unknown"
        self._jurisdiction = ""
        self._contracts = {}
        self._login_observed = False
        self._sequence = getattr(self, "_sequence", 0) + 1

    def start(self):
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._run, name="star-citizen-log-read-only", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)

    def _run(self):
        while not self._stop.wait(1.5):
            try:
                self.poll_once()
            except Exception:
                with self._lock:
                    self._error = "Game.log monitor could not read the selected log"

    def _add_event(self, kind, detail, historical):
        detail = safe_label(detail)
        if not detail:
            return
        self._events.insert(0, {
            "type": kind,
            "detail": detail,
            "observed_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "historical": historical,
        })
        del self._events[MAX_EVENTS:]
        self._sequence += 1

    def _parse(self, raw_line, historical=False):
        line = raw_line[:MAX_LINE]
        if LOGIN.search(line):
            self._login_observed = True
            self._ship = ""
            self._location_event = ""
            self._quantum_target = ""
            self._quantum_status = "Unknown"
            self._contracts = {}
            self._events = []
            self._add_event("session", "Player login observed in Game.log", historical)
            return
        match = SHIP_JOIN.search(line)
        if match:
            # The text is a ship comms channel, not proof the pilot is seated.
            self._ship = safe_label(match.group(1).replace("_", " "))
            self._add_event("ship_channel", "Joined ship channel: " + self._ship, historical)
            return
        match = SHIP_EXIT.search(line)
        if match:
            ship = safe_label(match.group(1).replace("_", " "))
            if self._ship == ship:
                self._ship = ""
            self._add_event("ship_channel", "Left ship channel: " + ship, historical)
            return
        match = QT_TARGET.search(line)
        if match:
            self._quantum_target = safe_label(match.group(1))
            self._quantum_status = "Selected"
            self._add_event("quantum", "Quantum target selected: " + self._quantum_target, historical)
            return
        match = QT_FUEL.search(line)
        if match:
            target = safe_label(match.group(1))
            self._add_event("quantum", "Fuel calculation requested: " + target, historical)
            return
        if QT_ARRIVED.search(line):
            self._quantum_status = "Arrival reported"
            self._add_event("quantum", "Quantum arrival reported (destination not independently confirmed)", historical)
            return
        match = LOCATION_REQUEST.search(line)
        if match:
            loc = safe_label(match.group(1))
            self._location_event = loc
            self._add_event("location_event", "Inventory requested near: " + loc, historical)
            return
        match = JURISDICTION.search(line)
        if match:
            self._jurisdiction = safe_label(match.group(1))
            self._add_event("jurisdiction", "Entered jurisdiction: " + self._jurisdiction, historical)
            return
        match = CONTRACT.search(line)
        if match:
            action = match.group(1)
            name = safe_label(match.group(2))
            self._contracts[name] = "Accepted" if action == "Accepted" else ("Completed" if action == "Complete" else "Failed")
            self._add_event("contract", "Contract " + self._contracts[name].lower() + ": " + name, historical)

    def poll_once(self):
        """Single deterministic read step; tests can call without a thread."""
        with self._lock:
            source, manual = self._get_settings()
            current, error = find_game_log(source, manual)
            if current is None:
                if self._path is not None:
                    self._path = None
                    self._ident = None
                    self._offset = 0
                    self._partial = b""
                    self._modified = None
                    self._reset()
                self._error = error
                return
            try:
                st = current.stat()
                identity = (str(current).casefold(), st.st_dev, st.st_ino)
                changed = self._ident != identity or st.st_size < self._offset
                if changed:
                    self._reset()
                    self._ident = identity
                    self._path = current
                    self._partial = b""
                    self._backfilling = True
                    self._offset = max(0, st.st_size - MAX_BACKFILL)
                self._modified = st.st_mtime
                self._error = ""
                with current.open("rb") as f:
                    f.seek(self._offset)
                    chunk = f.read(MAX_READ)
                    self._offset = f.tell()
                if not chunk:
                    return
                data = self._partial + chunk
                lines = data.split(b"\n")
                self._partial = lines.pop()[-MAX_LINE:]
                if changed and st.st_size > MAX_BACKFILL and lines:
                    # Skip first partial line when starting in a log tail.
                    lines.pop(0)
                for raw in lines:
                    self._parse(raw.decode("utf-8", errors="replace"), historical=self._backfilling)
                if self._offset >= st.st_size:
                    self._backfilling = False
            except OSError:
                self._error = "Could not open Game.log for read-only monitoring"

    def snapshot(self):
        with self._lock:
            age = max(0, int(time.time() - self._modified)) if self._modified is not None else None
            status = "missing" if self._path is None else "stale" if age is not None and age > 900 else "monitoring"
            return {
                "status": status,
                "error": self._error,
                "source": str(self._path) if self._path else "",
                "log_age_seconds": age,
                "ship_channel": self._ship,
                "location_activity": self._location_event,
                "jurisdiction": self._jurisdiction,
                "quantum_target": self._quantum_target,
                "quantum_status": self._quantum_status,
                "contracts": [{"name": k, "status": v} for k, v in list(self._contracts.items())[-6:]],
                "events": list(self._events),
                "login_observed": self._login_observed,
                "sequence": self._sequence,
                "note": "Log-derived events only; no ship telemetry or confirmed live Starmap route",
            }
