/* Star Citizen Control Deck — version from Windows companion API. */
'use strict';
const icons = {
 grid:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
 compass:'<circle cx="12" cy="12" r="9"/><path d="m15.9 8.1-3 6-4.8 2.1 2-5.4z"/>',
 target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 1v5m0 12v5M1 12h5m12 0h5"/>',
 cpu:'<rect x="5" y="5" width="14" height="14" rx="2"/><path d="M9 9h6v6H9zM9 1v4m6-4v4M9 19v4m6-4v4M1 9h4M1 15h4m14-6h4m-4 6h4"/>',
 pickaxe:'<path d="m14 8-7 13M2 5c7-4 14-3 19 3-8-1-13 1-16 8"/>',
 person:'<circle cx="12" cy="6" r="3.2"/><path d="M5 21v-3c0-7 14-7 14 0v3M9 12v7m6-7v7"/>',
 sliders:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="8" cy="6" r="2" fill="#07111d"/><circle cx="15" cy="12" r="2" fill="#07111d"/><circle cx="10" cy="18" r="2" fill="#07111d"/>',
 settings:'<circle cx="12" cy="12" r="3.5"/><path d="M9 2h6l.5 2.5 2 1 2.2-1.2 3 5-2 1.7v2.2l2 1.7-3 5-2.2-1.2-2 1L15 22H9l-.5-2.3-2-1-2.2 1.2-3-5 2-1.7v-2.2l-2-1.7 3-5 2.2 1.2 2-1z"/>',
 bolt:'<path d="m13 2-9 12h7l-1 8 10-13h-7z"/>',
 toggle:'<path d="M12 2v10M6.4 6.5a9 9 0 1 0 11.2 0"/>',
 circle:'<circle cx="12" cy="12" r="8"/><path d="m9 12 2 2 4-4"/>',
 arrow:'<path d="M4 12h16M14 6l6 6-6 6"/>',
 lock:'<rect x="5" y="10" width="14" height="12" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
 sync:'<path d="M21 11A9 9 0 0 0 5 5L3 7m0-5v5h5M3 13a9 9 0 0 0 16 6l2-2m0 5v-5h-5"/>',
 shield:'<path d="m12 2 9 4v6c0 5-3.3 8.3-9 10-5.7-1.7-9-5-9-10V6z"/>',
 chevron:'<path d="m5 9 7 7 7-7"/>',
 edit:'<path d="M3 21l5-1 13-13-4-4L4 16zM14 6l4 4"/>',
 alert:'<path d="m12 2 10 19H2zM12 8v6m0 3v1"/>',
};
const svg=(name,css='')=>`<svg class="${css}" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" fill="none" aria-hidden="true">${icons[name]||icons.circle}</svg>`;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let token=localStorage.getItem('scdeck-token')||'';
let app=null,active='home',settingsTab='bindings',profileFilter='all',search='',localStates={},localSliders={};
let toastTimer=null;
const activeHoldTouches=new Map();
const el=id=>document.getElementById(id);
async function request(path,data){
  let resp=await fetch(path,{method:data===undefined?'GET':'POST',headers:{...(token?{'X-Deck-Token':token}:{}),...(data===undefined?{}:{'Content-Type':'application/json'})},body:data===undefined?undefined:JSON.stringify(data),cache:'no-store'});
  const j=await resp.json();
  if(!resp.ok)throw Object.assign(new Error(j.error||`HTTP ${resp.status}`),{status:resp.status});
  return j;
}
function notify(message,isError=false){
  const root=el('toast-root');
  root.innerHTML=`<div class="toast ${isError?'error':''}"><strong>${isError?'COMMAND NOT SENT':'CONTROL DECK'}</strong>${esc(message)}</div>`;
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>root.innerHTML='',3700);
}
function clock(){const d=new Date();el('top-time').textContent=d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',hour12:false});}
function linkStatus(ok){const node=el('top-link');node.className='connection-chip'+(ok?'':' offline');node.innerHTML=`<span class="dot"></span>${ok?'LINK ESTABLISHED':'OFFLINE'}`;}
async function startup(){
  el('settings-icon').innerHTML=svg('settings'); clock();setInterval(clock,15000);
  if(!token){showPairing();return;}
  await loadState();
  setInterval(async()=>{
    if(!token||!app)return;
    try{
      const fresh=await request('/api/state');
      const changed=fresh.last_import!==app.last_import||fresh.armed!==app.armed||fresh.version!==app.version||JSON.stringify(fresh.controls)!==JSON.stringify(app.controls);
      app=fresh;linkStatus(true);updateRail();
      if(changed && !el('modal-root').innerHTML){render();}
    }catch(err){linkStatus(false);if(err.status===401){token='';localStorage.removeItem('scdeck-token');showPairing();}}
  },9000);
}
async function loadState(){
  try{app=await request('/api/state');linkStatus(true);render();}
  catch(err){linkStatus(false);if(err.status===401){token='';localStorage.removeItem('scdeck-token');showPairing();}else notify(err.message,true);}
}
function showPairing(){
  const template=`<div class="modal-wrap pair-wrap"><div class="modal" role="dialog" aria-modal="true" aria-label="Pair companion"><div class="pair-logo">${svg('compass')}</div><div class="eyebrow" style="justify-content:center">INITIAL CONNECTION</div><h2>Pair with Serenity</h2><p>Start <b>START_DECK.bat</b> on your PC, then enter the six-digit PIN displayed in the companion window.</p><form id="pair-form"><div class="field"><label for="pair-pin">PAIRING CODE</label><input id="pair-pin" class="input" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]{6}" placeholder="••••••" required></div><button class="primary-btn" type="submit">CONNECT CONTROL DECK</button></form><p class="hint">Both devices must be on the same trusted local network.</p></div></div>`;
  el('modal-root').innerHTML=template;
  el('pair-form').onsubmit=async ev=>{ev.preventDefault();try{
    const result=await request('/api/pair',{pin:el('pair-pin').value});token=result.token;
    localStorage.setItem('scdeck-token',token);el('modal-root').innerHTML='';await loadState();
  }catch(e){notify(e.message,true);}};
}
function render(){
 if(!app)return;
 document.body.classList.toggle('cockpit-page', active!=='settings');
 const version=app.version||'unknown';
 if(el('deck-footer-version'))el('deck-footer-version').innerHTML='<b>STAR CITIZEN DECK</b> / V'+esc(version);
 if(el('top-version'))el('top-version').textContent='v'+version;
 renderNav();renderContent();updateRail();
}
function renderNav(){
  el('profile-nav').innerHTML=app.profiles.map(p=>`<button data-profile="${esc(p.id)}" class="sidebar-button ${active===p.id?'active':''}" aria-label="${esc(p.name)}"><span>${svg(p.icon)}</span><small>${esc(p.short)}</small></button>`).join('');
  el('profile-nav').querySelectorAll('[data-profile]').forEach(node=>node.onclick=()=>{active=node.dataset.profile;render();el('main-area').scrollTop=0;});
  const btn=el('settings-nav');btn.classList.toggle('active',active==='settings');btn.onclick=()=>{active='settings';render();el('main-area').scrollTop=0;};
}
const heroTexts={
  home:['SYSTEM OVERVIEW','Your ship. One command center.','Favorite controls and quick access. Labels and bindings are editable in Settings.'],
  nav:['NAVIGATION SUITE','Travel without reaching for the keyboard.','Quantum travel, flight modes and energy distribution.'],
  scm:['COMBAT SUITE','Stay focused on the fight.','Targeting, weapons and defensive systems within easy reach.'],
  systems:['SHIP SYSTEMS','Every switch has a purpose.','Electrical systems, flight readiness, access and landing configuration.'],
  mining:['INDUSTRIAL SUITE','Precision at your fingertips.','Mining operator controls and an experimental local-value power slider.'],
  foot:['PERSONNEL SUITE','Equipment ready.','Useful on-foot controls for FPS activities and ground operations.'],
  utility:['AUXILIARY SUITE','Everything else, organized.','Cargo, salvage, EVA, camera and communication controls.'],
};
function renderContent(){
  if(active==='settings')return renderSettings();
  renderCockpitContent();
}

function bindingLabel(control){return control.kind==='slider'?'STEP KEYS': control.binding?control.binding.replace(/^(kb1_|mo1_)/i,'').replace(/mwheel_up/ig,'WHEEL UP').replace(/mwheel_down/ig,'WHEEL DOWN').replace(/\+/g,' + ').toUpperCase():'UNASSIGNED';}
function controlHTML(c){
  if(c.kind==='slider')return `<div class="slider-control"><div class="slider-head"><div><div class="slider-title">${esc(c.label)}</div><span class="ctl-mini">LOCAL VISUAL REFERENCE</span></div><div class="slider-val" id="val-${esc(c.id)}">${localSliders[c.id]??35}%</div></div><div class="slider-row"><button class="step-btn" data-step="${esc(c.id)}" data-direction="down" title="Decrease one step">−</button><input data-slider="${esc(c.id)}" type="range" min="0" max="100" value="${localSliders[c.id]??35}" aria-label="Local laser output preview"><button class="step-btn" data-step="${esc(c.id)}" data-direction="up" title="Increase one step">+</button></div><div class="slider-note">SLIDER IS A VISUAL GUIDE. ONLY THE ± BUTTONS SEND SINGLE INPUTS WHEN MAPPED.</div></div>`;
  let on=Boolean(localStates[c.id]);let symbol=c.kind==='toggle'?`<span class="micro-switch"><b></b></span>`:svg(c.kind==='hold'?'lock':c.confirm?'alert':'arrow');
  return `<button class="ctl ${c.confirm?'guarded ':''}${c.kind==='toggle'?'toggle-control ':''}${on?'active':''}" data-control="${esc(c.id)}" title="${esc(c.description)}"><span class="ctl-top"><span class="ctl-name">${esc(c.label)}</span><span class="ctl-glyph">${symbol}</span></span><span class="ctl-bottom"><span class="ctl-binding ${c.binding?'':'unmapped'}">${esc(bindingLabel(c))}</span><span class="ctl-mini">${c.kind==='toggle'?'COMMAND':c.kind==='hold'?'TOUCH + HOLD':c.confirm?'GUARDED':'EXECUTE'}</span></span></button>`;
}
function updateRail(){if(!app)return;
 const mapped=app.controls.filter(c=>c.binding||c.kind==='slider'&&(c.binding_up||c.binding_down)).length;
 const all=app.controls.length;
 const syncInfo=app.last_import?new Date(app.last_import).toLocaleString([], {month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}):'Not imported';
 el('status-rail').innerHTML=`<div class="rail-title">MISSION CONTROL / 01</div>
 <div class="rail-block"><div class="rail-kicker">LOCAL CONNECTION</div><div class="rail-value blue">● SERENITY LINK</div><div class="rail-small">Your iPad is connected to the Windows companion.</div><span class="rail-chip">LAN / CONNECTED</span></div>
 <div class="rail-block"><div class="rail-kicker">KEYBOARD OUTPUT</div><div class="rail-value ${app.armed?'blue':'red'}">${app.armed?'ARMED':'DISARMED'}</div><div class="rail-small">${app.armed?'Star Citizen must be the foreground window.':'Commands cannot reach the game until enabled in Settings.'}</div><button class="small-action" id="rail-arm">${app.armed?'DISARM OUTPUT':'OPEN SETTINGS TO ARM'}</button></div>
 <div class="rail-block"><div class="rail-kicker">BINDING COVERAGE</div><div class="rail-value">${mapped} <span style="color:#577f9f">/ ${all}</span> ASSIGNED</div><div class="rail-progress"><span style="width:${Math.round(100*mapped/all)}%"></span></div><div class="rail-small">From effective game bindings and manual shortcuts. Unassigned MFD actions need in-game keys.</div></div>
 <div class="rail-block"><div class="rail-kicker">LAST PROFILE IMPORT</div><div class="rail-value">${esc(syncInfo)}</div><div class="rail-small">${esc(app.last_file?app.last_file.split(/[\\/]/).pop():'No XML selected')}</div></div>
 <div class="rail-block"><div class="rail-kicker">STATE REPORTING</div><div class="rail-value">COMMAND ONLY</div><div class="rail-small">Toggle indicators are local estimates, not live readings from your ship.</div></div>
 <div class="rail-ornament"><svg viewBox="0 0 160 160"><circle cx="80" cy="80" r="65"/><circle cx="80" cy="80" r="49" stroke-dasharray="7 10"/><circle cx="80" cy="80" r="27"/><path d="M80 4v30M80 126v30M4 80h30M126 80h30M40 40l80 80M120 40l-80 80"/></svg></div>`;
 el('rail-arm').onclick=()=>{active='settings';settingsTab='connection';render();};
}
async function activate(id,direction){const ctl=app.controls.find(c=>c.id===id);if(!ctl)return;
  if(ctl.kind==='hold'){notify('Touch and hold '+ctl.label+' to activate; release to stop.',true);return;}
 if((!ctl.binding&&ctl.kind!=='slider')||(ctl.kind==='slider'&&!ctl['binding_'+direction])){
   notify('"'+ctl.label+'" has no keyboard shortcut assigned. Set its binding under Settings.',true);return;}
 if(!app.armed){notify('Output is disarmed. Open Settings → Connection to enable commands.',true);return;}
 if(ctl.confirm&&!window.confirm('Send '+ctl.label+' command to Star Citizen?'))return;
 try{await request('/api/action',{id,direction});
   // No ship-state telemetry: never latch a toggle LED after merely sending a command.
   if(ctl.kind==='slider')localSliders[id]=Math.max(0,Math.min(100,Number(localSliders[id]??35)+(direction==='up'?1:-1)));
   notify(ctl.label+' → command sent (ship state not verified)');renderContent();
 }catch(e){notify(e.message,true);}
}
// Pointer-held buttons: release on touch-up, focus loss or disconnection.
function stopTouchHold(id){
 const h=activeHoldTouches.get(id);
 if(!h || h.ended)return;
 h.ended=true;
 clearInterval(h.heartbeat);
 h.button.classList.remove('pulse');
 activeHoldTouches.delete(id);
 h.start.then(()=>request('/api/hold',{id,phase:'stop'})).catch(()=>{});
}
function beginTouchHold(id,button,event){
 if(activeHoldTouches.has(id))return;
 const ctl=app?.controls.find(x=>x.id===id);
 if(!ctl || ctl.kind!=='hold')return;
 if(!ctl.binding){notify(ctl.label+' has no keyboard or mouse-button binding.',true);return;}
 if(!app.armed){notify('Output is disarmed. Arm it in Settings → Connection.',true);return;}
 if(ctl.confirm){notify('Guarded controls cannot use continuous hold.',true);return;}
 if(event.button!==undefined && event.button!==0)return;
 event.preventDefault();
 try{button.setPointerCapture(event.pointerId);}catch(_){}
 const h={button,ended:false,heartbeat:null,start:null};
 activeHoldTouches.set(id,h);button.classList.add('pulse');
 h.start=request('/api/hold',{id,phase:'start'});
 h.start.then(()=>{
   if(h.ended)return;
   h.heartbeat=setInterval(()=>{
     if(h.ended)return;
     request('/api/hold',{id,phase:'heartbeat'}).catch(error=>{
       if(!h.ended){notify('Hold ended: '+error.message,true);stopTouchHold(id);}
     });
   },550);
   const line=el('cockpit-action-line');
   if(line)line.textContent=ctl.label.toUpperCase()+' / HELD UNTIL RELEASED';
 }).catch(error=>{if(!h.ended){notify(error.message,true);stopTouchHold(id);}});
}
window.addEventListener('blur',()=>{for(const id of [...activeHoldTouches.keys()])stopTouchHold(id);});
document.addEventListener('visibilitychange',()=>{
 if(document.hidden)for(const id of [...activeHoldTouches.keys()])stopTouchHold(id);
});
window.addEventListener('pagehide',()=>{
 for(const id of [...activeHoldTouches.keys()]){
   stopTouchHold(id);
   if(token)fetch('/api/hold',{method:'POST',keepalive:true,
     headers:{'X-Deck-Token':token,'Content-Type':'application/json'},
     body:JSON.stringify({id,phase:'stop'})}).catch(()=>{});
 }
});
function renderSettings(){
 el('main-area').innerHTML=`<div class="eyebrow">PREFERENCES / CONFIGURATION</div><div class="page-title"><div><h1>Deck Settings</h1><p>Configure keybindings, connection and interface behavior.</p></div><div class="page-index">SYSTEM / CFG</div></div>
 <div class="settings-tabs"><button data-tab="bindings" class="tab ${settingsTab==='bindings'?'active':''}">KEYBINDINGS</button><button data-tab="connection" class="tab ${settingsTab==='connection'?'active':''}">CONNECTION</button><button data-tab="updates" class="tab ${settingsTab==='updates'?'active':''}">UPDATES</button><button data-tab="about" class="tab ${settingsTab==='about'?'active':''}">ABOUT</button></div><div id="settings-body"></div>`;
 el('main-area').querySelectorAll('[data-tab]').forEach(btn=>btn.onclick=()=>{settingsTab=btn.dataset.tab;renderSettings();});
 if(settingsTab==='bindings')renderBindingSettings();else if(settingsTab==='connection')renderConnectionSettings();else if(settingsTab==='updates')renderUpdateSettings();else renderAbout();
}
function bindingPeers(control){
  const report=app?.binding_report||{};
  const ids=report.shared_by_id?.[control.id]||[];
  return ids.map(id=>app.controls.find(c=>c.id===id)?.label||id);
}
function bindingConflictLabels(control){
  const ids=app?.binding_report?.conflicts_by_id?.[control.id]||[];
  return ids.map(id=>app.controls.find(c=>c.id===id)?.label||id);
}
function renderBindingSettings(){
 const choices=app.profiles.map(p=>`<option value="${esc(p.id)}" ${profileFilter===p.id?'selected':''}>${esc(p.name)}</option>`).join('');
 el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">01 / XML PROFILE SYNCHRONIZATION</div><h3>Automatic keybinding import</h3><p>Combines custom bindings with an available local Star Citizen defaultProfile.xml and optionally monitors the live actionmaps.xml. The game's current files take precedence; default mappings are never guessed from external lists.</p>
 <div class="settings-row"><div class="field"><label for="xml-path">XML FILE OR MAPPINGS FOLDER ON SERENITY</label><input class="input" id="xml-path" value="${esc(app.source_path)}" placeholder="C:\\Program Files\\Roberts Space Industries\\StarCitizen\\LIVE\\USER\\Client\\0\\Controls\\Mappings"></div><button id="sync-btn" class="primary-btn">SYNC BINDINGS</button></div>
 <div class="settings-card defaults-import"><h3>Import current game bindings</h3><p>Merge your active Star Citizen <b>actionmaps.xml</b> customizations with a verified <b>4.10.2 LIVE default profile</b>, sourced from SC Keymap. No Data.p4k extraction or downloaded executable. Only the Deck's own mapping cache changes; your game settings and HOTAS are untouched. If Star Citizen updates beyond 4.10.2, review the baseline version before relying on new/changed game actions.</p><button id="get-game-defaults" class="primary-btn" type="button">IMPORT CURRENT BINDINGS</button><p id="defaults-import-status" class="hint" role="status">Currently ${app.defaults_count||0} game defaults available.</p></div>
 <div class="toggle-row"><div class="setting-meta"><strong>Automatically watch game bindings</strong><small>Checks selected profile, live actionmaps.xml and extracted defaultProfile.xml for changes every 3 seconds.</small></div><input id="auto-toggle" class="ios-switch" type="checkbox" ${app.auto_sync?'checked':''} aria-label="Automatic XML sync"></div>
 <div class="toggle-row"><div class="setting-meta"><strong>Prefer currently active game bindings</strong><small>Uses Star Citizen's live actionmaps.xml over saved exports when available.</small></div><input id="live-toggle" class="ios-switch" type="checkbox" ${app.prefer_live?'checked':''} aria-label="Use active game bindings"></div>
 <div class="warning-line">Last import: <b>${esc(app.last_import||'Never')}</b> · ${app.catalog.length} total actions · ${app.defaults_count||0} game defaults<br>Custom source: ${esc(app.sync_source||'None')} ${app.active_file?'<br>Active game file: '+esc(app.active_file):''}<br>Default source: ${app.defaults_file?esc(app.defaults_file)+(app.defaults_reference_version?' (reference '+esc(app.defaults_reference_version)+')':''):'Not found — optional extracted defaultProfile.xml needed for full defaults. Ship Lights L is included as your confirmed reference.'}${app.import_error?'<br><b>'+esc(app.import_error)+'</b>':''}</div></section>
 <section class="settings-card"><div class="settings-heading">02 / CONTROL MAPPING EDITOR</div><h3>Editable iPad controls</h3><p>Select an action to follow imported keyboard overrides and local game defaults. When defaults are unavailable, missing assignments stay unassigned instead of being guessed.</p><div class="binding-guidance">${app.binding_report?.shared_action_count||0} shared game actions · ${app.binding_report?.potential_conflict_count||0} potential shortcut overlaps. An overlap is only a warning: contexts may legitimately use the same key.</div>
 <div class="search-row"><input class="input" id="filter-text" placeholder="Search controls..." value="${esc(search)}"><select id="filter-profile" class="input" style="max-width:190px"><option value="all">All profiles</option>${choices}</select><button id="add-control-btn" class="primary-btn">+ ADD</button></div><div id="binding-results"></div></section>`;
 el('get-game-defaults').onclick=async()=>{
   if(!confirm('Import your effective keyboard bindings? This downloads a pinned 4.10.2 default XML (no executable), merges your live Star Citizen customizations and auto-links verified cockpit actions. Your game files and HOTAS settings will not change.'))return;
   const btn=el('get-game-defaults'),status=el('defaults-import-status');
   btn.disabled=true;btn.textContent='IMPORTING CURRENT BINDINGS…';status.textContent='Combining verified 4.10.2 defaults with your live game overrides. No game settings are being changed.';
   try{const result=await request('/api/defaults/extract',{confirm:'EXTRACT_DEFAULTS'});
       app=await request('/api/state');renderSettings();updateRail();
       notify('Imported '+result.defaults+' default actions and your active overrides. '+result.assigned+'/'+result.controls+' cockpit controls have keyboard inputs. Baseline: '+result.reference_version);
   }catch(e){btn.disabled=false;btn.textContent='RETRY IMPORT CURRENT BINDINGS';status.textContent='Could not import defaults: '+e.message;notify(e.message,true);}
 };
 el('sync-btn').onclick=async()=>{try{const p=el('xml-path').value.trim();const res=await request('/api/import',p?{path:p}:{});notify(`Synced ${res.total} actions (${res.defaults} game defaults) from ${res.source}`);app=await request('/api/state');renderSettings();updateRail();}catch(e){notify(e.message,true);}};
 el('auto-toggle').onchange=async ev=>{try{app=await request('/api/settings',{auto_sync:ev.target.checked});notify('Automatic sync '+(app.auto_sync?'enabled':'disabled'));}catch(e){notify(e.message,true);}};
 el('live-toggle').onchange=async ev=>{try{app=await request('/api/settings',{prefer_live:ev.target.checked});renderSettings();notify('Game binding source updated');}catch(e){notify(e.message,true);}};
 el('add-control-btn').onclick=()=>addControl();
 el('filter-text').oninput=e=>{search=e.target.value;renderBindingRows();};
 el('filter-profile').onchange=e=>{profileFilter=e.target.value;renderBindingRows();};
 renderBindingRows();
}
function renderBindingRows(){const term=search.toLowerCase().trim();const rows=app.controls.filter(c=>(profileFilter==='all'||c.profile===profileFilter)&&(!term||(c.label+' '+c.id+' '+c.section+' '+c.binding).toLowerCase().includes(term)));
 el('binding-results').innerHTML=`<div class="count-caption">${rows.length} CONTROLS</div><div class="binding-list">${rows.map(c=>`<div class="binding-row"><div><div class="binding-name">${esc(c.label)}</div><div class="binding-sub">${esc(c.profile.toUpperCase())} / ${esc(c.section)} · ${esc(c.manual?'MANUAL':c.action_ref?'XML LINKED':'NOT LINKED')}${bindingPeers(c).length?' · SHARED WITH '+esc(bindingPeers(c).join(', ')):''}${bindingConflictLabels(c).length?' · POSSIBLE SHORTCUT OVERLAP: '+esc(bindingConflictLabels(c).join(', ')):''}</div></div><div style="display:flex;align-items:center;gap:10px;min-width:0"><span class="binding-key ${c.binding?'':'empty'}" title="${esc(c.binding_source||'Not mapped')}">${esc(bindingLabel(c))}</span><button data-edit="${esc(c.id)}">EDIT</button></div></div>`).join('')}</div>`;
 el('binding-results').querySelectorAll('[data-edit]').forEach(btn=>btn.onclick=()=>editControl(btn.dataset.edit));
}
async function renderUpdateSettings(){
 el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">SOFTWARE / MAINTENANCE</div><h3>Companion updates</h3><p>Installed on Serenity: <strong>v${esc(app.version||'unknown')}</strong>. Existing controls, keyboard mappings, and pairing stay in your Windows user data folder.</p>
 <div class="update-console"><div class="update-indicator"><span class="update-led"></span><div><strong id="remote-update-title">Checking for releases…</strong><small id="remote-update-info">Public update mirror: GitHub Pages / star-citizen-deck.</small></div></div><button type="button" id="update-fetch" class="primary-btn" disabled>CHECKING…</button></div>
 <div class="modal-actions"><button id="update-check" type="button" class="secondary-btn">CHECK AGAIN</button></div>
 <details class="advanced-update"><summary>Advanced: install a trusted ZIP manually</summary><p>Use this only until the release channel is published or if Serenity cannot access GitHub. Keep the ZIP compressed.</p><div class="field"><label for="update-file">UPDATE PACKAGE (.ZIP)</label><input type="file" id="update-file" class="input" accept=".zip,application/zip"></div><div class="modal-actions"><button id="one-step-update" type="button" class="primary-btn">VERIFY ZIP, INSTALL &amp; RESTART</button></div></details>
 <div id="update-info" class="warning-line">Future updates use verified packages, persistent backups, and a Python import check. Keep START_DECK.bat open.</div></section>`;
 const info=el('remote-update-info'), title=el('remote-update-title'), fetchButton=el('update-fetch');
 async function check(){
  title.textContent='Checking release channel…'; fetchButton.disabled=true; fetchButton.textContent='CHECKING…';
  try {const r=await request('/api/update/check'); title.textContent=r.available?'UPDATE AVAILABLE: v'+r.latest:r.configured?'NO NEW RELEASE':'RELEASE CHANNEL NOT LIVE';
       info.textContent=r.note;fetchButton.disabled=!r.available;fetchButton.textContent=r.available?'INSTALL v'+r.latest:'UP TO DATE / OFFLINE';}
  catch(e){title.textContent='RELEASE CHECK FAILED';info.textContent=e.message;fetchButton.textContent='UNAVAILABLE';}
 }
 el('update-check').onclick=check;
 fetchButton.onclick=async()=>{
  if(!confirm('Install the verified published update and restart the Windows companion?'))return;
  fetchButton.disabled=true;fetchButton.textContent='VERIFYING RELEASE…';
  try{const r=await request('/api/update/fetch',{});await applyAndReconnect(r.version);}
  catch(e){info.textContent=e.message;notify(e.message,true);await check();}
 };
 el('one-step-update').onclick=async()=>{
  const file=el('update-file').files[0];if(!file)return notify('Select the trusted update ZIP first.',true);
  if(file.size>4_000_000)return notify('Update ZIP is larger than 4 MB.',true);
  if(!confirm('Verify this ZIP and install it on Serenity?'))return;
  const button=el('one-step-update');button.disabled=true;button.textContent='VERIFYING & INSTALLING…';
  try {
   const response=await fetch('/api/update/upload',{method:'POST',headers:{'X-Deck-Token':token,'Content-Type':'application/zip'},body:file,cache:'no-store'});
   const result=await response.json();if(!response.ok)throw new Error(result.error||'ZIP upload failed');
   await applyAndReconnect(result.version);
  } catch(e){button.disabled=false;button.textContent='VERIFY ZIP, INSTALL & RESTART';el('update-info').textContent=e.message;notify(e.message,true);}
 };
 async function applyAndReconnect(version){
  await request('/api/update/apply',{confirm:'INSTALL'});
  el('update-info').textContent='Installing v'+version+' on Serenity. Waiting for the companion to reconnect…';
  const started=Date.now();
  while(Date.now()-started<40000){
   await new Promise(resolve=>setTimeout(resolve,1250));
   try{const response=await fetch('/api/hello',{cache:'no-store'});if(!response.ok)continue;
       const state=await response.json();if(state.version===version){window.location.reload();return;}}
   catch(_){ /* Installer momentarily stops the old server. */ }
  }
  el('update-info').textContent='The restart has not been confirmed. Check the companion window on Serenity before trying again.';
 }
 await check();
}
function renderConnectionSettings(){
 el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">01 / INPUT SAFETY</div><h3>Live keyboard output</h3><p>Every button sends one user-requested keyboard press to the foreground Star Citizen window only. The deck never reads game memory, modifies game files, or runs automatic command sequences.</p>
 <div class="toggle-row"><div class="setting-meta"><strong>Arm keyboard controls</strong><small>Resets to OFF whenever you restart the companion. Available on Windows only.</small></div><input id="arm-toggle" class="ios-switch" type="checkbox" ${app.armed?'checked':''} ${!app.can_send?'disabled':''} aria-label="Arm keyboard output"></div>
 <div class="warning-line">CURRENT INPUT METHOD: <b>${esc(app.input_mode==='scan'?'SCAN-CODE TEST':'VIRTUAL KEY')}</b>. Scan-code mode was selected automatically on the v0.2.4 upgrade, with no extra setting needed.</div>
 <div class="field"><label>GAME KEYBOARD DELIVERY</label><select id="input-mode" class="input" ${app.can_send?'':'disabled'}><option value="virtual" ${(app.input_mode||'virtual')==='virtual'?'selected':''}>Standard virtual-key (original)</option><option value="scan" ${app.input_mode==='scan'?'selected':''}>Physical scan-code (test)</option></select><p class="hint">Star Citizen may process scan codes differently from virtual-key events. Both use Windows SendInput; neither guarantees the game will accept a command. Notepad diagnostic remains unchanged.</p></div>
 <div class="warning-line">${app.can_send?'Input is supported by this Windows companion, but compatibility with the game and its anti-cheat is not guaranteed.':'This preview is running on '+esc(app.system)+'. Live key input requires running the companion on Windows.'}</div><div class="toggle-row"><div class="setting-meta"><strong>Start companion automatically when signing in to Windows</strong><small>One-time setup on Serenity. No administrator access required. The companion runs before Star Citizen opens, so you won't need the BAT file each session. You still arm controls manually.</small></div><input id="autostart-toggle" class="ios-switch" type="checkbox" ${app.start_at_login?'checked':''} ${!app.can_send?'disabled':''} aria-label="Start Windows companion when signing in"></div></section>
 <section class="settings-card"><div class="settings-heading">02 / SAFE WINDOWS DIAGNOSTIC</div><h3>Notepad keyboard test</h3><p>Open Notepad on Serenity, click into a blank document, and keep it in the foreground. This sends exactly one <b>L</b> keystroke only if Windows confirms the foreground process is Notepad. Normal ship controls remain Star Citizen-only.</p>
 <div class="modal-actions"><button id="notepad-test" type="button" class="secondary-btn" ${app.can_send?'':'disabled'}>SEND TEST L TO NOTEPAD</button></div>
 <div id="notepad-result" class="warning-line">Requires keyboard output ARMED. The diagnostic is never sent to Star Citizen.</div></section>
 <section class="settings-card"><div class="settings-heading">03 / DEVICE INFO</div><h3>Serenity companion</h3><div class="toggle-row"><div class="setting-meta"><strong>Platform</strong><small>${esc(app.system)} / Star Citizen Deck companion v${esc(app.version||"unknown")}</small></div><span class="pill">CONNECTED</span></div><div class="toggle-row"><div class="setting-meta"><strong>Game profile</strong><small>${esc(app.profile_label)}</small></div><span class="pill">LOCAL</span></div><div class="toggle-row"><div class="setting-meta"><strong>Saved configuration</strong><small>Persistent on your PC; independent from Mongrel HUD</small></div><span class="pill">LOCAL</span></div></section>`;
 el('notepad-test').onclick=async()=>{
   const target=el('notepad-result');target.textContent='Checking Notepad foreground window and sending one L...';
   try{const result=await request('/api/diagnostic/notepad',{});
     target.textContent='Windows accepted test L. Check whether lowercase l appeared in Notepad. This does not verify Star Citizen input.';
     notify('Notepad diagnostic sent — check Notepad on Serenity');
   }catch(err){target.textContent=err.message;notify(err.message,true);}
 };
 el('input-mode').onchange=async e=>{
   try{app=await request('/api/settings',{input_mode:e.target.value});renderConnectionSettings();updateRail();notify('Input mode set to '+(app.input_mode==='scan'?'physical scan-code test':'standard virtual-key'));}
   catch(err){notify(err.message,true);renderConnectionSettings();}
 };
 el('autostart-toggle').onchange=async e=>{
   try{app=await request('/api/settings',{start_at_login:e.target.checked});renderConnectionSettings();notify(app.start_at_login?'Windows sign-in startup enabled. Companion stays available for Star Citizen.':'Windows sign-in startup disabled. Launch with BAT file when needed.');}
   catch(err){notify(err.message,true);renderConnectionSettings();}
 };
 el('arm-toggle').onchange=async e=>{if(e.target.checked&&!confirm('Arm the deck to send keyboard inputs to Star Citizen when it is in the foreground?')){e.target.checked=false;return;}
 try{app=await request('/api/settings',{armed:e.target.checked});renderConnectionSettings();updateRail();notify(app.armed?'Output ARMED — use caution':'Output safely DISARMED');}catch(err){notify(err.message,true);}};
}
function renderAbout(){el('settings-body').innerHTML=`<section class="settings-card"><div class="settings-heading">CONTROL DECK / BUILD 01</div><h3>Star Citizen Deck v${esc(app.version||"unknown")}</h3><p>Independent personal touchscreen companion for Star Citizen. Built with standard Python and browser technologies, no third-party dependencies, no installation or modification of game files.</p><div class="warning-line">Ship Lights has been confirmed working in Star Citizen on Serenity using scan-code keyboard input. Other commands remain unverified and may be ignored. Use only if allowed by the game's current rules. No macros or repeated unattended automation are implemented.</div></section><section class="settings-card"><h3>Known limits</h3><p>• No official live ship-state feed. Toggles are visual estimates.<br>• Defaults use a pinned 4.10.2 LIVE reference with your active overrides.<br>• Mouse buttons 1–5 and single vertical mouse-wheel steps supported; mouse movement, analog axes, joystick output are not.<br>• Keybinding importer does not change controls inside Star Citizen.<br>• Use on trusted LAN only: HTTP connection is not encrypted.</p></section>`;}
function editControl(id){const c=app.controls.find(x=>x.id===id);if(!c)return;
 const kindOptions=['button','toggle','hold','slider'].map(k=>`<option value="${k}" ${c.kind===k?'selected':''}>${k.toUpperCase()}</option>`).join('');
  const modal=`<div class="modal-wrap"><div class="modal" role="dialog" aria-modal="true" aria-label="Edit control"><div class="eyebrow">BINDING EDITOR / ${esc(c.profile.toUpperCase())}</div><h2>${esc(c.label)}</h2><p>Choose a linked XML action for automatic updates, or enter a keyboard shortcut manually.</p><form id="edit-form"><div class="modal-grid"><div class="field"><label>DISPLAY LABEL</label><input class="input" id="edit-label" value="${esc(c.label)}" required></div><div class="field"><label>CONTROL TYPE</label><select class="input" id="edit-kind">${kindOptions}</select></div></div>
 <div class="modal-grid"><div class="field"><label>PROFILE / PAGE</label><select class="input" id="edit-profile">${app.profiles.map(p=>`<option value="${esc(p.id)}" ${p.id===c.profile?'selected':''}>${esc(p.name)}</option>`).join('')}</select></div><div class="field"><label>CONTROL GROUP / SECTION</label><input class="input" id="edit-section" value="${esc(c.section)}" required></div></div>
 <div class="field"><label>BINDING SOURCE</label><select class="input" id="edit-source"><option value="xml" ${!c.manual?'selected':''}>Imported XML action (auto sync)</option><option value="manual" ${c.manual?'selected':''}>Manual keyboard mapping</option></select></div>
 <div class="field" id="action-field"><label>STAR CITIZEN ACTION ID</label><input class="input" id="edit-action" placeholder="Use Browse Imported Actions below" value="${esc(c.action_ref||'')}" autocapitalize="off" autocomplete="off" spellcheck="false"><div class="action-picker-tools"><button id="browse-actions" type="button" class="secondary-btn">BROWSE ${app.catalog.length} AVAILABLE ACTIONS</button><span class="hint" id="selected-action-status"></span></div><div id="action-picker" class="action-picker" hidden><label for="action-search">SEARCH GAME KEYBINDINGS</label><input class="input" id="action-search" type="search" placeholder="Search name, group or keyboard shortcut" autocomplete="off" autocapitalize="off" spellcheck="false"><div id="action-search-results" class="action-search-results"></div></div><div class="field"><label for="edit-share-action">USE THE SAME GAME ACTION AS ANOTHER CONTROL</label><select class="input" id="edit-share-action"><option value="">Choose a linked control...</option>${app.controls.filter(other=>other.id!==c.id&&!other.manual&&other.action_ref).map(other=>`<option value="${esc(other.id)}">${esc(other.label)} (${esc(other.profile.toUpperCase())})</option>`).join('')}</select></div><p class="hint">Linked controls inherit the same game action and binding. Choosing a manual shortcut affects only this control. Unknown game actions remain unassigned.</p></div>
 <div class="field" id="manual-field"><label>KEY OR MOUSE COMBINATION</label><input class="input" id="edit-manual" placeholder="e.g. LALT+R or F6" value="${esc(c.manual?c.binding:'')}"><p class="hint">Supports keyboard chords, MOUSE1–MOUSE5, MWHEEL_UP/MWHEEL_DOWN and modifier + mouse/wheel. No mouse movement, axes or macros.</p></div>
 <div class="field"><label>TAP DURATION (40–3000 MS) · HOLD CONTROLS RELEASE ON TOUCH-UP</label><input type="number" min="40" max="3000" class="input" id="edit-hold" value="${Number(c.hold_ms)||100}"></div>
 <div id="step-settings" class="modal-grid"><div class="field"><label>SLIDER STEP UP</label><input class="input" id="edit-up" placeholder="e.g. LALT+UP" value="${esc(c.binding_up||'')}"></div><div class="field"><label>SLIDER STEP DOWN</label><input class="input" id="edit-down" placeholder="e.g. LALT+DOWN" value="${esc(c.binding_down||'')}"></div></div>
 <div class="modal-actions">${c.id.startsWith("custom_")?'<button id="edit-delete" type="button" class="danger-btn">DELETE</button>':''}<button id="edit-cancel" type="button" class="secondary-btn">CANCEL</button><button type="submit" class="primary-btn">SAVE CONTROL</button></div></form></div></div>`;
 el('modal-root').innerHTML=modal;
 const updateVisible=()=>{
   const xml=el('edit-source').value==='xml';el('action-field').style.display=xml?'block':'none';el('manual-field').style.display=xml?'none':'block';el('step-settings').style.display=el('edit-kind').value==='slider'?'grid':'none';
 };
 el('edit-source').onchange=updateVisible;el('edit-kind').onchange=updateVisible;updateVisible();
 // iPad Safari does not reliably show HTML datalist suggestions. Use a real, filtered list.
 const picker=el('action-picker');
 const selectedStatus=el('selected-action-status');
 const describeSelected=()=>{
   const ref=el('edit-action').value.trim();
   const found=app.catalog.find(a=>a.ref===ref);
   const others=app.controls.filter(other=>other.id!==c.id&&!other.manual&&other.action_ref===ref).map(other=>other.label);
   const state=!ref?'No action chosen':found?(found.keyboard?'INPUT: '+found.keyboard.replace(/^(kb1_|mo1_)/i,'').toUpperCase()+' ('+(found.origin||'imported')+')':'No supported keyboard/mouse binding'):'Not in the imported game profile';
   selectedStatus.textContent=state+(others.length?' · Linked with '+others.join(', '):'');
 };
 const showImported=()=>{
   const q=el('action-search').value.trim().toLowerCase();
   const matching=app.catalog.map((a,i)=>({...a,idx:i})).filter(a=>(a.ref+' '+a.map+' '+a.name+' '+a.keyboard+' '+(a.raw||[]).join(' ')).toLowerCase().includes(q));
   const html=matching.map(a=>`<button type="button" class="action-option" data-action-index="${a.idx}"><span class="action-title">${esc(a.name.replace(/_/g,' '))}</span><span class="action-ref">${esc(a.ref)}</span><span class="action-binding ${a.keyboard?'':'action-unavailable'}">${esc(a.keyboard?a.keyboard.replace(/^(kb1_|mo1_)/i,'').toUpperCase():'NO SUPPORTED INPUT')} · ${esc(a.origin||'custom')}</span></button>`).join('');
   el('action-search-results').innerHTML=matching.length?html:`<div class="action-empty">No matching actions in your imported 4.10.2 game profile. Assign a game binding and sync, or enter a manual shortcut.</div>`;
   el('action-search-results').querySelectorAll('[data-action-index]').forEach(btn=>btn.onclick=()=>{
     const a=app.catalog[Number(btn.dataset.actionIndex)];
     if(!a)return;
     el('edit-action').value=a.ref;
     picker.hidden=true;
     el('browse-actions').textContent=`BROWSE ${app.catalog.length} AVAILABLE ACTIONS`;
     describeSelected();
   });
 };
 el('browse-actions').onclick=()=>{
   picker.hidden=!picker.hidden;
   el('browse-actions').textContent=picker.hidden?`BROWSE ${app.catalog.length} AVAILABLE ACTIONS`:'CLOSE ACTION LIST';
   if(!picker.hidden){showImported();el('action-search').focus();}
 };
 el('action-search').oninput=showImported;
 el('edit-action').oninput=describeSelected;
 el('edit-share-action').onchange=ev=>{
   const other=app.controls.find(x=>x.id===ev.target.value);
   if(other && !other.manual && other.action_ref){el('edit-action').value=other.action_ref;describeSelected();}
 };
 describeSelected();
 el('edit-cancel').onclick=()=>el('modal-root').innerHTML='';
 if(c.id.startsWith('custom_'))el('edit-delete').onclick=async()=>{if(confirm('Delete this custom control?')){try{await request('/api/control/delete',{id:c.id});app=await request('/api/state');el('modal-root').innerHTML='';render();}catch(e){notify(e.message,true);}}};
 el('edit-form').onsubmit=async e=>{e.preventDefault();const patch={id,label:el('edit-label').value,profile:el('edit-profile').value,section:el('edit-section').value,kind:el('edit-kind').value,hold_ms:Number(el('edit-hold').value)};
 if(el('edit-source').value==='xml')patch.action_ref=el('edit-action').value.trim();else patch.manual_binding=el('edit-manual').value.trim();
 if(patch.kind==='slider'){patch.binding_up=el('edit-up').value.trim();patch.binding_down=el('edit-down').value.trim();}
 try{await request('/api/control',patch);app=await request('/api/state');el('modal-root').innerHTML='';render();notify('Saved '+patch.label);}catch(err){notify(err.message,true);}};
}
window.addEventListener('DOMContentLoaded',startup);

async function addControl(){
 const label=prompt('Name your new control:');if(!label)return;
 const profile=profileFilter==='all'?'home':profileFilter;
 try{const c=await request('/api/control/create',{label,profile});app=await request('/api/state');render();editControl(c.id);}catch(e){notify(e.message,true);}
}


/* Cockpit Concept 02 — integrated with the existing controller's validated actions.
   No synthetic ship telemetry. No change to Windows keyboard injection. */
const cockpitLayouts = {home:'Overview',nav:'Navigation',scm:'Combat',scan:'Scanning',mfd:'MFD Control',systems:'Ship systems',mining:'Mining',foot:'On foot',utility:'Utilities'};
const cockpitOrderKey='scdeck-cockpit-order-v1';
let cockpitArrange=false, cockpitSelected=null;
let cockpitOrder={};
try {
  const saved=JSON.parse(localStorage.getItem(cockpitOrderKey)||'{}');
  if(saved && typeof saved==='object' && !Array.isArray(saved))cockpitOrder=saved;
} catch(_){ cockpitOrder={}; }
function cockpitLookup(id){return app?.controls.find(c=>c.id===id&&c.profile===active);}
function cockpitMeta(c){
  if(!c)return '';
  const assign=c.kind==='slider' ? (c.binding_up||c.binding_down?'STEP MAPPED':'STEP UNMAPPED') : (c.binding?bindingLabel(c):'UNMAPPED');
  return esc(assign);
}
function cockpitPanel(title,num,tag,body,extra=''){
  return `<section class="module ${extra}"><i class="screw"></i><i class="screw right"></i><div class="module-head"><h2>${esc(title)}</h2><small>${esc(num)} &nbsp; / &nbsp; ${esc(tag)}</small></div><div class="module-body">${body}</div></section>`;
}
function cockpitControl(id,kind='pad',sym='✧',style=''){
  const c=cockpitLookup(id);if(!c)return '';
  const name=esc(c.label);const binding=cockpitMeta(c);
  const safety=c.confirm||style==='amber';
  const accessible=`data-control="${esc(c.id)}" title="${name} / ${binding} / ${esc(c.description||'')}" aria-label="${name}: ${binding}"`;
  const mapped=Boolean(c.binding)||Boolean(c.binding_up||c.binding_down);
  const unmap=mapped?'':' unmapped';
  if(c.kind==='slider')return `<div class="slider-control cockpit-slider" data-slider-control="${esc(c.id)}"><div class="slider-title">${name}</div><div class="ctl-mini">STEP COMMANDS ONLY / NO ANALOG AXIS</div><div class="range-steps"><button type="button" data-slider-step="-1" data-step-id="${esc(c.id)}">− STEP</button><button type="button" data-slider-step="1" data-step-id="${esc(c.id)}">+ STEP</button></div><small>${binding}</small></div>`;
  if(kind==='switch')return `<button type="button" class="switch-row ${safety?'amber':''}${unmap}" ${accessible}><span class="switch-label"><b>${name}</b><small>${safety?'CONFIRM · ':''}${binding}</small></span><span class="mechanism"><span class="lever"></span><i class="lamp"></i></span></button>`;
  if(kind==='choice')return `<button type="button" class="power-choice${unmap}" ${accessible}><span><b>${name}</b><small>${binding}</small></span><span class="chev">›</span></button>`;
  const decor=safety?'amber':style;
  return `<button type="button" class="pad ${decor}${unmap}" ${accessible}><i class="pad-led"></i><span class="pad-icon">${safety?'⛨':sym}</span><b>${name}</b><small>${safety?'CONFIRM · ':''}${c.kind==='hold'?(mapped?'TOUCH + HOLD':'UNMAPPED'):binding}</small></button>`;
}
function cockpitBig(id,caption,secondary=false){
  const c=cockpitLookup(id);if(!c)return '';
  return `<button type="button" class="big-button ${secondary?'secondary':''} ${c.binding?'':'unmapped'}" data-control="${esc(id)}" title="${esc(c.description||c.label)}"><b>${esc(c.label)}</b><span>${esc(c.binding?caption:'UNMAPPED / CONFIGURE IN SETTINGS')}</span></button>`;
}
function cockpitPair(ids,signs=[],style=''){return `<div class="control-grid">${ids.map((id,i)=>cockpitControl(id,'pad',signs[i]||'✧',style)).join('')}</div>`;}
function cockpitDisplay(kind='quantum'){
  const combat=kind==='target';
  return `<div class="display ${combat?'target':''}" aria-label="Schematic only; no live telemetry"><div class="readout-top"><span>${combat?'SENSORS / STANDBY':'NAV COMP / STANDBY'}</span><span>${combat?'NO LOCK DATA':'QUANTUM / UNKNOWN'}</span></div><div class="orbital"><i class="circle"></i><i class="circle two"></i><i class="circle three"></i><i class="sweep"></i><span class="symbol">${combat?'⊕':'⌾'}</span></div><div class="readout-label">${combat?'NO TARGET DATA':'NO ROUTE DATA'}</div><div class="readout-caption">${combat?'TARGET TELEMETRY NOT LINKED':'SHIP TELEMETRY NOT LINKED'}</div><div class="readout-bottom">SCHEMATIC DISPLAY ONLY &nbsp; / &nbsp; SCD-02</div></div>`;
}
function cockpitFooter(){return `<div class="bottom-strip"><div class="mini-module"><span class="mark">✦</span><div><b>INPUT PATH · WINDOWS SCAN-CODE</b><small>Game commands require a mapped control, armed output and Star Citizen in foreground.</small></div><span class="index">AUX 01</span></div><div class="mini-module"><span class="mark">⌁</span><div><b>ACTUAL SHIP STATE · UNKNOWN</b><small>Sending a command does not confirm a toggle, power level or system state.</small></div><span class="index">AUX 02</span></div></div>`;}
const panel=cockpitPanel,ctl=cockpitControl,pair=cockpitPair,display=cockpitDisplay,landingFooter=cockpitFooter;

function navScreen(){return `<div class="dashboard">
 ${panel('Flight control','01','MOBILITY',`<div class="microhead"><span>FLIGHT CONTROL MATRIX</span><span>SCM / NAV</span></div><div class="control-block">${['nav_cruise','nav_decouple','nav_vtol','nav_gear'].map(id=>ctl(id,'switch')).join('')}</div><div class="module-bottom">${pair(['nav_mode','nav_speed_reset'],['↔','↺'])}</div>`)}
 ${panel('Quantum operations','02','TRANSIT',`${display()}<div class="two-action">${cockpitBig('nav_spool','PREPARE QUANTUM',true)}${cockpitBig('nav_quantum','TOUCH + HOLD',false)}</div><div class="two-action">${cockpitBig('nav_cancel','SINGLE INPUT',true)}${cockpitBig('nav_request','LANDING SERVICES',true)}</div>`)}
 ${panel('Power distribution','03','ENERGY',`<div class="statlines"><div class="statline"><b>THRUSTER DISTRIBUTION</b><span>UNKNOWN</span></div><div class="statline"><b>SHIELD DISTRIBUTION</b><span>UNKNOWN</span></div><div class="statline"><b>WEAPON DISTRIBUTION</b><span>UNKNOWN</span></div></div><div class="microhead"><span>FOCUS COMMANDS</span><span>MANUAL</span></div><div class="control-block">${['nav_power_thrusters','nav_power_shields','nav_power_weapons','nav_power_reset'].map(id=>ctl(id,'choice')).join('')}</div><p class="subtle-note">Distribution percentages deliberately hidden: no live data source is connected.</p>`)}
 </div>${landingFooter()}`;}
function scmScreen(){return `<div class="dashboard">
 ${panel('Target acquisition','01','SENSORS',`<div class="microhead"><span>CONTACT / SELECTION</span><span>MANUAL</span></div>${pair(['scm_hostiles','scm_nearest'],['◎','◉'])}${pair(['scm_lock1','scm_lock2'],['①','②'])}<div class="module-bottom"><p class="subtle-note">The targeting reticle is a visual instrument. Target selections cannot be confirmed without game telemetry.</p></div>`)}
 ${panel('Combat operations','02','WEAPONS',`${display('target')}<div class="two-action">${cockpitBig('scm_aimmode','CYCLE',true)}${cockpitBig('scm_missiles','SINGLE INPUT',false)}</div>`)}
 ${panel('Defense matrix','03','PROTECTION',`<div class="microhead"><span>COUNTERMEASURES</span><span>CMD</span></div>${pair(['scm_decoy_less','scm_decoy','scm_decoy_more'],['−','✹','+'])}${pair(['scm_noise'],['◈'])}<div class="microhead"><span>POWER / DEFENSE</span><span>FOCUS</span></div>${['scm_shields','scm_weapons','scm_reset','scm_shield_reset'].map(id=>ctl(id,'choice')).join('')}<p class="subtle-note">These are command senders, not shield or weapon-state indicators.</p>`)}
 </div>${landingFooter()}`;}

function scanScreen(){return `<div class="dashboard scan-suite">
 ${panel('Scan operations','01','ACTIVE SCANNING',`<div class="microhead"><span>MODE / SCAN / PING</span><span>DIRECT INPUT</span></div>${pair(['scan_mode','scan_trigger','scan_ping'],['◈','◎','⌁'])}<p class="subtle-note">SCAN TARGET and RADAR PING use touch-and-hold. Ship telemetry and scan results are not available to this controller.</p>`)}
 ${panel('Scanning angle','02','ADJUST',`<div class="microhead"><span>SCAN CONE ANGLE</span><span>ONE STEP PER TAP</span></div>${pair(['scan_focus_less','scan_focus_more'],['−','+'])}<p class="subtle-note">Uses your current binding. Star Citizen defaults these actions to mouse wheel down/up; each tap sends one step.</p>`)}
 ${panel('Scan display navigation','03','CONTACT DATA',`<div class="microhead"><span>SCAN TABS</span><span>PREV / NEXT</span></div>${pair(['scan_tab_prev','scan_tab_next'],['◂','▸'])}<div class="microhead"><span>SCAN PAGES</span><span>PREV / NEXT</span></div>${pair(['scan_page_prev','scan_page_next'],['◂','▸'])}<div class="microhead"><span>CONTACTS</span><span>PREV / NEXT</span></div>${pair(['scan_contact_prev','scan_contact_next'],['◂','▸'])}<div class="microhead"><span>CONTACT PAGES</span><span>PREV / NEXT</span></div>${pair(['scan_contact_page_prev','scan_contact_page_next'],['◂','▸'])}`)}
 </div>${landingFooter()}`;}
function mfdScreen(){return `<div class="dashboard mfd-suite">
 ${panel('Select a cockpit display','01','FOCUS',`<div class="microhead"><span>FIRST SELECT AN MFD</span><span>STEP 1</span></div>${pair(['mfd_primary','mfd_cast_left','mfd_cast_right'],['▣','◂','▸'])}<div class="microhead"><span>NUMBERED SLOTS</span><span>1–10</span></div><div class="control-grid mfd-slots">${Array.from({length:10},(_,i)=>ctl('mfd_'+(i+1),'pad',String(i+1))).join('')}</div><p class="subtle-note">MFD focus shortcuts are unassigned in the 4.10.2 defaults. Configure only the displays you use, in the game keybindings.</p>`)}
 ${panel('Choose a screen','02','PAGE',`<div class="microhead"><span>THEN CHOOSE A VIEW</span><span>STEP 2</span></div><div class="control-grid mfd-pages">${['mfd_self','mfd_target','mfd_scanning','mfd_config','mfd_comms','mfd_ifcs','mfd_diagnostics','mfd_resources'].map(id=>ctl(id,'pad','▤')).join('')}</div><p class="subtle-note">Screen shortcuts are also unbound by default. Selecting a page sends one game action to the focused MFD; it does not detect or remember the ship's display state.</p>`)}
 ${panel('Cycle the focused display','03','ALTERNATIVE',`<div class="microhead"><span>PREVIOUS / NEXT PAGE</span><span>DEFAULT BINDINGS</span></div>${pair(['mfd_page_prev','mfd_page_next'],['◂','▸'])}<p class="subtle-note">LALT+Q / LALT+E are the 4.10.2 default cycle shortcuts. Your live game overrides still take precedence.</p>`)}
 </div>${landingFooter()}`;}
function sysScreen(){return `<div class="dashboard systems">
 ${panel('Electrical bus','01','CORE',`<div class="microhead"><span>HARDWARE COMMANDS</span><span>MANUAL</span></div><div class="control-block">${['ship_power','engine_power','sys_shields','sys_weapons','sys_lights'].map(id=>ctl(id,'switch')).join('')}</div><div class="module-bottom">${pair(['sys_flight_ready'],['ϟ'])}</div>`)}
 ${panel('Access & hatches','02','GUARDED',`<div class="guard-hardware"><div class="guard-symbol">⌑</div><div class="guard-desc">SAFETY COVER / CONFIRM BEFORE ACTION</div>${pair(['open_all_doors','close_all_doors'],['↟','↡'],'amber')}</div><div class="control-block">${['sys_lock','sys_ramp'].map(id=>ctl(id,'switch')).join('')}</div><p class="subtle-note">Guard confirmation will be required when the real controller is armed.</p>`)}
 ${panel('Landing config','03','GROUND',`<div class="microhead"><span>LANDING SUPPORT</span><span>CMD</span></div><div class="control-block">${['sys_gear','sys_vtol'].map(id=>ctl(id,'switch')).join('')}</div><div class="module-bottom">${pair(['sys_atc'],['⌂'],'accent')}</div><div class="statlines"><div class="statline"><b>LANDING GEAR</b><span>UNKNOWN</span></div><div class="statline"><b>VTOL STATE</b><span>UNKNOWN</span></div></div>`)}
 </div>${landingFooter()}`;}
function miningScreen(){return `<div class="dashboard mining">
 ${panel('Laser operations','01','EXTRACTION',`<div class="microhead"><span>INDUSTRIAL INPUT</span><span>CMD</span></div>${pair(['mine_mode','mine_laser'],['◆','⇧'])}${pair(['mine_switch','mine_ping'],['↻','⌁'])}${pair(['mine_gimbal'],['⊕'])}<p class="subtle-note">Controls send your assigned keyboard or mouse inputs only while armed.</p>`)}
 ${panel('Laser output','02','REFERENCE',`<div class="range-display"><span class="range-label">LOCAL VISUAL REFERENCE</span><span class="range-value" id="range-value">${localSliders['mining_power']??37}<span style="font-size:28px">%</span></span><span class="subtle-note">NOT A LIVE LASER POWER READING</span></div><input class="range-slider" type="range" min="0" max="100" value="${localSliders['mining_power']??37}" id="power-slider" data-source-control="mining_power" aria-label="Local example slider"><div class="range-steps"><button data-slider-step="-1">− STEP</button><button data-slider-step="1">+ STEP</button></div><p class="subtle-note">Dragging is preview-only. The real deck's ± step keys send a single mapped keystroke, if configured.</p>`)}
 ${panel('Consumables','03','UTILITY',`<div class="microhead"><span>ASSIGNABLE SLOTS</span><span>3 BANKS</span></div>${pair(['mine_slot1','mine_slot2'],['Ⅰ','Ⅱ'])}${pair(['mine_slot3'],['Ⅲ'])}<div class="module-bottom"><div class="statline"><b>LASER HEAT</b><span>UNKNOWN</span></div><div class="statline"><b>ROCK STABILITY</b><span>UNKNOWN</span></div><div class="statline"><b>RESOURCES</b><span>UNKNOWN</span></div></div>`)}
 </div>${landingFooter()}`;}
function genericScreen(){
 let mine=app.controls.filter(c=>c.profile===active),groups=[...new Set(mine.map(c=>c.section))];
 return `<div class="dashboard generic">${groups.map((g,i)=>panel(g,String(i+1).padStart(2,'0'),'CONTROL BANK',`<div class="control-grid">${mine.filter(c=>c.section===g).map(c=>c.kind==='toggle'?ctl(c.id,'switch'):ctl(c.id)).join('')}</div>`)).join('')}${panel('Command guidance','03','STATUS',`${display('quantum')}<p class="subtle-note">Each control uses the existing game binding. Actual ship-state telemetry is unavailable.</p>`)}</div>${landingFooter()}`;
}

function renderCockpitContent(){
  const main=el('main-area');
  const selected=app.profiles.find(p=>p.id===active); if(!selected)return;
  const title=cockpitLayouts[active]||selected.name;
  cockpitSelected=null;
  const layout=(active==='nav'?navScreen():active==='scm'?scmScreen():active==='systems'?sysScreen():active==='mining'?miningScreen():active==='scan'?scanScreen():active==='mfd'?mfdScreen():genericScreen());
  main.innerHTML=`<section class="cockpit2">
    <div class="cockpit2-heading"><div><div class="eyebrow">SERENITY / ${esc(selected.short||active.toUpperCase())} / LIVE COMMAND DECK</div><div class="title-row"><h1>${esc(title)}</h1><span>FLIGHT STATION · ${esc(app.version||'')}</span></div></div><button type="button" id="cockpit-arrange" class="secondary-btn" aria-pressed="${cockpitArrange}">${cockpitArrange?'✓ FINISH ARRANGING':'◈ ARRANGE CONTROLS'}</button></div>
    <div class="cockpit-note" role="note"><span class="pilot-dot"></span><b>COMMAND CONSOLE</b><span>Buttons send configured inputs only when armed. Instrument graphics are schematics, not live ship-state readings.</span></div>
    <div id="cockpit-arrange-tools" class="arrange-toolbar ${cockpitArrange?'open':''}"><strong>ARRANGE MODE / THIS iPAD ONLY</strong><span class="hint" id="cockpit-selection">Select a control to move within its bank.</span><button type="button" data-shift="back">◀ MOVE</button><button type="button" data-shift="forward">MOVE ▶</button></div>
    <div id="cockpit-layout" class="cockpit-layout">${layout}</div><div class="cockpit-action-line" id="cockpit-action-line" aria-live="polite">${app.armed?'KEYBOARD OUTPUT ARMED':'OUTPUT DISARMED'} / SHIP STATE NOT VERIFIED</div>
   </section>`;
  const visible=new Set([...main.querySelectorAll('[data-control]')].map(b=>b.dataset.control));
  main.querySelectorAll('[data-source-control],[data-slider-control]').forEach(e=>visible.add(e.dataset.sourceControl||e.dataset.sliderControl));
  const extra=app.controls.filter(c=>c.profile===active && !visible.has(c.id));
  if(extra.length){
    const bank=document.createElement('section');bank.className='module cockpit-extra';
    bank.innerHTML=`<div class="module-head"><h2>Additional controls</h2><small>USER CONFIGURED / ${extra.length}</small></div><div class="module-body"><div class="control-grid">${extra.map(c=>cockpitControl(c.id,c.kind==='toggle'?'switch':'pad')).join('')}</div></div>`;
    main.querySelector('.dashboard').appendChild(bank);
  }
  applyCockpitOrder();
  main.querySelectorAll('[data-control]').forEach(btn=>{
    const id=btn.dataset.control;
    const model=app.controls.find(c=>c.id===id);
    if(model?.kind==='hold'){
      btn.style.touchAction='none';
      btn.onpointerdown=e=>{if(!cockpitArrange)beginTouchHold(id,btn,e);};
      btn.onpointerup=()=>stopTouchHold(id);
      btn.onpointercancel=()=>stopTouchHold(id);
      btn.onlostpointercapture=()=>stopTouchHold(id);
    }
    btn.onclick=()=>{
      if(cockpitArrange){cockpitSelected=id;
        main.querySelectorAll('.edit-selected').forEach(e=>e.classList.remove('edit-selected'));
        btn.classList.add('edit-selected');
        el('cockpit-selection').textContent=(cockpitLookup(cockpitSelected)?.label||'Control')+' selected';
        return;}
      if(model?.kind==='hold')return;
      activate(id);
    };
  });
  main.querySelectorAll('[data-slider-step]').forEach(b=>b.onclick=()=>{
    if(cockpitArrange)return;
    activate(b.dataset.stepId||'mining_power',Number(b.dataset.sliderStep)>0?'up':'down');
  });
  const slider=main.querySelector('#power-slider');
  if(slider){slider.oninput=()=>{
    localSliders['mining_power']=Number(slider.value);
    const label=el('range-value');if(label)label.innerHTML=esc(slider.value)+'<span style="font-size:28px">%</span>';
    el('cockpit-action-line').textContent='LOCAL VISUAL REFERENCE ONLY / DRAGGING DOES NOT SEND KEYS';
  };}
  main.querySelectorAll('[data-shift]').forEach(b=>b.onclick=()=>shiftCockpitControl(b.dataset.shift));
  el('cockpit-arrange').onclick=()=>{cockpitArrange=!cockpitArrange;renderCockpitContent();};
}
function applyCockpitOrder(){
 const layout=el('cockpit-layout');if(!layout)return;
 const groups=cockpitOrder[active]||{};
 layout.querySelectorAll('.control-grid,.control-block').forEach((parent,index)=>{
  const saved=Array.isArray(groups[index])?groups[index]:[];
  for(const id of saved){const node=[...parent.children].find(child=>child.dataset.control===id);if(node)parent.appendChild(node);}
 });
}
function shiftCockpitControl(direction){
 if(!cockpitSelected)return;
 const layout=el('cockpit-layout');
 const node=[...layout.querySelectorAll('[data-control]')].find(e=>e.dataset.control===cockpitSelected);
 if(!node)return;
 const group=node.parentElement;
 const items=[...group.children].filter(e=>e.dataset.control);
 const index=items.indexOf(node);
 const target=direction==='back'?items[index-1]:items[index+1];
 if(!target)return;
 if(direction==='back')group.insertBefore(node,target);else group.insertBefore(target,node);
 const bank=[...layout.querySelectorAll('.control-grid,.control-block')].indexOf(group);
 if(bank>=0){cockpitOrder[active]??={};cockpitOrder[active][bank]=[...group.children].filter(e=>e.dataset.control).map(e=>e.dataset.control);
  try{localStorage.setItem(cockpitOrderKey,JSON.stringify(cockpitOrder));}catch(_){}
 }
 el('cockpit-selection').textContent='Saved on this iPad only. Game mappings unchanged.';
}
