"""Curated controls. Action references are examples verified against CIG's exported XML.
Unverified controls deliberately have no automatic action reference or key assigned.
"""

PROFILES = [
    {"id":"home","name":"Overview","short":"HOME","subtitle":"Command center","icon":"grid"},
    {"id":"nav","name":"Navigation","short":"NAV","subtitle":"Transit & maneuvering","icon":"compass"},
    {"id":"scm","name":"Combat","short":"SCM","subtitle":"Weapons & defense","icon":"target"},
    {"id":"scan","name":"Scanning","short":"SCAN","subtitle":"Scanning and contact management","icon":"target"},
    {"id":"mfd","name":"MFD Control","short":"MFD","subtitle":"Display selection and MFD pages","icon":"grid"},
    {"id":"systems","name":"Ship Systems","short":"SYS","subtitle":"Power & access","icon":"cpu"},
    {"id":"mining","name":"Mining","short":"MINE","subtitle":"Extraction operations","icon":"pickaxe"},
    {"id":"foot","name":"On Foot","short":"FPS","subtitle":"Personal equipment","icon":"person"},
    {"id":"utility","name":"Utilities","short":"UTIL","subtitle":"Cargo, EVA & camera","icon":"sliders"},
]

CONTROLS = []

def add(profile, section, items):
    for name, label, kind, action, detail in items:
        CONTROLS.append({"id":name,"profile":profile,"section":section,"label":label,"kind":kind,
                         "action_ref":action,"binding":"","hold_ms":100,"description":detail,
                         "confirm":name in {"ship_power","open_all_doors","close_all_doors","engine_power"}})

add("home","Flight essentials",[
    ("home_master","Master Modes","button",None,"Switch NAV / SCM; link your assigned shortcut"),
    ("home_landing","Landing Gear","toggle",None,"Local indication only; not aircraft telemetry"),
    ("home_lights","Exterior Lights","toggle",None,"Local indication only"),
    ("home_hail","Takeoff / Landing Request","button",None,"Request departure or arrival clearance"),
])
add("home","Quick actions",[
    ("home_flight_ready","Flight Ready","button",None,"Ship startup action"),
    ("home_ping","Sensor Ping","button",None,"Use your current ping mapping"),
    ("home_cruise","Cruise Control","toggle","spaceship_movement/v_ifcs_toggle_cruise_control","Toggle cruise control"),
    ("home_decouple","Decoupled","toggle","spaceship_movement/v_ifcs_toggle_vector_decoupling","Toggle coupled flight"),
])
add("nav","Quantum & transit",[
    ("nav_mode","NAV / SCM","hold",None,"Master mode switch; configure a hold if required"),
    ("nav_quantum","Quantum Engage","hold",None,"Touch and hold to engage a calibrated quantum jump; release to stop the input"),
    ("nav_spool","Quantum Spool","button",None,"Only if separately bound in current version"),
    ("nav_cancel","Cancel Quantum","button",None,"Only if supported by game mapping"),
])
add("nav","Flight management",[
    ("nav_cruise","Cruise Control","toggle","spaceship_movement/v_ifcs_toggle_cruise_control","Local state estimate"),
    ("nav_decouple","Decoupled","toggle","spaceship_movement/v_ifcs_toggle_vector_decoupling","Local state estimate"),
    ("nav_speed_reset","Speed Limiter Reset","button","spaceship_movement/v_ifcs_speed_limiter_reset_scm","Reset to SCM speed"),
    ("nav_vtol","VTOL","toggle",None,"Toggle VTOL"),
    ("nav_gear","Landing Gear","toggle",None,"Toggle landing gear"),
    ("nav_request","Takeoff / Landing Request","button",None,"ATC departure or arrival request"),
])
add("nav","Power distribution",[
    ("nav_power_thrusters","Focus Thrusters","button","spaceship_power/v_power_focus_thrusters","Power focus"),
    ("nav_power_shields","Focus Shields","button","spaceship_power/v_power_focus_shields","Power focus"),
    ("nav_power_weapons","Focus Weapons","button","spaceship_power/v_power_focus_weapons","Power focus"),
    ("nav_power_reset","Reset Distribution","button","spaceship_power/v_power_reset_focus","Return power focus"),
])
add("scm","Targeting",[
    ("scm_hostiles","Cycle Hostiles","button","spaceship_targeting_advanced/v_target_cycle_hostile_fwd","Next hostile"),
    ("scm_nearest","Nearest Hostile","button",None,"Find a hostile target"),
    ("scm_lock1","Target Pin 1","button","spaceship_targeting/v_target_toggle_lock_index_1","Lock pinned target 1"),
    ("scm_lock2","Target Pin 2","button","spaceship_targeting/v_target_toggle_lock_index_2","Lock pinned target 2"),
])
add("scm","Weapons & defensive",[
    ("scm_aimmode","Aim Mode","button","spaceship_weapons/v_weapon_cycle_aimmode","Cycle aim settings"),
    ("scm_missiles","Missile Launch","button","spaceship_missiles/v_weapon_launch_missile","Send one launch input"),
    ("scm_decoy","Deploy Decoy","button","spaceship_defensive/v_weapon_countermeasure_decoy_launch","Launch selected decoy burst"),
    ("scm_decoy_less","Decoy −","button","spaceship_defensive/v_weapon_countermeasure_decoy_burst_decrease","Reduce decoys per burst"),
    ("scm_decoy_more","Decoy +","button","spaceship_defensive/v_weapon_countermeasure_decoy_burst_increase","Increase decoys per burst"),
    ("scm_noise","Deploy Noise","button","spaceship_defensive/v_weapon_countermeasure_noise_launch","Countermeasures"),
])
add("scm","Combat power",[
    ("scm_shields","Focus Shields","button","spaceship_power/v_power_focus_shields","Power focus"),
    ("scm_weapons","Focus Weapons","button","spaceship_power/v_power_focus_weapons","Power focus"),
    ("scm_reset","Reset Power","button","spaceship_power/v_power_reset_focus","Reset focus"),
    ("scm_shield_reset","Reset Shield Faces","button","spaceship_defensive/v_shield_reset_level","Shield equalization"),
])
add("scan","Scan operations",[
    ("scan_mode","Scanning Mode","button","seat_general/v_toggle_scan_mode","Toggle ship scanning mode"),
    ("scan_trigger","Scan Target","hold","spaceship_scanning/v_scanning_trigger_scan","Hold to scan target; no default keyboard shortcut"),
    ("scan_ping","Radar Ping","hold","spaceship_radar/v_invoke_ping","Hold and release to transmit a radar ping"),
])
add("scan","Focus adjustment",[
    ("scan_focus_less","Focus −","button","spaceship_scanning/v_dec_scan_focus_level","Decrease scan focus; bind in game"),
    ("scan_focus_more","Focus +","button","spaceship_scanning/v_inc_scan_focus_level","Increase scan focus; bind in game"),
])
add("scan","Scan display navigation",[
    ("scan_tab_prev","Previous Tab","button","spaceship_scanning/v_ui_prev_scan_tab","Previous scan tab"),
    ("scan_tab_next","Next Tab","button","spaceship_scanning/v_ui_next_scan_tab","Next scan tab"),
    ("scan_page_prev","Previous Page","button","spaceship_scanning/v_ui_prev_scan_page","Previous scan page"),
    ("scan_page_next","Next Page","button","spaceship_scanning/v_ui_next_scan_page","Next scan page"),
    ("scan_contact_prev","Previous Contact","button","spaceship_scanning/v_ui_prev_contact","Previous scanned contact"),
    ("scan_contact_next","Next Contact","button","spaceship_scanning/v_ui_next_contact","Next scanned contact"),
    ("scan_contact_page_prev","Contact Page −","button","spaceship_scanning/v_ui_prev_contact_page","Previous scanned contact page"),
    ("scan_contact_page_next","Contact Page +","button","spaceship_scanning/v_ui_next_contact_page","Next scanned contact page"),
])
add("mfd","Select display",[
    ("mfd_primary","Primary MFD","button","vehicle_mfd/v_mfd_soft_select_mfd_primary_short","Focus primary MFD before choosing a page"),
    ("mfd_cast_left","Left Cast","button","vehicle_mfd/v_mfd_soft_select_cast_left_short","Select left MFD cast"),
    ("mfd_cast_right","Right Cast","button","vehicle_mfd/v_mfd_soft_select_cast_right_short","Select right MFD cast"),
])
add("mfd","Select MFD slot",[
    ("mfd_1","MFD 1","button","vehicle_mfd/v_mfd_soft_select_mfd_1_short","Focus numbered MFD 1 before changing view"),
    ("mfd_2","MFD 2","button","vehicle_mfd/v_mfd_soft_select_mfd_2_short","Focus numbered MFD 2 before changing view"),
    ("mfd_3","MFD 3","button","vehicle_mfd/v_mfd_soft_select_mfd_3_short","Focus numbered MFD 3 before changing view"),
    ("mfd_4","MFD 4","button","vehicle_mfd/v_mfd_soft_select_mfd_4_short","Focus numbered MFD 4 before changing view"),
    ("mfd_5","MFD 5","button","vehicle_mfd/v_mfd_soft_select_mfd_5_short","Focus numbered MFD 5 before changing view"),
    ("mfd_6","MFD 6","button","vehicle_mfd/v_mfd_soft_select_mfd_6_short","Focus numbered MFD 6 before changing view"),
    ("mfd_7","MFD 7","button","vehicle_mfd/v_mfd_soft_select_mfd_7_short","Focus numbered MFD 7 before changing view"),
    ("mfd_8","MFD 8","button","vehicle_mfd/v_mfd_soft_select_mfd_8_short","Focus numbered MFD 8 before changing view"),
    ("mfd_9","MFD 9","button","vehicle_mfd/v_mfd_soft_select_mfd_9_short","Focus numbered MFD 9 before changing view"),
    ("mfd_10","MFD 10","button","vehicle_mfd/v_mfd_soft_select_mfd_10_short","Focus numbered MFD 10 before changing view"),
])
add("mfd","Choose display page",[
    ("mfd_self","Self Status","button","vehicle_mfd/v_mfd_select_view_self_status_short","Show own ship status on focused MFD"),
    ("mfd_target","Target Status","button","vehicle_mfd/v_mfd_select_view_target_status_short","Show target status on focused MFD"),
    ("mfd_scanning","Scanning","button","vehicle_mfd/v_mfd_select_view_scanning_short","Show scanning view on focused MFD"),
    ("mfd_config","Configuration","button","vehicle_mfd/v_mfd_select_view_configuration_short","Show configuration view on focused MFD"),
    ("mfd_comms","Comms","button","vehicle_mfd/v_mfd_select_view_comms_short","Show communications on focused MFD"),
    ("mfd_ifcs","IFCS","button","vehicle_mfd/v_mfd_select_view_ifcs_short","Show IFCS screen on focused MFD"),
    ("mfd_diagnostics","Diagnostics","button","vehicle_mfd/v_mfd_select_view_diagnostics_short","Show diagnostics on focused MFD"),
    ("mfd_resources","Resource Network","button","vehicle_mfd/v_mfd_select_view_resource_network_short","Show engineering resource network"),
])
add("mfd","Cycle views",[
    ("mfd_page_prev","Previous View","button","vehicle_mfd/v_mfd_interact_cycle_backwards_short","Cycle selected MFD backward"),
    ("mfd_page_next","Next View","button","vehicle_mfd/v_mfd_interact_cycle_forwards_short","Cycle selected MFD forward"),
])

add("systems","Primary systems",[
    ("ship_power","Ship Power","toggle",None,"Single keyboard shortcut; requires confirmation"),
    ("engine_power","Thruster Power","toggle",None,"Single keyboard shortcut; requires confirmation"),
    ("sys_shields","Shields","toggle",None,"Single shortcut"),
    ("sys_weapons","Weapons","toggle",None,"Single shortcut"),
    ("sys_flight_ready","Flight Ready","button",None,"Ship startup"),
    ("sys_lights","Ship Lights","toggle",None,"Exterior lights"),
])
add("systems","Hatches & access",[
    ("open_all_doors","Open All Doors","button",None,"Single shortcut; requires confirmation"),
    ("close_all_doors","Close All Doors","button",None,"Single shortcut; requires confirmation"),
    ("sys_lock","Door Lock","toggle",None,"Lock/unlock doors"),
    ("sys_ramp","Exterior Access","toggle",None,"Ramp / access command"),
])
add("systems","Landing configuration",[
    ("sys_gear","Landing Gear","toggle",None,"Landing gear"),
    ("sys_vtol","VTOL","toggle",None,"VTOL mode"),
    ("sys_atc","Takeoff / Landing Request","button",None,"Request ATC takeoff or landing"),
])
add("mining","Mining operations",[
    ("mine_mode","Mining Mode","button",None,"Enter mining operator mode"),
    ("mine_laser","Mining Laser","hold",None,"Hold to fire; needs binding"),
    ("mine_switch","Switch Laser","button",None,"Swap mining heads"),
    ("mine_ping","Scan Ping","button",None,"Scan area"),
    ("mine_gimbal","Mining Gimbal","button",None,"Cycle gimbal"),
])
add("mining","Laser output • step control",[
    ("mining_power","Laser Power","slider",None,"Visualization only until increment/decrement keys are mapped"),
])
add("mining","Consumables",[
    ("mine_slot1","Consumable 01","button",None,"Activate slot 1"),
    ("mine_slot2","Consumable 02","button",None,"Activate slot 2"),
    ("mine_slot3","Consumable 03","button",None,"Activate slot 3"),
])
add("foot","Equipment",[
    ("fps_weapon","Draw / Holster","button",None,"Weapon quick access"),
    ("fps_medpen","Medical Item","button",None,"Use equipped med item"),
    ("fps_grenade","Grenade","button",None,"Quick throw/equip"),
    ("fps_flash","Flashlight","toggle",None,"Weapon / helmet light"),
])
add("foot","Interaction & navigation",[
    ("fps_inventory","Inventory","button",None,"Open inventory"),
    ("fps_mobiglas","mobiGlas","button",None,"Open mobiGlas"),
    ("fps_interact","Interaction","hold",None,"Hold interaction command"),
    ("fps_map","Map","button",None,"Navigation map"),
])
add("utility","Cargo & service",[
    ("util_tractor","Tractor Beam","button",None,"Equipment control"),
    ("util_cargo","Cargo Interface","button",None,"Open cargo / inventory"),
    ("util_salvage","Salvage Mode","button",None,"Operator mode"),
    ("util_scan","Scan Mode","button",None,"Scanner mode"),
])
add("utility","Camera & communication",[
    ("util_camera","External Camera","button",None,"Camera mode"),
    ("util_screenshot","Screenshot","button",None,"Capture frame"),
    ("util_comms","Comms","hold",None,"Push to talk; hold behavior"),
    ("util_eva","EVA Utility","button",None,"Custom EVA mapping"),
])
