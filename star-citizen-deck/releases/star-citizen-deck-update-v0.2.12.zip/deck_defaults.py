"""Curated controls. Action references are examples verified against CIG's exported XML.
Unverified controls deliberately have no automatic action reference or key assigned.
"""

PROFILES = [
    {"id":"home","name":"Overview","short":"HOME","subtitle":"Command center","icon":"grid"},
    {"id":"nav","name":"Navigation","short":"NAV","subtitle":"Transit & maneuvering","icon":"compass"},
    {"id":"scm","name":"Combat","short":"SCM","subtitle":"Weapons & defense","icon":"target"},
    {"id":"systems","name":"Ship Systems","short":"SYS","subtitle":"Power & access","icon":"cpu"},
    {"id":"mining","name":"Mining","short":"MINE","subtitle":"Extraction operations","icon":"pickaxe"},
    {"id":"foot","name":"On Foot","short":"FPS","subtitle":"Personal equipment","icon":"person"},
    {"id":"utility","name":"Utilities","short":"UTIL","subtitle":"Cargo, EVA & camera","icon":"sliders"},
]

CONTROLS = []

def add(profile, section, items):
    for name, label, kind, action, detail in items:
        CONTROLS.append({"id":name,"profile":profile,"section":section,"label":label,"kind":kind,
                         "action_ref":action,"binding":"","hold_ms":100,"description":detail,
                         "confirm":name in {"ship_power","open_all_doors","close_all_doors","engine_power"}})

add("home","Flight essentials",[
    ("home_master","Master Modes","button",None,"Switch NAV / SCM; link your assigned shortcut"),
    ("home_landing","Landing Gear","toggle",None,"Local indication only; not aircraft telemetry"),
    ("home_lights","Exterior Lights","toggle",None,"Local indication only"),
    ("home_hail","Request Landing","button",None,"Contact landing services"),
])
add("home","Quick actions",[
    ("home_flight_ready","Flight Ready","button",None,"Ship startup action"),
    ("home_ping","Sensor Ping","button",None,"Use your current ping mapping"),
    ("home_cruise","Cruise Control","toggle","spaceship_movement/v_ifcs_toggle_cruise_control","Toggle cruise control"),
    ("home_decouple","Decoupled","toggle","spaceship_movement/v_ifcs_toggle_vector_decoupling","Toggle coupled flight"),
])
add("nav","Quantum & transit",[
    ("nav_mode","NAV / SCM","hold",None,"Master mode switch; configure a hold if required"),
    ("nav_quantum","Quantum Engage","button",None,"Bind to current quantum jump control"),
    ("nav_spool","Quantum Spool","button",None,"Only if separately bound in current version"),
    ("nav_cancel","Cancel Quantum","button",None,"Only if supported by game mapping"),
])
add("nav","Flight management",[
    ("nav_cruise","Cruise Control","toggle","spaceship_movement/v_ifcs_toggle_cruise_control","Local state estimate"),
    ("nav_decouple","Decoupled","toggle","spaceship_movement/v_ifcs_toggle_vector_decoupling","Local state estimate"),
    ("nav_speed_reset","Speed Limiter Reset","button","spaceship_movement/v_ifcs_speed_limiter_reset_scm","Reset to SCM speed"),
    ("nav_vtol","VTOL","toggle",None,"Toggle VTOL"),
    ("nav_gear","Landing Gear","toggle",None,"Toggle landing gear"),
    ("nav_request","Request Landing","button",None,"ATC request"),
])
add("nav","Power distribution",[
    ("nav_power_thrusters","Focus Thrusters","button","spaceship_power/v_power_focus_thrusters","Power focus"),
    ("nav_power_shields","Focus Shields","button","spaceship_power/v_power_focus_shields","Power focus"),
    ("nav_power_weapons","Focus Weapons","button","spaceship_power/v_power_focus_weapons","Power focus"),
    ("nav_power_reset","Reset Distribution","button","spaceship_power/v_power_reset_focus","Return power focus"),
])
add("scm","Targeting",[
    ("scm_hostiles","Cycle Hostiles","button","spaceship_targeting_advanced/v_target_cycle_hostile_fwd","Next hostile"),
    ("scm_nearest","Nearest Hostile","button",None,"Find a hostile target"),
    ("scm_lock1","Target Pin 1","button","spaceship_targeting/v_target_toggle_lock_index_1","Lock pinned target 1"),
    ("scm_lock2","Target Pin 2","button","spaceship_targeting/v_target_toggle_lock_index_2","Lock pinned target 2"),
])
add("scm","Weapons & defensive",[
    ("scm_aimmode","Aim Mode","button","spaceship_weapons/v_weapon_cycle_aimmode","Cycle aim settings"),
    ("scm_missiles","Missile Launch","button","spaceship_missiles/v_weapon_launch_missile","Send one launch input"),
    ("scm_decoy","Deploy Decoy","button","spaceship_defensive/v_weapon_countermeasure_decoy_launch","Countermeasures"),
    ("scm_noise","Deploy Noise","button","spaceship_defensive/v_weapon_countermeasure_noise_launch","Countermeasures"),
])
add("scm","Combat power",[
    ("scm_shields","Focus Shields","button","spaceship_power/v_power_focus_shields","Power focus"),
    ("scm_weapons","Focus Weapons","button","spaceship_power/v_power_focus_weapons","Power focus"),
    ("scm_reset","Reset Power","button","spaceship_power/v_power_reset_focus","Reset focus"),
    ("scm_shield_reset","Reset Shield Faces","button","spaceship_defensive/v_shield_reset_level","Shield equalization"),
])
add("systems","Primary systems",[
    ("ship_power","Ship Power","toggle",None,"Single keyboard shortcut; requires confirmation"),
    ("engine_power","Thruster Power","toggle",None,"Single keyboard shortcut; requires confirmation"),
    ("sys_shields","Shields","toggle",None,"Single shortcut"),
    ("sys_weapons","Weapons","toggle",None,"Single shortcut"),
    ("sys_flight_ready","Flight Ready","button",None,"Ship startup"),
    ("sys_lights","Ship Lights","toggle",None,"Exterior lights"),
])
add("systems","Hatches & access",[
    ("open_all_doors","Open All Doors","button",None,"Single shortcut; requires confirmation"),
    ("close_all_doors","Close All Doors","button",None,"Single shortcut; requires confirmation"),
    ("sys_lock","Door Lock","toggle",None,"Lock/unlock doors"),
    ("sys_ramp","Exterior Access","toggle",None,"Ramp / access command"),
])
add("systems","Landing configuration",[
    ("sys_gear","Landing Gear","toggle",None,"Landing gear"),
    ("sys_vtol","VTOL","toggle",None,"VTOL mode"),
    ("sys_atc","Call ATC","button",None,"Landing service request"),
])
add("mining","Mining operations",[
    ("mine_mode","Mining Mode","button",None,"Enter mining operator mode"),
    ("mine_laser","Mining Laser","hold",None,"Hold to fire; needs binding"),
    ("mine_switch","Switch Laser","button",None,"Swap mining heads"),
    ("mine_ping","Scan Ping","button",None,"Scan area"),
    ("mine_gimbal","Mining Gimbal","button",None,"Cycle gimbal"),
])
add("mining","Laser output • step control",[
    ("mining_power","Laser Power","slider",None,"Visualization only until increment/decrement keys are mapped"),
])
add("mining","Consumables",[
    ("mine_slot1","Consumable 01","button",None,"Activate slot 1"),
    ("mine_slot2","Consumable 02","button",None,"Activate slot 2"),
    ("mine_slot3","Consumable 03","button",None,"Activate slot 3"),
])
add("foot","Equipment",[
    ("fps_weapon","Draw / Holster","button",None,"Weapon quick access"),
    ("fps_medpen","Medical Item","button",None,"Use equipped med item"),
    ("fps_grenade","Grenade","button",None,"Quick throw/equip"),
    ("fps_flash","Flashlight","toggle",None,"Weapon / helmet light"),
])
add("foot","Interaction & navigation",[
    ("fps_inventory","Inventory","button",None,"Open inventory"),
    ("fps_mobiglas","mobiGlas","button",None,"Open mobiGlas"),
    ("fps_interact","Interaction","hold",None,"Hold interaction command"),
    ("fps_map","Map","button",None,"Navigation map"),
])
add("utility","Cargo & service",[
    ("util_tractor","Tractor Beam","button",None,"Equipment control"),
    ("util_cargo","Cargo Interface","button",None,"Open cargo / inventory"),
    ("util_salvage","Salvage Mode","button",None,"Operator mode"),
    ("util_scan","Scan Mode","button",None,"Scanner mode"),
])
add("utility","Camera & communication",[
    ("util_camera","External Camera","button",None,"Camera mode"),
    ("util_screenshot","Screenshot","button",None,"Capture frame"),
    ("util_comms","Comms","hold",None,"Push to talk; hold behavior"),
    ("util_eva","EVA Utility","button",None,"Custom EVA mapping"),
])
